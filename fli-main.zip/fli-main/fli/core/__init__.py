"""Core utilities for flight search operations.

This module provides shared parsing and building utilities used by both
the CLI and MCP interfaces.
"""

from .airports import search_airports
from .builders import (
    build_date_search_segments,
    build_flight_segments,
    build_multi_city_segments,
    build_time_restrictions,
    normalize_date,
)
from .currency import extract_currency_from_price_token, format_price, format_price_axis_label
from .errors import ErrorClassification, classify_error, format_validation_error
from .links import google_flights_url, with_locale_params
from .parsers import (
    parse_airlines,
    parse_alliances,
    parse_cabin_class,
    parse_currency,
    parse_emissions,
    parse_max_stops,
    parse_sort_by,
    parse_time_range,
    resolve_airport,
    resolve_airports,
    resolve_enum,
)

__all__ = [
    # Parsers
    "parse_airlines",
    "parse_alliances",
    "parse_cabin_class",
    "parse_currency",
    "parse_emissions",
    "parse_max_stops",
    "parse_sort_by",
    "parse_time_range",
    "resolve_airport",
    "resolve_airports",
    "resolve_enum",
    # Builders
    "build_date_search_segments",
    "build_flight_segments",
    "build_multi_city_segments",
    "build_time_restrictions",
    "normalize_date",
    "search_airports",
    # Currency
    "extract_currency_from_price_token",
    "format_price",
    "format_price_axis_label",
    # Errors
    "ErrorClassification",
    "classify_error",
    "format_validation_error",
    # Links
    "google_flights_url",
    "with_locale_params",
]
