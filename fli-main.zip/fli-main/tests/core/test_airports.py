"""Tests for airport search functionality."""

from fli.core.airports import AirportMatch, search_airports
from fli.models import Airport


class TestSearchAirports:
    def test_exact_iata_code(self):
        results = search_airports("JFK")
        assert len(results) >= 1
        assert results[0].code is Airport.JFK
        assert results[0].match_type == "iata_exact"
        assert results[0].score == 100.0

    def test_iata_code_case_insensitive(self):
        results = search_airports("jfk")
        assert results[0].code is Airport.JFK

    def test_iata_code_with_surrounding_whitespace(self):
        results = search_airports("  JFK  ")
        assert results[0].code is Airport.JFK
        assert results[0].match_type == "iata_exact"

    def test_city_name_new_york(self):
        codes = {r.code for r in search_airports("new york")}
        assert {Airport.JFK, Airport.LGA, Airport.EWR} <= codes

    def test_city_name_tokyo(self):
        codes = {r.code for r in search_airports("tokyo")}
        assert {Airport.NRT, Airport.HND} <= codes

    def test_city_name_london_returns_all_five(self):
        codes = {r.code for r in search_airports("london")}
        assert {Airport.LHR, Airport.LGW, Airport.STN, Airport.LTN, Airport.LCY} <= codes

    def test_airport_name_substring(self):
        results = search_airports("heathrow")
        assert results[0].code is Airport.LHR
        assert results[0].match_type == "name"

    def test_san_francisco_dedupes_across_priorities(self):
        # "san francisco" matches both Priority 2 (city map) and Priority 4
        # (airport name substring). seen_codes must prevent duplicates.
        results = search_airports("san francisco")
        codes = [r.code for r in results]
        assert codes.count(Airport.SFO) == 1

    def test_partial_city_name(self):
        codes = {r.code for r in search_airports("new yo")}
        assert Airport.JFK in codes

    def test_iata_prefix_distinct_from_exact(self):
        # "JF" is not an exact IATA code, not a city alias, and not a substring
        # of any airport name -- so only Priority 5 (iata_prefix) fires.
        results = search_airports("JF")
        jfk_match = next(r for r in results if r.code is Airport.JFK)
        assert jfk_match.match_type == "iata_prefix"
        assert jfk_match.score == 60.0
        # All results for this query should be prefix matches.
        assert all(r.match_type == "iata_prefix" for r in results)

    def test_empty_query(self):
        assert search_airports("") == []
        assert search_airports("   ") == []

    def test_no_results(self):
        assert search_airports("xyznonexistent") == []

    def test_invalid_limit_returns_empty(self):
        assert search_airports("JFK", limit=0) == []
        assert search_airports("JFK", limit=-1) == []

    def test_limit_caps_results(self):
        assert len(search_airports("international", limit=3)) <= 3

    def test_default_limit_is_ten(self):
        # "international" appears in many airport names; default limit is 10.
        assert len(search_airports("international")) <= 10

    def test_priority_ordering(self):
        # Exact code (100) must rank above any city/name/prefix match for the same query family.
        results = search_airports("LAX")
        assert results[0].code is Airport.LAX
        assert results[0].match_type == "iata_exact"
        # Scores in the returned list must be monotonically non-increasing.
        scores = [r.score for r in results]
        assert scores == sorted(scores, reverse=True)

    def test_priority_3_skipped_when_exact_city_match(self):
        # When query is an exact city, only Priority 2 (score 90) should fire,
        # not Priority 3 (score 80). All city-matched results should be 90.
        results = search_airports("london")
        city_results = [r for r in results if r.match_type == "city"]
        assert city_results, "expected at least one city-typed match for 'london'"
        assert all(r.score == 90.0 for r in city_results)

    def test_name_score_decreases_with_position(self):
        # The 0.1-per-position weight means a match at position 0 outscores one later.
        results = search_airports("international")
        name_matches = [r for r in results if r.match_type == "name"]
        if len(name_matches) >= 2:
            scores = [r.score for r in name_matches]
            assert scores == sorted(scores, reverse=True)
            assert all(s <= 70.0 for s in scores)

    def test_city_abbreviation(self):
        codes = {r.code for r in search_airports("sf")}
        assert Airport.SFO in codes

    def test_nyc_abbreviation(self):
        codes = {r.code for r in search_airports("nyc")}
        assert Airport.JFK in codes


class TestAirportMatch:
    def test_frozen(self):
        m = AirportMatch(code=Airport.JFK, name="JFK Airport", match_type="iata_exact", score=100.0)
        try:
            m.score = 0.0
        except Exception:
            return
        raise AssertionError("AirportMatch should be frozen")

    def test_equality(self):
        a = AirportMatch(code=Airport.JFK, name="JFK", match_type="city", score=90.0)
        b = AirportMatch(code=Airport.JFK, name="JFK", match_type="city", score=90.0)
        assert a == b

    def test_rejects_invalid_match_type(self):
        try:
            AirportMatch(code=Airport.JFK, name="JFK", match_type="bogus", score=50.0)  # type: ignore[arg-type]
        except Exception:
            return
        raise AssertionError("AirportMatch should reject unknown match_type")

    def test_rejects_score_out_of_range(self):
        try:
            AirportMatch(code=Airport.JFK, name="JFK", match_type="iata_exact", score=101.0)
        except Exception:
            return
        raise AssertionError("AirportMatch should reject score > 100")


class TestDisambiguatedNamesStayInternal:
    """The " (CODE)" suffix that keeps Enum values unique must never reach users."""

    def test_search_results_show_the_plain_name(self):
        """Both airports called "Naha Airport" are returned under their own code."""
        from fli.core.airports import search_airports

        by_code = {m.code.name: m.name for m in search_airports("Naha Airport", limit=10)}
        assert by_code["OKA"] == "Naha Airport"
        assert by_code["NAH"] == "Naha Airport"

    def test_suffix_does_not_create_name_matches(self):
        """A code fragment must not match through the hidden suffix text."""
        from fli.core.airports import search_airports

        matches = [m for m in search_airports("(NC", limit=10) if m.match_type == "name"]
        assert matches == []

    def test_display_name_strips_only_its_own_code(self):
        """``display_name`` is a no-op for ordinary names."""
        from fli.models import Airline, Airport, display_name

        assert display_name(Airport.OKA) == "Naha Airport"
        assert display_name(Airport.JFK) == Airport.JFK.value
        assert Airline._1S.value.endswith(
            " (1S)"
        )  # digit-leading code: suffix shows "1S", not "_1S"
        assert display_name(Airline._1S) == Airline._1S.value.removesuffix(" (1S)")


class TestIcaoLookup:
    """`search_airports` resolves 4-letter ICAO codes, like `resolve_airport` does."""

    def test_icao_code_is_an_exact_match(self):
        """KJFK finds JFK as the top, exact result."""
        from fli.core.airports import search_airports

        results = search_airports("KJFK")
        assert results[0].code.name == "JFK"
        assert results[0].match_type == "icao_exact"

    def test_icao_lookup_is_case_insensitive(self):
        """Lower-case ICAO input resolves too."""
        from fli.core.airports import search_airports

        assert search_airports("egll")[0].code.name == "LHR"

    def test_unknown_four_letter_query_still_falls_through(self):
        """A 4-letter word that is not an ICAO code keeps using name/city search."""
        from fli.core.airports import search_airports

        results = search_airports("naha")
        assert results and all(r.match_type != "icao_exact" for r in results)

    def test_icao_hit_does_not_hijack_a_partial_word(self):
        """A "Santa..." search leads with names even though "sant" is Tucuman's ICAO code."""
        from fli.core.airports import search_airports

        results = search_airports("sant", limit=1000)
        assert results[0].match_type == "name"
        assert "TUC" in {r.code.name for r in results}  # still offered, just not first
