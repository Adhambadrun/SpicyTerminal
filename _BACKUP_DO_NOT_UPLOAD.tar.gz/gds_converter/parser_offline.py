"""
parser_offline.py — Rule-based offline parser.

Extracts flight segments from pasted text (Google Flights text, airline
emails, prose descriptions) and returns structured FlightSegment objects
ready for formatter.render_itinerary().

Best-effort by design: anything it cannot confidently parse becomes a
warning so the user can switch to AI mode.
"""

import re
from datetime import date

from aviation_data import (AIRLINES, AIRLINE_ALIASES, AMBIGUOUS_CODES,
                           AIRPORTS, CITY_ALIASES, AIRCRAFT, IATA_ACFT_CODES,
                           haversine_miles, estimate_duration_min,
                           utc_offset, format_h_mm, scan_aircraft,
                           infer_aircraft, range_advisory)
from formatter import (FlightSegment, fmt_clock, make_date,
                       CLASS_TO_CABIN, CABIN_DEFAULT_CLASS, MONTHS)

_TODAY = date.today()

# feature kill-switches (tests flip these to diff old vs new behaviour)
_ENABLE_SPLIT = True      # v1.5 google multi-block preamble splitting
_ENABLE_DEDUP = True      # v1.5 exact-duplicate leg removal
_ENABLE_PAREN_DUR = True  # v1.5 "(8h 55m)" beats bare "1h 55m" tokens

# =====================================================================
# Months / dates
# =====================================================================
MONTH_MAP = {m: i + 1 for i, m in enumerate(
    ["JAN", "FEB", "MAR", "APR", "MAY", "JUN",
     "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"])}
MONTH_MAP.update({"JANUARY": 1, "FEBRUARY": 2, "MARCH": 3, "APRIL": 4,
                  "JUNE": 6, "JULY": 7, "AUGUST": 8, "SEPTEMBER": 9,
                  "OCTOBER": 10, "NOVEMBER": 11, "DECEMBER": 12})
MONTH_RE = "|".join(sorted(MONTH_MAP, key=len, reverse=True))

DATE_RES = [
    re.compile(rf"\b(\d{{1,2}})[\s\-\.]?({MONTH_RE})(?:[\s,/\-]+(\d{{2,4}}))?\b", re.I),
    re.compile(rf"\b({MONTH_RE})\s+(\d{{1,2}})(?:st|nd|rd|th)?(?:[\s,]+(\d{{4}}))?\b", re.I),
    re.compile(r"\b(\d{4})-(\d{1,2})-(\d{1,2})\b"),
    re.compile(r"\b(\d{1,2})/(\d{1,2})/(\d{2,4})\b"),
]

# =====================================================================
# Times
# =====================================================================
TIME_RE = re.compile(
    r"(?<![\d:])"
    r"(?:(\d{1,2})[:.](\d{2})\s*([AaPp])\.?\s*[Mm]\.?"        # 1,2,3  9:30 PM
    r"|(\d{1,2})\s*([AaPp])\.?\s*[Mm]\.?"                     # 4,5    9 PM
    r"|(?<![\d:A-Za-z])(\d{1,2})(\d{2})([AP])(?![a-z])"       # 6,7,8  GDS 930P
    r"|([01]?\d|2[0-3])[:.](\d{2}))"                          # 9,10   21:30
)
OVERNIGHT_TAIL_RE = re.compile(
    r"\s*(?:¥\s?(\d)|\+\s?(\d)(?:\s?days?)?|\(?(next day|following day)\)?)", re.I)
DEP_NEAR_RE = re.compile(r"(dep\w*|leav\w*|from|take\s?off)\b", re.I)
ARR_NEAR_RE = re.compile(r"(arr\w*|arrive\w*|land\w*)\b", re.I)

DURATION_RE = re.compile(
    r"\b(\d{1,2})\s*(?:hrs?|hours?|h)\s*,?\s*(?:(\d{1,2})\s*(?:mins?|minutes?|m)\b)?"
    r"|\b(\d{1,3})\s*(?:mins?|minutes?)\b", re.I)
# Google Flights block time always comes parenthesised: "(8h 55m)".
# Bare "1h 55m" tokens are usually layover/connection noise.
PAREN_DURATION_RE = re.compile(
    r"\(\s*(\d{1,2})\s*(?:hrs?|hours?|h)\s*,?\s*"
    r"(?:(\d{1,2})\s*(?:mins?|minutes?|m)\s*)?\s*\)", re.I)
LAYOVER_GUARD_RE = re.compile(r"(layover|stopover|connection|transit|stop in|via)\b", re.I)
DIST_RE = re.compile(r"\b(\d[\d,]{2,})\s*(mi|miles|km|kilometers|kilometres)\b", re.I)

# =====================================================================
# Cabin / class
# =====================================================================
CABIN_RES = [
    ("PREMIUM ECONOMY", re.compile(r"\bpremium\s+economy\b|\bprem(ium)?\s+eco\b", re.I)),
    ("FIRST", re.compile(r"\bfirst(\s+class)?\b|\b1st\s+class\b", re.I)),
    ("BUSINESS", re.compile(r"\bbusiness(\s+class)?\b|\bbiz(\s+class)?\b|\bexec(utive)?\s+class\b", re.I)),
    ("ECONOMY", re.compile(r"\beconomy(\s+class)?\b|\bcoach\b", re.I)),
]
CABIN_CLASS_RE = re.compile(
    # cabin word followed by an explicit booking-class letter, optionally
    # parenthesised: "Business (Z)", "Premium Economy (W)", "Economy (M)"
    r"\b(premium economy|first|business|economy|coach)\s*(?:class)?\s*[-,/]?\s*"
    r"\(?\s*\b([A-Z])\b\s*\)?", re.I)
CLASS_RE = re.compile(
    r"\b(?:booking\s+class|bkg\s+class|booking\s+code|cabin\s+class|rbd|"
    r"fare\s+class|fare\s+basis|class|cls)\s*[:\-]?\s*\"?'?\b([A-Z])\b")
ALL_CABIN_RE = re.compile(r"\ball\s+(premium economy|first|business|economy)\b", re.I)
GLOBAL_CLASS_RE = re.compile(
    r"\b(?:booking\s+class|bkg\s+class|booking\s+code|cabin\s+class|rbd|"
    r"fare\s+class|fare\s+basis)\s*[:\-]?\s*\"?'?\b([A-Z])\b", re.I)

# =====================================================================
# Routes
# =====================================================================
WORD_SEP_RE = re.compile(r"\bto\b|\binto\b")
SYM_SEP_RE = re.compile(r"[-–—→➔>]")
DEP_KW_RE = re.compile(r"\b(?:departs?|departure|leaves?|leaving|from|ex)\s*[:\-]?\s*\b([A-Z]{3})\b")
ARR_KW_RE = re.compile(r"\b(?:arrives?|arrival|landing|lands?|to|into)\s*[:\-]?\s*\b([A-Z]{3})\b")
BARE_CODE_RE = re.compile(r"\b([A-Z]{3})\b")

# "City (XXX)" parenthesised codes count as airport mentions even when the
# code is not (yet) in the airport table — an unknown airport used to block
# header detection and corrupt a whole multi-block paste (v2.3 fix).
PAREN_CODE_RE = re.compile(r"(?<=[A-Za-z]\s)\(([A-Z]{3})\)")
PAREN_ROUTE_HDR_RE = re.compile(
    r"\(([A-Z]{3})\)\s+(?:to|into)\s+[A-Za-z ,.'-]{2,40}?\(([A-Z]{3})\)")

# =====================================================================
# Airline anchors
# =====================================================================
_alias_alt = "|".join(re.escape(a) for a in sorted(AIRLINE_ALIASES, key=len, reverse=True))
ALIAS_NUM_RE = re.compile(
    rf"\b({_alias_alt})\b\s*(?:flight|flt)?\s*(?:no\.?|number|nbr|#)?\s*"
    rf"(?:\(?([A-Z][A-Z0-9])\)?\s*)?(\d{{1,4}})\b", re.I)
# 2-char IATA marketing code, letter- OR digit-leading (4Y Discover,
# 6E IndiGo, 3O Air Arabia Maroc...). AIRLINES membership guards junk.
_AIRLINE_TOK = r"(?:[A-Z][A-Z0-9]|[0-9][A-Z])"
CODE_NUM_RE = re.compile(r"\b([A-Z][A-Z0-9]|[0-9][A-Z])\s{0,3}(\d{1,4})\b")


def _code_corroborated(code, text_l):
    for alias, c in AIRLINE_ALIASES.items():
        if c == code and len(alias) >= 3 and \
                re.search(rf"\b{re.escape(alias)}\b", text_l):
            return True
    return False


_OPBY_RGX = re.compile(
    r"(operated\s+by|operating\s+carrier|dba\b|on\s+behalf\s+of|op\s+by)[^\n]*$",
    re.I)
_MANUF_RGX = re.compile(
    r"(canadair|bombardier|embraer|airbus|boeing|antonov|cessna|atr|"
    r"de\s+havilland|tupolev|ilyushin|comac|sukhoi|fokker|saab|fairchild|"
    r"crj|erj)[\s\-/]*$", re.I)


def _suppressed_anchor(text, start):
    """Reject 'airline + number' matches that are really an aircraft name
    ('Canadair RJ 900' -> RJ 900 is NOT Royal Jordanian flight 900) or that
    sit inside an 'operated by ...' codeshare phrase (spec: the MARKETING
    carrier is used; operating-carrier details are ignored)."""
    seg_start = text.rfind("\n", 0, start) + 1
    line_before = text[seg_start:start]
    prev = text[max(seg_start, start - 120):start]
    return bool(_OPBY_RGX.search(prev) or _MANUF_RGX.search(line_before[-48:]))


_TIME_UNIT_AFTER = re.compile(r"\s*(?:hrs?\b|hours?\b|mins?\b|minutes?\b|m\b|h\b)", re.I)


def find_anchors(text):
    text_l = text.lower()
    cands, occupied = [], []

    for m in ALIAS_NUM_RE.finditer(text):
        if _TIME_UNIT_AFTER.match(text, m.end()):
            continue                                   # "Qatar Airways 12 hr 50 min"
        if _suppressed_anchor(text, m.start()):
            continue
        raw_alias = m.group(1).lower()
        code = AIRLINE_ALIASES.get(raw_alias)
        code_txt = (m.group(2) or "").upper()
        if code_txt and code_txt in AIRLINES:
            code = code_txt                    # explicit code = marketing carrier
        if not code:
            continue
        cands.append({"start": m.start(), "end": m.end(), "code": code,
                      "num": m.group(3)})
        occupied.append((m.start(), m.end()))

    def overlaps(s, e):
        return any(s < ee and e > ss for ss, ee in occupied)

    for m in CODE_NUM_RE.finditer(text):
        code, num = m.group(1), m.group(2)
        if code not in AIRLINES or overlaps(m.start(), m.end()):
            continue
        if _TIME_UNIT_AFTER.match(text, m.end()):
            continue
        if _suppressed_anchor(text, m.start()):
            continue                              # "Canadair RJ 900" / "operated by ..."
        after = text[m.end():m.end() + 6]
        if re.match(r"-\d", after):                    # "A350-900" tail
            continue
        token = (code + num).upper()                   # aircraft guard
        if token in AIRCRAFT or re.fullmatch(
                r"(A3\d\d|A22\d|B7\d7|E1\d\d|E19\d|E29\d|CRJ\d+|ATR\d\d)",
                token):
            continue
        if code in AMBIGUOUS_CODES and not _code_corroborated(code, text_l):
            nxt = text[m.end():m.end() + 30]
            if not any(r.search(nxt) for r in DATE_RES[:2]):
                continue
        cands.append({"start": m.start(), "end": m.end(), "code": code,
                      "num": num})
        occupied.append((m.start(), m.end()))

    cands.sort(key=lambda c: c["start"])
    deduped = []
    for c in cands:
        if (deduped and c["start"] - deduped[-1]["start"] < 60
                and c["code"] == deduped[-1]["code"] and c["num"] == deduped[-1]["num"]):
            continue
        deduped.append(c)
    return deduped


# =====================================================================
# Field extraction
# =====================================================================
def find_dates(region):
    out = []
    for idx, rx in enumerate(DATE_RES):
        for m in rx.finditer(region):
            try:
                if idx == 0:
                    day, mon = int(m.group(1)), MONTH_MAP[m.group(2).upper()]
                elif idx == 1:
                    day, mon = int(m.group(2)), MONTH_MAP[m.group(1).upper()]
                elif idx == 2:
                    day, mon = int(m.group(3)), int(m.group(2))
                else:
                    a_, b_ = int(m.group(1)), int(m.group(2))
                    if a_ > 12:
                        day, mon = a_, b_
                    else:
                        # 08/12/2026 -> Aug 12. Ambiguous pairs follow the
                        # US airline convention MM/DD (a dropped date is far
                        # worse than a flipped one).
                        day, mon = b_, a_
                if 1 <= day <= 31 and 1 <= mon <= 12:
                    out.append({"pos": m.start(), "day": day, "mon": mon, "prio": idx})
            except (ValueError, KeyError):
                continue
    return out


def find_times(region, base):
    out = []
    for m in TIME_RE.finditer(region):
        if m.group(1) is not None:                       # 9:30 PM
            hh, mm = int(m.group(1)) % 12, int(m.group(2))
            if m.group(3).lower() == "p":
                hh += 12
        elif m.group(4) is not None:                     # 9 PM
            hh, mm = int(m.group(4)) % 12, 0
            if m.group(5).lower() == "p":
                hh += 12
        elif m.group(6) is not None:                     # GDS 930P
            hh, mm = int(m.group(6)) % 12, int(m.group(7))
            if m.group(8) == "P":
                hh += 12
        else:                                            # 24h
            hh, mm = int(m.group(9)), int(m.group(10))
        if hh > 23 or mm > 59:
            continue
        marker = None
        tail = OVERNIGHT_TAIL_RE.match(region, m.end())
        if tail:
            if tail.group(1) or tail.group(2):
                marker = int(tail.group(1) or tail.group(2))
            elif tail.group(3):
                marker = 1
        ctx = region[max(0, m.start() - 32):m.start()]
        out.append({
            "h": hh, "m": mm, "marker": marker, "pos": base + m.start(),
            "depkw": bool(DEP_NEAR_RE.search(ctx)),
            "arrkw": bool(ARR_NEAR_RE.search(ctx)),
        })
    return out


def pick_times(w_times, p_times):
    """Choose dep/arr tokens. Window tokens always beat pre-region tokens."""
    for t in w_times:
        t["region"] = "w"
    for t in p_times:
        t["region"] = "p"
    pool = w_times if len(w_times) >= 2 else w_times + p_times
    pool.sort(key=lambda t: t["pos"])
    if not pool:
        return None, None

    dep = next((t for t in pool if t["depkw"]), None)
    arr = next((t for t in pool if t["arrkw"] and t is not dep), None)

    if dep is None and arr is None:
        if len(pool) >= 2:
            dep, arr = pool[0], pool[-1]
        else:
            dep = pool[0]
    elif dep is None:
        others = [t for t in pool if t is not arr]
        dep = others[0] if others else None
    elif arr is None:
        others = [t for t in pool if t is not dep]
        arr = others[-1] if others else None

    if dep and arr and dep is arr:
        others = [t for t in pool if t is not dep]
        arr = others[-1] if others else None
    # positional sanity: dep before arr (only when no keyword evidence)
    if dep and arr and dep["pos"] > arr["pos"] and not dep["depkw"] and not arr["arrkw"]:
        dep, arr = arr, dep
    return dep, arr


def find_duration(region):
    # parenthesised block time "(8h 55m)" wins over bare tokens — but a
    # parenthesised LAYOVER token ("Layover in IST (2h 25m)") is never
    # block time; its label guards it like any bare token.
    if _ENABLE_PAREN_DUR:
        for m in PAREN_DURATION_RE.finditer(region):
            ctx = region[max(0, m.start() - 25): m.end() + 25]
            if LAYOVER_GUARD_RE.search(ctx):
                continue
            mins = int(m.group(1)) * 60 + int(m.group(2) or 0)
            if 0 < mins <= 2400:
                return mins
    best_pos, best_val = None, None
    for m in DURATION_RE.finditer(region):
        ctx = region[max(0, m.start() - 25): m.end() + 25]
        if LAYOVER_GUARD_RE.search(ctx):
            continue
        if m.group(3) is not None:
            mins = int(m.group(3))
        else:
            mins = int(m.group(1)) * 60 + int(m.group(2) or 0)
        if 0 < mins <= 2400 and (best_pos is None or m.start() < best_pos):
            best_val, best_pos = mins, m.start()
    return best_val


def find_distance(region):
    for m in DIST_RE.finditer(region):
        val = int(m.group(1).replace(",", ""))
        if m.group(2).lower().startswith(("km", "kilomet")):
            val = round(val * 0.621371)
        if 50 <= val <= 14000:
            return val
    return None


def _city_alt_re():
    """Single precompiled alternation of every city alias (v3.0 speed fix).

    Previously each block scan re-sorted CITY_ALIASES and compiled ONE regex
    per alias (~1,100) — a recompile storm that made CONVERT chew 8+ seconds
    on full-page Google pastes and feel frozen (the office's exact report).
    One ordered alternation (longest-first, so priority is preserved) scans
    the region in a single pass."""
    global _CITY_ALT_RE
    if _CITY_ALT_RE is None:
        alts = sorted(CITY_ALIASES, key=len, reverse=True)
        _CITY_ALT_RE = re.compile(
            r"\b(" + "|".join(re.escape(a) for a in alts) + r")\b")
    return _CITY_ALT_RE


_CITY_ALT_RE = None


def _airport_mentions(region):
    """Unified (code token / city alias) mention list, position-sorted."""
    rl = region.lower()
    raw = []
    for m in BARE_CODE_RE.finditer(region):
        if m.group(1) in AIRPORTS:
            raw.append((m.start(), m.group(1), 3))
    for m in PAREN_CODE_RE.finditer(region):
        if not any(p <= m.start() < p + ln for p, _, ln in raw):
            raw.append((m.start(), m.group(1), 5))
    for m in _city_alt_re().finditer(rl):
        raw.append((m.start(), CITY_ALIASES[m.group(1)], len(m.group(1))))
    raw.sort(key=lambda x: (x[0], -x[2]))
    clean = []
    for pos, code, ln in raw:
        if clean and pos < clean[-1][0] + clean[-1][2]:
            continue                                   # overlap -> keep longer/first
        clean.append((pos, code, ln))
    return clean


def find_airports(region, anchor_rel):
    mentions = _airport_mentions(region)

    # 1) explicit separator pairs:  CODE/city sep CODE/city
    candidates = []
    for m in WORD_SEP_RE.finditer(region):
        sp = m.start()
        left = next((x for x in reversed(mentions) if x[0] < sp), None)
        right = next((x for x in mentions if x[0] > sp), None)
        if left and right and left[1] != right[1]:
            gap_ok = (right[0] - (left[0] + left[2])) < 60
            if gap_ok:
                candidates.append((abs(sp - anchor_rel), left[1], right[1]))
    for m in SYM_SEP_RE.finditer(region):
        sp = m.start()
        left = next((x for x in reversed(mentions) if x[0] < sp), None)
        right = next((x for x in mentions if x[0] > sp), None)
        if left and right and left[1] != right[1]:
            # tight adjacency for symbols (kills time/aircraft dashes)
            if (sp - (left[0] + left[2])) <= 2 and (right[0] - sp) <= 2:
                candidates.append((abs(sp - anchor_rel), left[1], right[1]))
    if candidates:
        candidates.sort()
        return candidates[0][1], candidates[0][2]

    # 2) departure/arrival keywords + code
    dep = arr = None
    for m in DEP_KW_RE.finditer(region):
        if m.group(1) in AIRPORTS:
            dep = m.group(1)
            break
    for m in ARR_KW_RE.finditer(region):
        if m.group(1) in AIRPORTS:
            arr = m.group(1)
            break

    # 3) positional fallback on mentions
    unique = []
    for _, code, _ln in mentions:
        if code not in unique:
            unique.append(code)
    if not dep and not arr:
        if len(unique) >= 2:
            dep, arr = unique[0], unique[1]
        elif len(unique) == 1:
            dep = unique[0]
    elif dep and not arr:
        for c in unique:
            if c != dep:
                arr = c
                break
    elif arr and not dep:
        for c in unique:
            if c != arr:
                dep = c
                break
    return dep, arr


def find_side_headers(text):
    """Line-anchored route headers in Google-Flights style pastes:
        Frankfurt (FRA) to Washington DC (IAD)
        Washington DC (IAD) to Dallas (DFW)
    Returns [(abs_line_start, orig_code, dest_code)], position-sorted."""
    out = []
    pos = 0
    for line in text.split("\n"):
        ls = pos
        pos += len(line) + 1
        if not line.strip() or len(line) > 90:
            continue
        pq = PAREN_ROUTE_HDR_RE.search(line)
        if pq and pq.group(1) != pq.group(2):
            # structurally a Google header even when a code is unknown
            out.append((ls, pq.group(1), pq.group(2)))
            continue
        mentions = _airport_mentions(line)
        uniq = {c for _, c, _ in mentions}
        if len(uniq) < 2 or not WORD_SEP_RE.search(line):
            continue
        o_, d_ = find_airports(line, len(line) // 2)
        if o_ and d_ and o_ != d_:
            out.append((ls, o_, d_))
    return out


def find_aircraft(region):
    rl = region.upper().replace("\u2013", "-").replace("\u2014", "-")
    for m in re.finditer(r"\b([A-Z0-9]{3})\b", rl):
        tok = m.group(1)
        if tok in IATA_ACFT_CODES and any(ch.isdigit() for ch in tok):
            return tok
    return scan_aircraft(rl)


def find_cabin_class(region, anchor_rel):
    cabin = cls = None
    hits = []
    for m in CABIN_CLASS_RE.finditer(region):
        w = m.group(1).upper()
        c = "PREMIUM ECONOMY" if "PREMIUM" in w else ("ECONOMY" if w in ("ECONOMY", "COACH") else w)
        hits.append((abs(m.start() - anchor_rel), c, m.group(2)))
    for name, rx in CABIN_RES:
        for m in rx.finditer(region):
            hits.append((abs(m.start() - anchor_rel), name, None))
    for m in CLASS_RE.finditer(region):
        hits.append((abs(m.start() - anchor_rel), None, m.group(1)))
    hits.sort(key=lambda h: h[0])
    for _, c, letter in hits:
        if c and not cabin:
            cabin = c
        if letter and not cls:
            cls = letter
        if cabin and cls:
            break
    return cabin, cls


# =====================================================================
# GDS-format fast path
# =====================================================================
# Handles already-structured black-window rows, e.g. pasted from a GDS:
#   1 UA    1 13DEC SFO SIN 1040P    800A¥2 D    789 17.20  8446  N
# Every column is preserved VERBATIM: booking class, overnight marker,
# displayed block time and distance are never recomputed or "corrected".

def _fill_aircraft(segments):
    """Business rule (v2.5): output never prints '???' as aircraft. Unknown
    aircraft are resolved from the curated flight table / per-airline route
    estimate, and the inference is disclosed in status-bar warnings (never
    inside the output). Explicit aircraft in input always wins."""
    for s in segments:
        if s.aircraft in ("", "???"):
            try:
                d = int(s.distance) if str(s.distance).isdigit() else 0
            except Exception:
                d = 0
            code, src = infer_aircraft(s.airline, s.flight_no, s.orig, s.dest, d)
            s.aircraft = code
            s.warnings.append(
                f"aircraft inferred {code} ({s.airline} {s.flight_no}, {src})")
    # v2.6 data-integrity pass: sanity-check every segment's equipment
    # (explicit or inferred) against published range vs route distance.
    # Advisory lives in status-bar warnings only; output rows never change.
    for s in segments:
        try:
            d = int(s.distance) if str(s.distance).isdigit() else 0
        except Exception:
            d = 0
        warn = range_advisory(s.aircraft, s.orig, s.dest, d)
        if warn:
            s.warnings.append(warn)

def _gds_clock(tok):
    """'1040P' / '800A' / noon '1200N' / midnight '1200M' -> (h24, mm) or None."""
    m = re.fullmatch(r"(\d{3,4})([APNM])", tok.upper())
    if not m:
        return None
    num = m.group(1)
    hh, mm = int(num[:-2]), int(num[-2:])
    if not (1 <= hh <= 12 and mm < 60):
        return None
    ap = m.group(2)
    if ap == "N":                                # GDS convention: N = noon
        return (12, 0) if (hh, mm) == (12, 0) else None
    if ap == "M":                                # GDS convention: M = midnight
        return (0, 0) if (hh, mm) == (12, 0) else None
    h24 = hh % 12 + (12 if ap == "P" else 0)
    return h24, mm


def _try_gds_lines(text):
    lines = text.replace("\u00a0", " ").replace("\u2007", " ").replace(
        "\u202f", " ").split("\n")

    def cabin_near(li):
        for j in (li, li + 1, li + 2, li - 1, li + 3):
            if 0 <= j < len(lines):
                m = re.search(
                    r"CABIN\s*[-:]?\s*(FIRST|BUSINESS|PREMIUM\s+ECONOMY|ECONOMY)",
                    lines[j], re.I)
                if m:
                    w = " ".join(m.group(1).upper().split())
                    return "PREMIUM ECONOMY" if "PREMIUM" in w else w
        for j in (li, li + 1, li + 2, li - 1, li + 3):
            if 0 <= j < len(lines):
                for name, rx in CABIN_RES:
                    if rx.search(lines[j]):
                        return name
        return ""

    segs = []
    for li, raw in enumerate(lines):
        toks = raw.split()
        if len(toks) < 7:
            continue
        i = 0
        # optional leading segment number
        if i + 1 < len(toks) and re.fullmatch(r"\d{1,2}", toks[i]) and re.fullmatch(
                _AIRLINE_TOK + r"\d{0,4}[A-Z]?", toks[i + 1].upper()):
            i += 1
        # airline + flight number (separate or glued like UA1)
        al = flt = flt_cls = None
        g = re.fullmatch(r"(" + _AIRLINE_TOK + r")(\d{1,4})([A-Z])?",
                         toks[i].upper())
        if g and g.group(1) in AIRLINES:
            al, flt, flt_cls = g.group(1), g.group(2), g.group(3) or ""
            i += 1
        elif i + 1 < len(toks) and re.fullmatch(_AIRLINE_TOK, toks[i].upper()) \
                and toks[i].upper() in AIRLINES:
            m2 = re.fullmatch(r"(\d{1,4})([A-Z])?", toks[i + 1].upper())
            if not m2:
                continue
            al, flt, flt_cls = toks[i].upper(), m2.group(1), m2.group(2) or ""
            i += 2
        else:
            continue
        # layout variant: booking class BEFORE the date ("AA 8880 I 26SEP")
        if i < len(toks) and re.fullmatch(r"[A-Z]", toks[i]):
            flt_cls = toks[i].upper()
            i += 1
        # date: 13DEC or 13 DEC
        day = mon = None
        dm = re.fullmatch(r"(\d{1,2})([A-Z]{3})",
                          toks[i].upper()) if i < len(toks) else None
        if dm and dm.group(2) in MONTH_MAP:
            day, mon = int(dm.group(1)), MONTH_MAP[dm.group(2)]
            i += 1
        elif i + 1 < len(toks) and re.fullmatch(r"\d{1,2}", toks[i]) \
                and toks[i + 1].upper() in MONTH_MAP:
            day, mon = int(toks[i]), MONTH_MAP[toks[i + 1].upper()]
            i += 2
        else:
            continue
        if not (1 <= day <= 31):
            continue
        # route
        if i + 1 >= len(toks) \
                or not re.fullmatch(r"[A-Z]{3}", toks[i].upper()) \
                or not re.fullmatch(r"[A-Z]{3}", toks[i + 1].upper()):
            continue
        orig, dest = toks[i].upper(), toks[i + 1].upper()
        if orig == dest:
            continue        # unknown codes still flow; the table is best-effort
        i += 2
        # departure clock
        dc = _gds_clock(toks[i]) if i < len(toks) else None
        if not dc:
            continue
        i += 1
        # arrival clock (+ optional overnight marker 800A¥2 / 520P+1 / +1 token)
        am = re.fullmatch(r"(\d{3,4}[APNM])[¥+]?(\d)?",
                          toks[i].upper()) if i < len(toks) else None
        if not am:
            continue
        ac = _gds_clock(am.group(1))
        if not ac:
            continue
        shift = int(am.group(2)) if am.group(2) else 0
        i += 1
        if i < len(toks) and re.fullmatch(r"[¥+]?([0-3])", toks[i]):
            shift = int(toks[i].lstrip("¥+"))   # "¥2" / "+1" / bare "1"
            i += 1
        # booking class (single letter, preserved verbatim)
        cls = ""
        if i < len(toks) and re.fullmatch(r"[A-Z]", toks[i]):
            cls = toks[i].upper()
            i += 1
        elif flt_cls:
            cls = flt_cls
        # aircraft / duration H.MM / distance — leftover columns, any order
        acft = dur = dist = ""
        while i < len(toks):
            t, up = toks[i], toks[i].upper()
            if not acft and up in IATA_ACFT_CODES and any(c.isdigit() for c in up):
                acft = up
            elif not dur and re.fullmatch(r"\d{1,2}\.\d{2}", t):
                dur = t
            elif not dist and re.fullmatch(r"\d{3,5}", t):
                dist = t
            i += 1

        seg = FlightSegment()
        seg.seg = len(segs) + 1
        seg.airline, seg.flight_no = al, flt
        seg.date_ddmmm = make_date(day, mon)
        seg.orig, seg.dest = orig, dest
        seg.dep_time = fmt_clock(dc[0], dc[1])
        seg.arr_time = fmt_clock(ac[0], ac[1])
        seg.arr_day_shift = min(max(shift, 0), 3)
        seg.booking_class = cls
        seg.aircraft = acft or "???"
        seg.cabin = cabin_near(li) or CLASS_TO_CABIN.get(cls, "") or "ECONOMY"
        if not seg.booking_class:
            seg.booking_class = CABIN_DEFAULT_CLASS[seg.cabin]
        if dur:
            hh, _, mm = dur.partition(".")
            seg.flight_time = f"{int(hh)}.{mm}"
        else:
            try:
                fdate = date(_TODAY.year, mon, min(day, 28))
            except ValueError:
                fdate = date(_TODAY.year, mon, 1)
            off_o, off_d = utc_offset(orig, fdate), utc_offset(dest, fdate)
            if off_o is None or off_d is None:
                duration = 0                     # unknown airport code
            else:
                raw_min = ((ac[0] * 60 + ac[1] - off_d * 60)
                           - (dc[0] * 60 + dc[1] - off_o * 60))
                duration = raw_min + 1440 * shift
                if duration <= 0:
                    duration = raw_min + 1440
            if duration <= 0 or duration > 1700:
                if dist and dist != "0":
                    est = int(dist)
                elif orig in AIRPORTS and dest in AIRPORTS:
                    est = haversine_miles(orig, dest)
                else:
                    est = 0
                duration = estimate_duration_min(est) if est else 0
            seg.flight_time = format_h_mm(duration) if duration else "0.00"
        if not dist:
            if orig in AIRPORTS and dest in AIRPORTS:
                dist = str(int(round(haversine_miles(orig, dest))))
            else:
                dist = "0"
        seg.distance = dist
        segs.append(seg)
    _fill_aircraft(segs)
    return segs


# =====================================================================
# Main parse
# =====================================================================
# =====================================================================
# Hidden-stop merge (v3.2) — same carrier + SAME flight number continuing
# through one airport with a verifiable short ground time is ONE segment
# with hidden stop(s) (GDS convention): the stop becomes a STOP- line,
# not a full segment.   User request: "understand whenever it's a hidden
# stop so we don't add it as a full segment".
# =====================================================================

def _ddmmm_parts(ddmmm):
    """'16NOV' -> (day, month) or None."""
    m = re.match(r"\s*(\d{1,2})\s*([A-Za-z]{3})", ddmmm or "")
    if not m or m.group(2).upper() not in MONTHS:
        return None
    return int(m.group(1)), MONTHS.index(m.group(2).upper()) + 1


def _clock_min(tok):
    """'725P' -> minutes since local midnight (1200A=0, 1200P=720)."""
    m = re.match(r"(\d{1,2})(\d{2})([AP])$", (tok or "").strip())
    if not m:
        return None
    h, mi = int(m.group(1)) % 12, int(m.group(2))
    if m.group(3) == "P":
        h += 12
    return h * 60 + mi


def _ground_minutes(a, b):
    """Minutes b departs after a arrives, proven via UTC offsets.
    None when it cannot be proven (unknown offsets/dates/times)."""
    pa, pb = _ddmmm_parts(a.date_ddmmm), _ddmmm_parts(b.date_ddmmm)
    ca, cb = _clock_min(a.arr_time), _clock_min(b.dep_time)
    if not (pa and pb) or ca is None or cb is None:
        return None
    yr = _TODAY.year
    da = date(yr, pa[1], pa[0])
    db = date(yr, pb[1], pb[0])
    if (pb[1], pb[0]) < (pa[1], pa[0]):      # year turnover (DEC -> JAN)
        db = date(yr + 1, pb[1], pb[0])
    offa = utc_offset(a.dest, da)
    offb = utc_offset(b.orig, db)
    if offa is None or offb is None:
        return None
    arr_utc = a.arr_day_shift * 1440 + ca - offa * 60
    dep_utc = (db - da).days * 1440 + cb - offb * 60
    return dep_utc - arr_utc


def _block_hmm(*times):
    """Sum '7.55'+'8.55' -> '16.50' (H.MM block times). '' if unparsable."""
    tot = 0
    for t in times:
        m = re.match(r"(\d+)\.(\d{2})$", (t or "").strip())
        if not m:
            return ""
        tot += int(m.group(1)) * 60 + int(m.group(2))
    return f"{tot // 60}.{tot % 60:02d}"


def _join_hidden(a, b):
    """Fold leg b into leg a (same through-flight): a becomes origin->final."""
    pa, pb = _ddmmm_parts(a.date_ddmmm), _ddmmm_parts(b.date_ddmmm)
    if pa and pb:
        ord_a = pa[1] * 31 + pa[0]
        ord_b = pb[1] * 31 + pb[0] + b.arr_day_shift
        if ord_b - ord_a < -300:             # year turnover wrap
            ord_b += 372
        a.arr_day_shift = max(0, ord_b - ord_a)
    tot = _block_hmm(a.flight_time, b.flight_time)
    if tot:
        a.flight_time = tot
    dm = haversine_miles(a.orig, b.dest)
    if dm:
        a.distance = str(int(round(dm)))
    if (b.aircraft and a.aircraft and "???" not in (a.aircraft + b.aircraft)
            and a.aircraft != b.aircraft):
        a.warnings.append(f"hidden-stop legs use {a.aircraft} then "
                          f"{b.aircraft} — first leg shown")
    if (b.booking_class and a.booking_class
            and a.booking_class != b.booking_class):
        a.warnings.append(f"class differs on hidden-stop legs "
                          f"({a.booking_class}/{b.booking_class}) — first shown")
    a.warnings.extend(b.warnings)
    a.dest = b.dest
    a.arr_time = b.arr_time


def merge_hidden_stops(segs):
    """Merge same-flight through-legs into single segments (v3.2).

    Conditions for a merge of leg i and i+1: identical airline, identical
    flight number, leg i+1 departs from leg i's arrival airport, and the
    ground time proves out to 0..24h via UTC offsets.  Merged segments are
    renumbered; each hidden stop lands in FlightSegment.hidden_stops and is
    disclosed in a warning (never silent)."""
    if len(segs) < 2:
        return segs
    out = []
    i, n = 0, len(segs)
    while i < n:
        cur = segs[i]
        stops = []
        while (i + 1 < n and cur.flight_no and segs[i + 1].flight_no
               and segs[i + 1].airline == cur.airline
               and (segs[i + 1].flight_no.lstrip("0")
                    == cur.flight_no.lstrip("0"))
               and segs[i + 1].orig == cur.dest):
            nxt = segs[i + 1]
            gap = _ground_minutes(cur, nxt)
            if gap is None or not (0 <= gap <= 24 * 60):
                break
            stops.append(cur.dest)
            _join_hidden(cur, nxt)
            i += 1
        if stops:
            cur.hidden_stops = tuple(stops)
            cur.warnings.append(
                f"hidden stop {' + '.join(stops)} — same flight "
                f"{cur.airline} {cur.flight_no} continues; shown as "
                f"ONE segment (not {len(stops) + 1})")
            cur.warnings = list(dict.fromkeys(cur.warnings))
        out.append(cur)
        i += 1
    for k, s in enumerate(out, 1):
        s.seg = k
    return out


def _parse_core(text):
    """Returns (segments, warnings)."""
    warnings = []
    gds_segs = _try_gds_lines(text)
    if gds_segs:
        gds_segs = merge_hidden_stops(gds_segs)
        gds_warns = [f"S{s.seg}: {w}" for s in gds_segs for w in s.warnings]
        return gds_segs, gds_warns
    anchors = find_anchors(text)
    if not anchors:
        return [], ["No flight anchors (airline + flight number) found. "
                    "Try AI mode for free-form input."]

    g_cabin = None
    m = ALL_CABIN_RE.search(text)
    if m:
        token = m.group(1).upper()
        g_cabin = "PREMIUM ECONOMY" if "PREMIUM" in token else token
    g_cabin_any = None
    for name, rx in CABIN_RES:
        if rx.search(text):
            g_cabin_any = name
            break
    g_class = None
    gm = GLOBAL_CLASS_RE.search(text)
    if gm:
        g_class = gm.group(1).upper()

    n = len(anchors)

    # ---------- preamble split points (multi-flight pastes) ----------
    # Google-Flights multi-leg text is a chain of blocks:
    #   [carrier] [route header "X (AAA) to Y (BBB)"] [date] [anchor] [times]
    # Without splitting the gap between two anchors at the NEXT flight's
    # header, anchor i's window swallows anchor i+1's route+date and both
    # flights get cross-contaminated (wrong route/times, "extra" garbage).
    side_hdrs = find_side_headers(text)

    # Content that means the previous flight's block has ENDED before a
    # header (Google variant: header, times, ANCHOR, aircraft, cabin,
    # layover — the anchor sits mid-block so plain distance guards fail):
    # blank-line separation, or tail material (aircraft / "(9h 50m)" /
    # 'layover' / 'Economy (S)') between the anchor and the header.
    _ACFT_TAIL_RE = re.compile(
        r"\b(airbus|boeing|embraer|bombardier|a3\d\d|a22\d|b7\d7|"
        r"e1\d\d|e19\d|e29\d|crj\d+|atr\d\d)", re.I)
    _STRUCT_TAIL_RE = re.compile(
        r"\(\s*\d{1,2}\s*h\s*(\d{1,2}\s*m\s*)?\)|layover|stopover|"
        r"\b(?:economy|business|first|premium economy|coach)\s*\([A-Z]\)",
        re.I)

    def _preamble_start(i):
        """Where anchor i's own preamble begins inside the gap before it
        (None = keep old behaviour; prose like 'UA 2116\nIAD to DFW departs
        6 PM' has a header directly attached to its anchor and is never
        split off)."""
        ga, gb = anchors[i - 1]["end"], anchors[i]["start"]
        gap = text[ga:gb]
        cands = []

        def header_ok(hpos):
            mid = text[ga:hpos]
            if re.search(r"\n\s*\n", mid):
                return True                    # blank line = block boundary
            if _ACFT_TAIL_RE.search(mid) or _STRUCT_TAIL_RE.search(mid):
                return True                    # prev flight's tail ended
            return abs(gb - hpos) <= abs(hpos - ga)   # header hugs next anchor

        for hpos, _o, _d in side_hdrs:
            if ga <= hpos < gb and header_ok(hpos):
                cands.append(hpos)
        if not cands:
            # headerless chains (truncated Google copy, compact lists...):
            # a date ALONE on its line ("Sat, Sep 12") that is closer to the
            # next anchor marks the start of the next flight's block.
            # Inline dates ("...arrives 8:24 PM on Sep 10, Boeing 737...")
            # are part of a sentence and never start a block.
            LONE_REST = {"", "on", "mon", "monday", "tue", "tues", "tuesday",
                         "wed", "wednesday", "thu", "thur", "thurs",
                         "thursday", "fri", "friday", "sat", "saturday",
                         "sun", "sunday"}
            for rx in DATE_RES[:2]:
                for dm_ in rx.finditer(gap):
                    apos = ga + dm_.start()
                    ls = text.rfind("\n", ga, apos) + 1
                    le = text.find("\n", apos)
                    if le == -1:
                        le = len(text)
                    line = text[ls:le]
                    rel = apos - ls
                    rest = (line[:rel] + line[rel + (dm_.end() - dm_.start()):]
                            ).strip(" \t,|·-–—")
                    if rest.lower() not in LONE_REST:
                        continue                       # inline date -> skip
                    if not (ga < ls and gb - apos < 400
                            and abs(gb - apos) <= abs(apos - ga)):
                        continue
                    cands.append(ls)
        return min(cands) if cands else None

    preambles = {}
    if _ENABLE_SPLIT:
        for i in range(1, n):
            p = _preamble_start(i)
            if p is not None:
                preambles[i] = p

    # ---------- per-anchor side assessment ----------
    # Google-style pasted text puts a flight's data BEFORE its flight-number
    # anchor; prose puts it AFTER. Score both sides and pick the richer one.
    def assess(region, base, anchor_abs):
        o_, d_ = find_airports(region, anchor_abs - base)
        times = find_times(region, base)
        dates = find_dates(region)
        route_pts = 2 if (o_ and d_) else (1 if (o_ or d_) else 0)
        time_pts = 2 if len(times) >= 2 else len(times)
        score = 4 * route_pts + 2 * time_pts + (1 if dates else 0)
        return {"region": region, "base": base, "o": o_, "d": d_,
                "times": times, "dates": dates, "score": score}

    sides = []
    for i, a in enumerate(anchors):
        ws, we = a["end"], (anchors[i + 1]["start"] if i + 1 < n else len(text))
        ps, pe = (anchors[i - 1]["end"] if i > 0 else 0), a["start"]
        if i in preambles:
            ps = preambles[i]              # own header/date starts the block
        if i + 1 in preambles:
            we = preambles[i + 1]          # stop before next flight's header
        sides.append({
            "win": assess(text[ws:we], ws, a["start"]),
            "pre": assess(text[ps:pe], ps, a["start"]),
            "ws": ws, "we": we, "ps": ps, "pe": pe,
        })

    chosen = []
    prev_dest = None
    for i, s in enumerate(sides):
        win, pre = dict(s["win"]), dict(s["pre"])
        wsc, psc = win["score"], pre["score"]
        if prev_dest:                          # chain-consistency bonus
            if win["o"] == prev_dest:
                wsc += 3
            if pre["o"] == prev_dest:
                psc += 3
        sel, oth = (win, pre) if wsc >= psc else (pre, win)
        chosen.append((sel, oth))
        prev_dest = sel["d"] or oth["d"] or prev_dest

    segments = []
    for i, a in enumerate(anchors):
        sel, oth = chosen[i]
        ws, we = sides[i]["ws"], sides[i]["we"]
        ps, pe = sides[i]["ps"], sides[i]["pe"]
        window, pre = text[ws:we], text[ps:pe]
        warn = []

        seg = FlightSegment(seg=i + 1, airline=a["code"],
                            flight_no=str(int(a["num"])))

        # ---------- date ----------
        def best_date(side):
            if not side["dates"]:
                return None
            region = side["region"]

            def on_clock_line(d):
                # inline ARRIVAL date ("5:20 AM on Fri, Dec 11") — belongs to
                # the time, not to the flight block
                ls = region.rfind("\n", 0, d["pos"])
                le = region.find("\n", d["pos"])
                if ls == -1:
                    ls = 0
                if le == -1:
                    le = len(region)
                return bool(TIME_RE.search(region[ls:le]))

            non_inline = [d for d in side["dates"] if not on_clock_line(d)]
            pool = non_inline or side["dates"]
            return sorted(pool,
                          key=lambda d: (d["prio"],
                                         abs(d["pos"] + side["base"] - a["start"])))[0]

        d_sel = best_date(sel)
        d = d_sel or best_date(oth)
        seg_day = seg_mon = None
        # a date from the CHOSEN side is hard evidence; one bleeding in
        # from the discarded side is weak (may be the neighbour's date)
        seg._date_explicit = d_sel is not None
        if d:
            seg_day, seg_mon = d["day"], d["mon"]
            seg.date_ddmmm = make_date(seg_day, seg_mon)
        else:
            seg.date_ddmmm = ""                  # resolved in propagation pass
        flight_date = _TODAY
        if d:
            try:
                flight_date = date(_TODAY.year, d["mon"], min(d["day"], 28))
            except ValueError:
                pass

        # ---------- route ----------
        orig, dest = sel["o"], sel["d"]
        if not orig:
            orig = oth["o"]
        if not dest or dest == orig:
            cand = oth["d"]
            if cand and cand != orig:
                dest = cand
        seg.orig, seg.dest = orig or "", dest or ""
        seg._date_parts = (seg_day, seg_mon)     # for inheritance pass

        # ---------- times ----------
        dep, arr = pick_times(sel["times"], oth["times"])
        if not dep:
            warn.append("departure time missing -> ????")
        if not arr:
            warn.append("arrival time missing -> ????")
        seg.dep_time = fmt_clock(dep["h"], dep["m"]) if dep else "????"
        seg.arr_time = fmt_clock(arr["h"], arr["m"]) if arr else "????"

        # ---------- duration / overnight ----------
        dur_token = (find_duration(sel["region"]) or
                     find_duration(oth["region"]))
        explicit_shift = arr["marker"] if arr and arr["marker"] else None
        # Google renders arrival dates inline: "5:20 AM on Fri, Dec 11".
        # When that stated date is LATER than the segment's date, the
        # overnight marker is explicit (and when it MATCHES, it is not).
        if explicit_shift is None and arr is not None and seg_day:
            line_end = text.find("\n", arr["pos"])
            if line_end == -1:
                line_end = len(text)
            tds = find_dates(text[arr["pos"]:line_end])
            if tds and (tds[0]["mon"], tds[0]["day"]) > (seg_mon, seg_day):
                explicit_shift = 1
        dist_miles = (find_distance(sel["region"]) or
                      find_distance(oth["region"]))
        if dist_miles is None and seg.orig in AIRPORTS and seg.dest in AIRPORTS:
            dist_miles = haversine_miles(seg.orig, seg.dest)

        dep_min = dep["h"] * 60 + dep["m"] if dep else None
        arr_min = arr["h"] * 60 + arr["m"] if arr else None
        shift, duration = 0, None
        if dep_min is not None and arr_min is not None:
            off_o = utc_offset(seg.orig, flight_date) if seg.orig in AIRPORTS else None
            off_d = utc_offset(seg.dest, flight_date) if seg.dest in AIRPORTS else None
            raw = None
            if off_o is not None and off_d is not None:
                raw = (arr_min - off_d * 60) - (dep_min - off_o * 60)
            if dur_token:
                # displayed block duration wins over timezone math
                duration = dur_token
                if explicit_shift is not None:
                    shift = explicit_shift
                elif (raw is not None and raw <= -60) or (raw is None and arr_min < dep_min):
                    shift = 1
            elif explicit_shift is not None:
                shift = explicit_shift
                if raw is not None:
                    duration = raw + 1440 * shift
            elif raw is not None:
                if raw <= 0:
                    shift, duration = 1, raw + 1440
                else:
                    duration = raw
            elif arr_min < dep_min:
                shift = 1
                warn.append("overnight marker assumed (+1)")
        seg.arr_day_shift = min(max(shift, 0), 3)

        if duration is None:
            duration = dur_token
        if duration is None or duration <= 0 or duration > 1700:
            duration = estimate_duration_min(dist_miles)
            if duration:
                warn.append("flight time estimated from distance")
        seg.flight_time = format_h_mm(duration) if duration else "0.00"

        # ---------- distance ----------
        if dist_miles is not None:
            seg.distance = str(int(dist_miles))
        else:
            seg.distance = "0"
            warn.append("distance unknown")

        # ---------- aircraft ----------
        acft = find_aircraft(window) or find_aircraft(pre)
        seg.aircraft = acft or "???"     # "???" resolved by _fill_aircraft below

        # ---------- cabin / class ----------
        cabin, cls = find_cabin_class(window, a["start"] - ws)
        if not (cabin or cls):
            cabin, cls = find_cabin_class(pre, a["start"] - ps)
        seg.cabin = cabin or ""
        seg.booking_class = cls or ""
        seg.warnings = warn
        segments.append(seg)

    # ---------- propagate missing route endpoints + dates ----------
    from datetime import timedelta
    for i, s in enumerate(segments):
        if not s.orig and i > 0 and segments[i - 1].dest != "":
            s.orig = segments[i - 1].dest
        if not s.dest and i + 1 < len(segments) and segments[i + 1].orig:
            s.dest = segments[i + 1].orig
        if not s.date_ddmmm and i > 0:
            pday, pmon = segments[i - 1]._date_parts
            if pday:
                base = date(_TODAY.year, pmon, 1) + timedelta(
                    days=pday - 1 + segments[i - 1].arr_day_shift)
                s.date_ddmmm = make_date(base.day, base.month)
                s._date_parts = (base.day, base.month)
                s.warnings.append("date inherited from previous segment")
    # ---------- date-sequence coherence ----------
    # A connection must be physically possible: each leg departs at/after
    # the previous leg's arrival (times normalised with UTC offsets).
    # Weak dates (inherited/guessed) are auto-corrected; explicit dates are
    # kept but flagged so the warning line shows it.
    from datetime import datetime as _dt, timedelta as _td

    def _abs_min(day, mon, clock, shift, airport):
        # coherence frame: year 2000 (leap) keeps Dec->Jan math sane
        dd = min(day, 29) if mon == 2 else day
        base = _dt(2000, mon, dd, clock[0], clock[1])
        try:
            off = utc_offset(airport, base.date())
        except Exception:
            off = 0
        return base + _td(days=shift) - _td(hours=off)

    for i in range(1, len(segments)):
        p, c = segments[i - 1], segments[i]
        if p.dest == "???" or c.orig != p.dest:
            continue                          # not a real connection
        pdm, cdm = getattr(p, "_date_parts", None), getattr(c, "_date_parts", None)
        if not pdm or not cdm or not pdm[0] or not cdm[0]:
            continue
        pc, cc = _gds_clock(p.arr_time), _gds_clock(c.dep_time)
        if not pc and not cc:
            continue
        arr = _abs_min(pdm[0], pdm[1], pc, p.arr_day_shift, p.dest)
        # year-turnover frame: a leg dated months EARLIER than the previous
        # one is almost always "next calendar year" (Dec 10 -> Jan 3), not
        # an impossible sequence — shift it into the following year
        yr_shift = 0
        if cdm[1] < pdm[1] and (pdm[1] - cdm[1]) >= 2:
            yr_shift = 1
        dep = _abs_min(cdm[0], cdm[1], cc, 0, c.orig) + _td(days=365 * yr_shift)
        if dep >= arr:
            continue
        if not getattr(c, "_date_explicit", False):
            fixed = False
            for bump in (1, 2, 3):
                nb = _dt(2000, cdm[1], min(cdm[0], 29) if cdm[1] == 2 else cdm[0])
                nb = (nb + _td(days=bump)).date()
                plus = 365 if (nb.month < pdm[1] and (pdm[1] - nb.month) >= 2) else 0
                if _abs_min(nb.day, nb.month, cc, 0, c.orig) + _td(days=plus) >= arr:
                    c.date_ddmmm = make_date(nb.day, nb.month)
                    c._date_parts = (nb.day, nb.month)
                    c.warnings.append("date inferred from connection "
                                      "(departure was before previous arrival)")
                    fixed = True
                    break
            if not fixed:
                c.warnings.append("date sequence impossible — verify connection")
        else:
            c.warnings.append("date sequence impossible — verify dates")

    for s in segments:
        if not s.date_ddmmm:
            s.date_ddmmm = "01JAN"
            s.warnings.append("date missing -> 01JAN")
        if not s.orig:
            s.orig = "???"
            s.warnings.append("origin airport unknown")
        if not s.dest:
            s.dest = "???"
            s.warnings.append("destination airport unknown")
        if s.orig != "???" and s.dest != "???" and s.distance in ("0", ""):
            dm = haversine_miles(s.orig, s.dest)
            if dm:
                s.distance = str(dm)

    # ---------- finalize cabin / class ----------
    for s in segments:
        cls = s.booking_class or g_class
        cab = s.cabin or g_cabin or g_cabin_any
        if not cab and cls:
            cab = CLASS_TO_CABIN.get(cls, "ECONOMY")
        if not cab:
            cab = "ECONOMY"
        if not cls:
            cls = CABIN_DEFAULT_CLASS[cab]
        s.cabin, s.booking_class = cab, cls

    _fill_aircraft(segments)

    # ---------- drop exact duplicates ----------
    # Users often hit CONVERT with the same flight pasted twice (e.g. an old
    # block left in the input box above the new paste).  Identical legs are
    # never intentional in one itinerary.
    if _ENABLE_DEDUP:
        seen, uniq = set(), []
        for s in segments:
            key = (s.airline, s.flight_no, s.date_ddmmm, s.orig, s.dest,
                   s.dep_time, s.arr_time)
            if key in seen and s.dep_time != "????":
                warnings.append(f"S{s.seg}: duplicate segment removed "
                                f"({s.airline} {s.flight_no} {s.date_ddmmm})")
                continue
            seen.add(key)
            uniq.append(s)
        segments = uniq
    segments = merge_hidden_stops(segments)
    for idx, s in enumerate(segments, 1):
        s.seg = idx
        warnings.extend(f"S{idx}: {w}" for w in s.warnings)

    return segments, warnings


# =====================================================================
# Never-silent-drops guard (v3.2): a line that LOOKS like a GDS flight
# row (airline + flight no + class + date) but never made it into the
# segments is ALWAYS called out by input line number.  The office's
# 'DL rows 5-6 dropped with no word' bug class ends here.
# =====================================================================
_LOST_ROW_RE = re.compile(
    r"^\s*(?:\d{1,2}\s+)?([A-Z][A-Z0-9]|[0-9][A-Z])\s*(\d{1,4})\s+"
    r"(?:[A-Z]\s+)?\d{1,2}\s*(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)"
    r"\b", re.I)


def sort_chronologically(segs):
    """One-ticket date order (v3.3): segments are emitted chronologically
    (date, then departure clock) and renumbered 1..N, no matter how the
    input rows were grouped/numbered (agents copy legs ticket by ticket).
    Stable sort keeps input order inside equal keys; a DEC...JAN turnover
    keeps DEC first; date-less segments sink to the end unchanged."""
    if len(segs) < 2:
        return segs
    mons = [(_ddmmm_parts(s.date_ddmmm) or (0, 0))[1] for s in segs]
    have = [m for m in mons if m]
    wrap = bool(have) and max(have) - min(have) > 6

    def key(idx_s):
        idx, s = idx_s
        p = _ddmmm_parts(s.date_ddmmm)
        if not p:
            return (10 ** 9, idx)
        d, m = p
        if wrap and m <= 4:
            m += 12
        c = _clock_min(s.dep_time)
        return ((m * 31 + d) * 1440 + (c if c is not None else 0), idx)

    return [s for _, s in sorted(enumerate(segs), key=key)]


def parse(text):
    segs, warns = _parse_core(text)
    segs = sort_chronologically(segs)
    for i, s in enumerate(segs, 1):
        s.seg = i
    have = {(s.airline.upper(), s.flight_no.lstrip("0") or "0")
            for s in segs}
    lost = []
    for ln, line in enumerate(text.splitlines(), 1):
        m = _LOST_ROW_RE.match(line)
        if m and (m.group(1).upper(), m.group(2).lstrip("0") or "0") \
                not in have:
            lost.append(ln)
    if lost:
        warns.append(
            "flight row(s) NOT read — check the times/date on input "
            f"line(s) {', '.join(str(x) for x in lost[:6])}: output has "
            "NONE of them; fix the text or press ✦ AI to fill them")
    return segs, warns
