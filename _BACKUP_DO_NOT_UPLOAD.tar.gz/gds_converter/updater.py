"""
updater.py — self-update for SpicyTerminal ("super smart, while connected
to internet").

How it works:
  * The app fetches a tiny JSON manifest from UPDATE_MANIFEST_URL
    (default points at Lamar's own domain — bcflights.com — so the office
    controls releases, not some third party):

        {
          "version": "2.3",
          "url": "https://bcflights.com/spicyterminal/SpicyTerminal.exe",
          "sha256": "<hex of the exe>",          (optional but used if given)
          "notes": "what's new, one line"
        }

  * check() compares versions. install_update() downloads the new exe,
    verifies the sha256 (million-percent-accurate: a corrupt/partial
    download is NEVER installed), then swaps it in with a tiny helper
    .bat that waits for this process to exit, replaces the exe and
    relaunches — the classic Windows self-update.

Everything network-related is isolated in _fetch/_download so tests can
run fully offline by monkeypatching those two functions.
"""

import hashlib
import json
import os
import re
import subprocess  # nosec - helper bat spawn only
import sys
import tempfile

# Office release point (Lamar's domain). Can be overridden in Settings
# (saved as "update_url" in the config).
DEFAULT_MANIFEST_URL = "https://bcflights.com/spicyterminal/version.json"


class UpdateError(Exception):
    pass


def parse_ver(text):
    """'2.10' -> (2, 10). Anything that isn't .-separated numbers -> (0,)."""
    parts = re.findall(r"\d+", str(text or ""))
    return tuple(int(p) for p in parts) if parts else (0,)


def _pad(a, b):
    n = max(len(a), len(b))
    return a + (0,) * (n - len(a)), b + (0,) * (n - len(b))


def version_newer(new, current):
    a, b = _pad(parse_ver(new), parse_ver(current))
    return a > b


def _fetch(url, timeout=10):
    import requests
    r = requests.get(url, timeout=timeout,
                     headers={"User-Agent": "SpicyTerminal-Updater"})
    if r.status_code != 200:
        raise UpdateError(f"HTTP {r.status_code} from update server")
    return r.json()


def validate_manifest(data):
    """Returns (version, url, sha256, notes) or raises UpdateError."""
    if not isinstance(data, dict):
        raise UpdateError("manifest is not a JSON object")
    ver = str(data.get("version", "")).strip()
    url = str(data.get("url", "")).strip()
    if not ver or not parse_ver(ver) or parse_ver(ver) == (0,):
        raise UpdateError("manifest has no usable 'version'")
    if url and not url.lower().startswith(("http://", "https://")):
        raise UpdateError("manifest 'url' is not http(s)")
    sha = str(data.get("sha256", "")).strip().lower()
    if sha and not re.fullmatch(r"[0-9a-f]{64}", sha):
        raise UpdateError("manifest 'sha256' is malformed")
    notes = str(data.get("notes", "")).strip()
    return ver, url, sha, notes


def check(current_version, url=None, timeout=10):
    """Ask the release point what's current.
    Returns dict(status, manifest, error):
      status: 'newer' | 'latest' | 'unavailable' | 'bad'
    """
    murl = (url or DEFAULT_MANIFEST_URL).strip()
    try:
        data = _fetch(murl, timeout=timeout)
    except Exception as e:
        return {"status": "unavailable", "manifest": None,
                "error": str(e), "url": murl}
    try:
        ver, dl, sha, notes = validate_manifest(data)
    except UpdateError as e:
        return {"status": "bad", "manifest": None, "error": str(e),
                "url": murl}
    man = {"version": ver, "url": dl, "sha256": sha, "notes": notes}
    return {"status": "newer" if version_newer(ver, current_version)
            else "latest", "manifest": man, "error": "", "url": murl}


def _download(url, dest, on_progress=None, timeout=60):
    import requests
    with requests.get(url, stream=True, timeout=timeout,
                      headers={"User-Agent": "SpicyTerminal-Updater"}) as r:
        if r.status_code != 200:
            raise UpdateError(f"download failed: HTTP {r.status_code}")
        total = int(r.headers.get("Content-Length") or 0)
        got = 0
        with open(dest, "wb") as f:
            for chunk in r.iter_content(chunk_size=262144):
                if not chunk:
                    continue
                f.write(chunk)
                got += len(chunk)
                if on_progress and total:
                    on_progress(min(100, int(got * 100 / total)))
    return dest


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(262144), b""):
            h.update(chunk)
    return h.hexdigest()


def install_update(manifest, on_progress=None):
    """Download + verify + schedule the swap. Returns the new exe path.
    Raises UpdateError on any mismatch — NEVER installs a bad file."""
    dl = manifest.get("url")
    if not dl:
        raise UpdateError("this release has no download URL in the manifest")
    fd, tmp_path = tempfile.mkstemp(prefix="spicy_update_", suffix=".exe")
    os.close(fd)
    try:
        _download(dl, tmp_path, on_progress=on_progress)
        # sanity: must look like a Windows exe, and match the pinned hash
        with open(tmp_path, "rb") as f:
            if f.read(2) != b"MZ":
                raise UpdateError("downloaded file is not a Windows .exe")
        want = (manifest.get("sha256") or "").lower()
        got = sha256_of(tmp_path)
        if want and got != want:
            raise UpdateError(
                f"checksum mismatch (expected {want[:12]}…, got "
                f"{got[:12]}…) — download rejected")
        if not getattr(sys, "frozen", False):
            # running from source — can't hot-swap, hand the file over
            keep = os.path.join(os.path.expanduser("~"),
                                f"SpicyTerminal_v{manifest['version']}.exe")
            os.replace(tmp_path, keep)
            return keep
        current = os.path.abspath(sys.executable)
        staging = current + ".new"
        os.replace(tmp_path, staging)
        _schedule_swap_and_exit(staging, current)
        return staging
    except Exception:
        try:
            os.remove(tmp_path)
        except OSError:
            pass
        raise


def build_bat_preview(new_exe, current_exe, pid=1234):
    """Exact .bat body the installer writes — exposed for tests."""
    bat = os.path.join(tempfile.gettempdir(), "spicy_self_update.bat")
    return (
        "@echo off\r\n"
        "setlocal\r\n"
        f"set \"NEW={new_exe}\"\r\n"
        f"set \"CUR={current_exe}\"\r\n"
        ":wait\r\n"
        f"tasklist /FI \"PID eq {pid}\" | find \" {pid} \" >nul\r\n"
        "if %errorlevel%==0 (timeout /t 1 /nobreak >nul & goto wait)\r\n"
        "move /y \"%NEW%\" \"%CUR%\" >nul\r\n"
        "start \"\" \"%CUR%\"\r\n"
        f"del \"{bat}\"\r\n")


def _schedule_swap_and_exit(new_exe, current_exe):
    """Spawn a detached helper .bat that waits for THIS process to die,
    moves the new exe over the old one and relaunches it."""
    bat = os.path.join(tempfile.gettempdir(), "spicy_self_update.bat")
    with open(bat, "w", encoding="ascii", errors="ignore") as f:
        f.write(build_bat_preview(new_exe, current_exe, os.getpid()))
    DETACHED = 0x00000008 | 0x00000200  # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
    subprocess.Popen(["cmd", "/c", bat], creationflags=DETACHED,
                     close_fds=True)
