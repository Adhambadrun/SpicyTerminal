"""
ai_engine.py — Sends flight data (text and/or screenshots) to an AI
provider using the master system prompt, and extracts the itinerary
code block from the response.

FREE providers (no credit card required) come first:
  * Google Gemini  — free tier from aistudio.google.com, READS SCREENSHOTS
  * Groq           — free tier, OpenAI-compatible, open-source models (text)
  * OpenRouter     — free ":free" models, OpenAI-compatible (text)
Plus the paid classics: Anthropic (Claude) and OpenAI (GPT).
"""

import base64
import re
import time

from system_prompt import (MASTER_SYSTEM_PROMPT, USER_TASK_TEMPLATE,
                           USER_TASK_IMAGE_ONLY)


def _sleep(seconds):
    """Module-level indirection so tests can disable backoff waits."""
    time.sleep(seconds)

PROVIDERS = {
    "Google Gemini (FREE)": {
        "id": "gemini",
        "default_model": "gemini-3-flash-preview",
        "vision": True,
        "key_hint": "AIza...",
        "key_url": "https://aistudio.google.com/app/apikey",
        "free_note": ("FREE TIER - no credit card. Built-in key included. "
                      "Reads screenshots (vision)."),
    },
    "Groq (FREE)": {
        "id": "groq",
        "default_model": "qwen/qwen3.6-27b",
        "vision": False,
        "key_hint": "gsk_...",
        "key_url": "https://console.groq.com/keys",
        "free_note": ("FREE TIER - no credit card. Built-in key included. "
                      "Very fast, text only. Small per-minute token "
                      "budget: use for short snippets; use Gemini for "
                      "big pastes/screenshots."),
    },
    "OpenRouter (FREE models)": {
        "id": "openrouter",
        "default_model": "openai/gpt-oss-20b:free",
        "vision": False,
        "key_hint": "sk-or-...",
        "key_url": "https://openrouter.ai/keys",
        "free_note": ("FREE ':free' models. Built-in key included. "
                      "Text only on free tier."),
    },
    "Anthropic (Claude)": {
        "id": "anthropic",
        "default_model": "claude-sonnet-5",
        "vision": True,
        "key_hint": "sk-ant-...",
        "key_url": "https://console.anthropic.com/settings/keys",
        "free_note": "Paid. Top accuracy on messy input and screenshots.",
    },
    "OpenAI (GPT)": {
        "id": "openai",
        "default_model": "gpt-5",
        "vision": True,
        "key_hint": "sk-...",
        "key_url": "https://platform.openai.com/api-keys",
        "free_note": "Paid. Top accuracy on messy input and screenshots.",
    },
}

# Built-in default keys (office build) — used automatically when no personal
# key is saved in Settings. A saved personal key always overrides these.
DEFAULT_KEYS = {
    "gemini": "AQ.Ab8RN6L5hjXIsusM05HBZS5ZpcNeAvB6w9x6pAL8DWDccjboDw",
    "openai": ("sk-proj-g-nFs8H4JjLaUx3u9bKnqqkXZKCZ_j8e1vanOxx_32UUgr1zhCk"
               "ItSpABKcrX5YCt6QsIE4_pQT3BlbkFJmMPN5iHoQwIv9VUznVCDoap_p-Ec--"
               "YnM17-x03abaYIdm_euLFEKpeqUG_FTF3e7VZ9nnra8A"),
    "groq": "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",
    "openrouter": ("sk-or-v1-179112301d6c269804ed5cf23b835dc7c2983f92bfcd1d78"
                   "a811a4ca12cc8a8b"),
}

_PROVIDER_BY_ID = {v["id"]: v for v in PROVIDERS.values()}

# OpenAI-compatible endpoints (chat completions, Bearer auth)
_OA_BASES = {
    "openai": "https://api.openai.com/v1/chat/completions",
    "groq": "https://api.groq.com/openai/v1/chat/completions",
    "openrouter": "https://openrouter.ai/api/v1/chat/completions",
}


class AIError(Exception):
    pass


def key_for(provider_id, saved_key=""):
    """Personal saved key wins; otherwise fall back to the built-in default."""
    if saved_key and saved_key.strip():
        return saved_key.strip()
    return DEFAULT_KEYS.get(provider_id, "")


def has_default_key(provider_id):
    return bool(DEFAULT_KEYS.get(provider_id))


def supports_vision(provider_id):
    info = _PROVIDER_BY_ID.get(provider_id, {})
    return bool(info.get("vision"))


def default_model_for(provider_id):
    info = _PROVIDER_BY_ID.get(provider_id, {})
    return info.get("default_model", "")


def clean_model_name(model):
    """The Settings MODEL box is free-text and users paste junk into it:
    'models/gemini-3-flash-preview' (Google docs show the models/ prefix),
    trailing newlines, inner spaces. Strip all of that — the raw junk is
    what produces 'GenerateContentRequest.model: unexpected model name
    format' (HTTP 400) from Gemini."""
    m = (model or "").strip()
    if m.lower().startswith("models/"):
        m = m[len("models/"):]
    m = re.sub(r"\s+", "", m)
    return m.strip("`'\".,;")


_MODEL_ERR_HINTS = ("unexpected model name", "404", "not found", "no model",
                    "does not exist", "invalid model", "unknown model",
                    "unavailable")

# ---- resilience (v2.1) -------------------------------------------------
# Transient = worth retrying the same engine after a short wait, and then
# worth moving on to the next engine that has a key. The Gemini HTTP 503
# "high demand" spike the office kept hitting is exactly this class.
_TRANSIENT_HINTS = ("503", "502", "500", "429", "high demand",
                    "spikes in demand", "overloaded", "temporarily",
                    "try again", "rate limit", "rate_limit",
                    "resource exhausted", "timed out", "timeout",
                    "network error", "connection")

# Errors that will never heal by retrying the same engine/payload
# (e.g. Groq 413 request-too-large on its small per-minute token budget) —
# skip straight to the next engine.
_SKIP_HINTS = ("413", "too large", "content too large")

_FAILOVER_ORDER = ["gemini", "openrouter", "groq", "anthropic", "openai"]

_TRIES_MAIN = 3      # attempts on the engine the user selected
_TRIES_BACKUP = 2    # attempts per backup engine

_SHORT_NAMES = {"anthropic": "Claude", "openai": "OpenAI",
                "gemini": "Gemini", "groq": "Groq",
                "openrouter": "OpenRouter"}


def _short(pid):
    return _SHORT_NAMES.get(pid, (pid or "?").title())


def _status(cb, msg):
    if cb:
        try:
            cb(msg)
        except Exception:
            pass


class AIResult(str):
    """The itinerary text, plus metadata about how it was produced
    (which engine actually answered, how many attempts, and which engines
    failed before it — so the UI can say 'Gemini down → auto-switched')."""

    def __new__(cls, text, provider, model, attempts=1, failover_from=None):
        obj = super().__new__(cls, text)
        obj.provider = provider
        obj.model = model
        obj.attempts = attempts
        obj.failover_from = list(failover_from or [])
        return obj

    @property
    def failover(self):
        return bool(self.failover_from)


def strip_fences(text):
    """Extract code-block content(s) from an AI response."""
    blocks = re.findall(r"```[^\n]*\n(.*?)```", text, re.S)
    if blocks:
        return "\n\n".join(b.strip("\n") for b in blocks)
    return text.strip()


def convert(text, images, provider_id, api_key, model=None, timeout=180,
            on_status=None, key_resolver=None):
    """
    text         : str (may be empty if images provided)
    images       : list of JPEG/PNG bytes (may be empty)
    on_status    : optional callback(str) for live progress ("Gemini busy —
                   retrying…", "…→ trying OpenRouter…")
    key_resolver : optional callable(provider_id) -> api key. When given,
                   enables automatic FAILOVER: if the selected engine keeps
                   failing (overload 503, quota 429, outage, bad key…), every
                   other engine with a key is tried in _FAILOVER_ORDER.

    Returns an AIResult (a str subclass: the itinerary with .provider,
    .model, .attempts and .failover_from metadata attached).
    """
    def _any_key():
        return key_resolver and any(key_resolver(p)
                                    for p in _FAILOVER_ORDER)

    if not api_key and not _any_key():
        raise AIError("No API key configured. Open ⚙ settings to add one — "
                      "Gemini / Groq / OpenRouter all offer FREE keys, no card "
                      "needed.")
    if not text.strip() and not images:
        raise AIError("Nothing to convert: paste text or attach a screenshot.")
    if images and not supports_vision(provider_id):
        raise AIError(
            f"The selected provider ({provider_id}) is text-only and cannot "
            "read screenshots. Switch to Google Gemini (FREE) in Settings, "
            "or paste the flight text instead.")

    custom = clean_model_name(model)

    def _dispatch(pid, key, m):
        if pid == "anthropic":
            return _call_anthropic(text, images, key, m, timeout)
        if pid == "gemini":
            return _call_gemini(text, images, key, m, timeout)
        if pid in _OA_BASES:
            return _call_openai_compatible(text, images, key, m, timeout,
                                           base=_OA_BASES[pid],
                                           provider_name=pid)
        raise AIError(f"Unknown provider: {pid}")

    # Engine chain: the user's choice first, then every backup with a key.
    chain = [provider_id]
    if key_resolver:
        for pid in _FAILOVER_ORDER:
            if pid == provider_id or pid in chain:
                continue
            if images and not supports_vision(pid):
                continue          # can't send screenshots to a text-only engine
            if key_resolver(pid):
                chain.append(pid)

    failures, failed_ids, total_attempts = [], [], 0

    for ci, pid in enumerate(chain):
        key = api_key if pid == provider_id else (key_resolver(pid) or "")
        if not key:
            failures.append(f"{_short(pid)}: no key")
            continue
        default = default_model_for(pid)
        # a custom model name only ever applies to the selected engine
        m = custom if (pid == provider_id and custom) else default
        tries = _TRIES_MAIN if ci == 0 else _TRIES_BACKUP
        rescued = False
        attempt = 0
        while attempt < tries:
            attempt += 1
            total_attempts += 1
            try:
                raw = _dispatch(pid, key, m)
            except AIError as e:
                em = str(e).lower()
                # auto-rescue: a mangled custom model name gets one free
                # retry with the provider's built-in default model
                if (pid == provider_id and custom and custom != default
                        and default and not rescued
                        and any(k in em for k in _MODEL_ERR_HINTS)):
                    rescued = True
                    m = default
                    attempt -= 1
                    continue
                transient = any(k in em for k in _TRANSIENT_HINTS)
                if (transient and attempt < tries
                        and not any(k in em for k in _SKIP_HINTS)):
                    delay = min(2 * attempt, 5)
                    _status(on_status,
                            f"{_short(pid).upper()} busy ({str(e)[:60]}…) — "
                            f"retrying in {delay}s ({attempt + 1}/{tries})")
                    _sleep(delay)
                    continue
                failures.append(f"{_short(pid)}: {str(e)[:200]}"
                                + (f" (tried {attempt}×)" if attempt > 1
                                   else ""))
                failed_ids.append(pid)
                break
            if not raw or not strip_fences(raw).strip():
                failures.append(f"{_short(pid)}: empty response")
                failed_ids.append(pid)
                break
            if pid != provider_id:
                _status(on_status,
                        f"{_short(provider_id).upper()} unavailable → "
                        f"{_short(pid).upper()} answered ✓")
            return AIResult(strip_fences(raw), provider=pid, model=m,
                            attempts=total_attempts,
                            failover_from=failed_ids)
        if pid != provider_id and attempt:
            _status(on_status, f"{_short(pid).upper()} failed too — "
                               "trying next engine…")

    raise AIError("Every AI engine failed — " + "  |  ".join(failures))


def _user_payload(text, images):
    if text.strip():
        note = ""
        if images:
            note = (" (screenshot(s) also attached — include ALL flights "
                    "from both the text and the images)")
        return USER_TASK_TEMPLATE.format(img_note=note, payload=text.strip())
    return USER_TASK_IMAGE_ONLY


def _media(img_bytes):
    return "image/png" if img_bytes[:8] == b"\x89PNG\r\n\x1a\n" else "image/jpeg"


# ---------------------------------------------------------------------
# Anthropic
# ---------------------------------------------------------------------
def _call_anthropic(text, images, api_key, model, timeout):
    import requests

    content = [{
        "type": "image",
        "source": {"type": "base64", "media_type": _media(b),
                   "data": base64.b64encode(b).decode()},
    } for b in images]
    content.append({"type": "text", "text": _user_payload(text, images)})

    try:
        r = requests.post(
            "https://api.anthropic.com/v1/messages",
            headers={"x-api-key": api_key.strip(),
                     "anthropic-version": "2023-06-01",
                     "content-type": "application/json"},
            json={"model": model, "max_tokens": 8192,
                  "system": MASTER_SYSTEM_PROMPT,
                  "messages": [{"role": "user", "content": content}]},
            timeout=timeout)
    except AIError:
        raise
    except Exception as e:
        raise AIError(f"Network error calling Anthropic: {e}")

    if r.status_code != 200:
        msg = ""
        try:
            msg = r.json().get("error", {}).get("message", "")
        except Exception:
            pass
        raise AIError(f"Anthropic HTTP {r.status_code}: {msg or r.text[:300]}")

    try:
        data = r.json()
        parts = [b.get("text", "") for b in data.get("content", [])
                 if b.get("type") == "text"]
        return "\n".join(p for p in parts if p).strip()
    except Exception as e:
        raise AIError(f"Could not parse Anthropic response: {e}")


# ---------------------------------------------------------------------
# Google Gemini (generateContent, x-goog-api-key header, native images)
# ---------------------------------------------------------------------
def _call_gemini(text, images, api_key, model, timeout):
    import requests

    parts = [{"inline_data": {"mime_type": _media(b),
                              "data": base64.b64encode(b).decode()}}
             for b in images]
    parts.append({"text": _user_payload(text, images)})

    url = (f"https://generativelanguage.googleapis.com/v1beta/models/"
           f"{model}:generateContent")
    try:
        r = requests.post(
            url,
            headers={"x-goog-api-key": api_key.strip(),
                     "Content-Type": "application/json"},
            json={"systemInstruction": {"parts": [{"text": MASTER_SYSTEM_PROMPT}]},
                  "contents": [{"role": "user", "parts": parts}],
                  "generationConfig": {"maxOutputTokens": 8192,
                                       "temperature": 0.1}},
            timeout=timeout)
    except Exception as e:
        raise AIError(f"Network error calling Gemini: {e}")

    if r.status_code != 200:
        msg = ""
        try:
            msg = r.json().get("error", {}).get("message", "")
        except Exception:
            pass
        raise AIError(f"Gemini HTTP {r.status_code}: {msg or r.text[:300]}")

    try:
        data = r.json()
        parts_out = (data["candidates"][0]["content"]["parts"])
        texts = [p.get("text", "") for p in parts_out if "text" in p]
        return "\n".join(t for t in texts if t).strip()
    except Exception as e:
        raise AIError(f"Could not parse Gemini response: {e}")


# ---------------------------------------------------------------------
# OpenAI-compatible (OpenAI, Groq, OpenRouter)
# ---------------------------------------------------------------------
def _call_openai_compatible(text, images, api_key, model, timeout,
                            base, provider_name):
    import requests

    content = []
    for b in images:
        content.append({
            "type": "image_url",
            "image_url": {"url": f"data:{_media(b)};base64,"
                          + base64.b64encode(b).decode()}})
    content.append({"type": "text", "text": _user_payload(text, images)})

    headers = {"Authorization": f"Bearer {api_key.strip()}",
               "Content-Type": "application/json"}
    if provider_name == "openrouter":
        headers["HTTP-Referer"] = "https://spicyterminal.local"
        headers["X-Title"] = "SpicyTerminal"

    payload = {"model": model,
               "messages": [{"role": "system", "content": MASTER_SYSTEM_PROMPT},
                            {"role": "user", "content": content}]}
    if provider_name == "openai":
        payload["max_completion_tokens"] = 8192
    else:
        payload["max_tokens"] = 8192

    try:
        r = requests.post(base, headers=headers, json=payload, timeout=timeout)
    except Exception as e:
        raise AIError(f"Network error calling {provider_name.title()}: {e}")

    if r.status_code != 200:
        msg = ""
        try:
            msg = r.json().get("error", {}).get("message", "")
        except Exception:
            pass
        raise AIError(
            f"{provider_name.title()} HTTP {r.status_code}: {msg or r.text[:300]}")

    try:
        data = r.json()
        return (data["choices"][0]["message"]["content"] or "").strip()
    except Exception as e:
        raise AIError(f"Could not parse {provider_name.title()} response: {e}")


# ---------------------------------------------------------------------
# Built-in key validation ("check your key" button)
# ---------------------------------------------------------------------
def test_key(provider_id, api_key, model=None):
    """Cheap connectivity check (~a few tokens). Returns (ok, message)."""
    if not api_key or not api_key.strip():
        return False, "no key"
    model = clean_model_name(model) or default_model_for(provider_id)
    try:
        import requests
    except ImportError:
        return False, "requests pkg missing"

    try:
        if provider_id == "anthropic":
            r = requests.post(
                "https://api.anthropic.com/v1/messages",
                headers={"x-api-key": api_key.strip(),
                         "anthropic-version": "2023-06-01",
                         "content-type": "application/json"},
                json={"model": model, "max_tokens": 8,
                      "messages": [{"role": "user", "content": "Reply: OK"}]},
                timeout=30)
            return r.status_code == 200, f"HTTP {r.status_code}"

        if provider_id == "gemini":
            r = requests.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/"
                f"{model}:generateContent",
                headers={"x-goog-api-key": api_key.strip(),
                         "Content-Type": "application/json"},
                json={"contents": [{"role": "user",
                                    "parts": [{"text": "Reply: OK"}]}],
                      "generationConfig": {"maxOutputTokens": 32}},
                timeout=30)
            return r.status_code == 200, f"HTTP {r.status_code}"

        if provider_id in _OA_BASES:
            headers = {"Authorization": f"Bearer {api_key.strip()}",
                       "Content-Type": "application/json"}
            if provider_id == "openrouter":
                headers["HTTP-Referer"] = "https://spicyterminal.local"
                headers["X-Title"] = "SpicyTerminal"
            if provider_id == "openai":
                payload = {"model": model, "max_completion_tokens": 16,
                           "messages": [{"role": "user", "content": "Reply: OK"}]}
            else:
                payload = {"model": model, "max_tokens": 16,
                           "messages": [{"role": "user", "content": "Reply: OK"}]}
            r = requests.post(_OA_BASES[provider_id], headers=headers,
                              json=payload, timeout=30)
            return r.status_code == 200, f"HTTP {r.status_code}"

        return False, f"unknown provider {provider_id}"
    except Exception as e:
        return False, str(e)
