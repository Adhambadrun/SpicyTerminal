"""
tests.py — self-contained engine test suite (no pytest needed).

Run:  python tests.py
Every check prints PASS/FAIL; exit code 0 means all green.
"""

import re
import sys

import parser_offline as P
import formatter as F
import ai_engine as A
from aviation_data import (lookup_aircraft, haversine_miles, utc_offset,
                           estimate_duration_min, AIRCRAFT, AIRPORTS)


results = []


def check(name, cond, detail=""):
    results.append((name, bool(cond), detail))
    print(("PASS  " if cond else "FAIL  ") + name + (f"  [{detail}]" if detail and not cond else ""))


def parse1(text):
    segs, warns = P.parse(text)
    return segs, warns, F.render_itinerary(segs) if segs else ""


# =====================================================================
# 1. Clock formatting (spec Field 7)
# =====================================================================
for (h, m), exp in {
    (0, 0): "1200A", (0, 30): "1230A", (12, 0): "1200P", (1, 0): "100A",
    (13, 0): "100P", (9, 5): "905A", (23, 59): "1159P", (12, 55): "1255P",
    (18, 30): "630P", (6, 5): "605A", (11, 15): "1115A",
}.items():
    check(f"fmt_clock {h:02d}:{m:02d} -> {exp}", F.fmt_clock(h, m) == exp)

# =====================================================================
# 2. Aircraft table (spec Field 10)
# =====================================================================
AC_CASES = {
    "Boeing 737 MAX 8": "7M8", "Boeing 737 MAX 10": "7MJ",
    "Boeing 737-800": "738", "Boeing 737-900ER": "739",
    "Boeing 747-8": "748", "Boeing 767-300ER": "76W",
    "Boeing 767-400ER": "764", "Boeing 777-200LR": "77L",
    "Boeing 777-300ER": "77W", "Boeing 777-9": "779",
    "Boeing 787-9": "789", "Boeing 787-10": "781",
    "Airbus A350-900": "359", "Airbus A350-1000": "35K",
    "Airbus A380-800": "388", "Airbus A321neo": "32Q",
    "Airbus A321XLR": "32Q", "Airbus A320neo": "32N",
    "Airbus A330-900neo": "339", "Airbus A220-300": "223",
    "Embraer 175": "E75", "Embraer E195-E2": "295",
    "CRJ-900": "CR9", "Dash 8 Q400": "DH4", "ATR 72": "AT7",
    "Cessna Grand Caravan": "CN1", "BaE 146": "146",
}
ok = all(lookup_aircraft(k) == v for k, v in AC_CASES.items())
bad = {k: lookup_aircraft(k) for k, v in AC_CASES.items() if lookup_aircraft(k) != v}
check("aircraft table 26 lookups", ok, str(bad))

# =====================================================================
# 3. Master prompt example 1
# =====================================================================
segs, warns, out = parse1(
    "Qatar Airways QR 704, Jan 15, departs JFK 9:30 PM, arrives DOH 5:20 PM+1, "
    "Airbus A350-900, then QR 812, Jan 16, departs DOH 7:15 AM, arrives CMB "
    "3:30 PM, Boeing 787-8. Business class, booking class I.")
s1, s2 = segs
check("EX1 two segments", len(segs) == 2)
check("EX1 s1 anchor", (s1.airline, s1.flight_no, s1.date_ddmmm) == ("QR", "704", "15JAN"))
check("EX1 s1 route", (s1.orig, s1.dest) == ("JFK", "DOH"))
check("EX1 s1 times+marker", s1.dep_time == "930P" and s1.arr_time == "520P" and s1.arr_day_shift == 1)
check("EX1 s1 class I kept / cabin", s1.booking_class == "I" and s1.cabin == "BUSINESS")
check("EX1 s1 aircraft", s1.aircraft == "359")
check("EX1 s2 anchor", (s2.airline, s2.flight_no, s2.date_ddmmm) == ("QR", "812", "16JAN"))
check("EX1 s2 no marker", s2.arr_day_shift == 0)
check("EX1 additional section", "1 QR 704I 15JAN" in out and "2 QR 812I 16JAN" in out)
check("EX1 ends correctly", out.rstrip().endswith("2 QR 812I 16JAN"))
check("EX1 14-token lines", all(len(l.split()) == 13 for l in out.split("\n") if l.endswith(" N")))
check("EX1 QC silent", not F.qc_check(out, segs))

# =====================================================================
# 4. Field edge cases
# =====================================================================
# red-eye +1
segs, _, out = parse1("AA 100 JFK LAX dep 11:30 PM arr 2:15 AM+1, Boeing 737-800, economy")
check("red-eye marker", segs[0].arr_day_shift == 1 and out.splitlines()[0].split()[7] == "215A¥1")

# explicit +2 preserved
segs, _, out = parse1("SQ 22 01JUN SIN SYD dep 8:45 AM arr 7:20 PM+2 A350-900, premium economy")
check("explicit +2", segs[0].arr_day_shift == 2 and "720P¥2" in out)
check("premium economy default W", segs[0].cabin == "PREMIUM ECONOMY" and segs[0].booking_class == "W")

# duplicate flight numbers, different dates
segs, _, out = parse1("Emirates EK 101 Jan 5 DXB LHR dep 2:30 AM arr 6:30 AM. Return EK 101 Jan 6 DXB LHR dep 2:30 AM arrives 6:30 AM. Boeing 777-300ER economy.")
check("duplicate flight kept twice", len(segs) == 2 and segs[0].date_ddmmm == "05JAN" and segs[1].date_ddmmm == "06JAN")

# noon / midnight conversions
segs, _, _ = parse1("MS 777 15MAR CAI DXB departs 12:00 PM arrives 5:05 PM, 737-800")
check("noon -> 1200P", segs[0].dep_time == "1200P")
segs, _, _ = parse1("MS 777 15MAR CAI DXB departs 00:30 arrives 4:05 AM, 737-800")
check("midnight 00:30 -> 1230A", segs[0].dep_time == "1230A")

# slash date disambiguation
segs, _, _ = parse1("EK 924 on 20/03/2026 CAI DXB 12:50 PM - 6:10 PM Y 77W")
check("slash date 20/03 -> 20MAR", segs[0].date_ddmmm == "20MAR")

# ordinal date
segs, _, _ = parse1("BA 179 March 9th JFK LHR 6:30 PM to 6:15 AM+1, 777-200, first")
check("ordinal March 9th -> 09MAR", segs[0].date_ddmmm == "09MAR")
check("first default F", segs[0].booking_class == "F" and segs[0].cabin == "FIRST")

# explicit class letter never overridden
segs, _, _ = parse1("DL 1 JFK LHR 10MAR 7:00 PM - 7:00 AM+1 767-400ER business class O")
check("class O preserved w/ BUSINESS cabin", segs[0].booking_class == "O" and segs[0].cabin == "BUSINESS")

# letter-only class derives cabin
segs, _, _ = parse1("UA 100 05MAY JFK SFO 8:00 AM - 11:30 AM booking class J")
check("class J derives BUSINESS cabin", segs[0].booking_class == "J" and segs[0].cabin == "BUSINESS")

# all business global
segs, _, out = parse1("TK 2 20JAN IST JFK 130A 550A 77W. TK 1 27JAN JFK IST 1030P 510P¥1 359. All business.")
check("all business -> C both", all(s.booking_class == "C" and s.cabin == "BUSINESS" for s in segs))

# codeshare marketing carrier
segs, _, out = parse1("Qatar Airways QR 8112 operated by Royal Air Maroc Nov 3 DOH CMN 8:00 AM - 1:30 PM 787-9 economy")
check("codeshare -> QR not AT", segs[0].airline == "QR" and out.split()[1] == "QR")

# city names only
segs, _, _ = parse1("Emirates 800 on June 4 from Cairo to Dubai leaves 4:25 PM gets in 9:35 PM")
check("cities -> CAI DXB", (segs[0].orig, segs[0].dest) == ("CAI", "DXB"))

# 24-hour input
segs, _, _ = parse1("EgyptAir flight MS 777 on 2026-03-15, departing Cairo (CAI) at 09:40 and arriving Dubai (DXB) at 15:05. Boeing 737-800. Economy.")
check("24h times converted", segs[0].dep_time == "940A" and segs[0].arr_time == "305P")

# missing aircraft -> inferred (output never shows ???, v2.5)
segs, warns, out = parse1("MS 40 03DEC CAI SSH 6:00 AM - 7:05 AM economy")
check("missing aircraft -> inferred 738, not ???", segs[0].aircraft == "738")
check("inference disclosed in warnings", any("aircraft inferred" in w for w in warns))
check("no ??? in output ever", "???" not in out)

# garbage -> no segments, no crash
segs, warns = P.parse("hello this is not a flight at all")
check("garbage input -> 0 segments", segs == [] and warns)

# spacing rule: exactly one space everywhere on flight lines
segs, _, out = parse1("QR 704 15JAN JFK DOH 930P 520P¥1 I 359 business")
check("no double spaces", "  " not in out)

# additional section formatting (GDS row: class I preserved verbatim per spec)
check("additional line format", bool(re.search(r"\n1 QR 704I 15JAN\n?$", out)))

# =====================================================================
# 6b. GDS-format fast path (paste-from-black-window; reported bug: empty output)
# =====================================================================
GDS_IN = """1 UA    1 13DEC SFO SIN 1040P    800A¥2 D    789 17.20  8446  N
DEP-I                                  ARR-2
STAR
CABIN-BUSINESS"""
GDS_EXP = """1 UA 1 13DEC SFO SIN 1040P 800A¥2 D 789 17.20 8446 N
DEP-SAN FRANCISCO INTL
ARR-SINGAPORE CHANGI
CABIN-BUSINESS

<--additional-->
1 UA 1D 13DEC"""
segs, warns, out = parse1(GDS_IN)
check("BUGFIX multi-space GDS row -> verbatim re-render", out == GDS_EXP, out.replace("\n", " | "))
check("BUGFIX GDS class D kept", segs[0].booking_class == "D" and segs[0].cabin == "BUSINESS")
check("BUGFIX GDS shift/block/dist kept", segs[0].arr_day_shift == 2 and segs[0].flight_time == "17.20" and segs[0].distance == "8446")

segs, _, out = parse1("1 UA1 13DEC SFO SIN 1040P 800A+2 D 789 17.20 8446 N")
check("glued flight UA1", segs and segs[0].airline == "UA" and segs[0].flight_no == "1")
check("glued marker +2 kept", "800A¥2" in out)

GDS2 = """1 QR 704 15JAN JFK DOH 930P 520P¥1 I 359 12.50 6702 N"""
segs, _, out = parse1(GDS2)
check("full GDS row round-trip", out.splitlines()[0] == "1 QR 704 15JAN JFK DOH 930P 520P¥1 I 359 12.50 6702 N")
check("full GDS distance kept 6702", "6702" in out and "additional" in out)
check("full GDS class I additional", "1 QR 704I 15JAN" in out)

GDS3 = """1 UA    1 13DEC SFO SIN 1040P    800A¥2 D    789 17.20  8446  N

2 QR    704 15JAN JFK DOH 930P    520P¥1 I    359 12.50  6702  N"""
segs, _, out = parse1(GDS3)
check("two GDS rows, sequential additional", len(segs) == 2 and "1 UA 1D 13DEC" in out and "2 QR 704I 15JAN" in out)

segs, _, out = parse1("1 MS 777 15MAR CAI DXB 940A 305P Y 738 3.25 1542 N")
check("GDS economy Y", segs[0].booking_class == "Y" and segs[0].cabin == "ECONOMY" and "additional" in out)

# =====================================================================
# 5. Google Flights style (data-before-anchor)
# =====================================================================
gtxt = """Doha to New York
Mon, Mar 9
9:30 PM - 5:20 PM+1
Qatar Airways
12 hr 50 min
Hamad Intl (DOH) - John F Kennedy Intl (JFK)
QR 701
777-300ER
Economy"""
segs, warns, out = parse1(gtxt)
check("google leg parsed", len(segs) == 1 and segs[0].flight_no == "701")
check("google duration from display", segs[0].flight_time == "12.50")
check("google route/times/marker", segs[0].orig == "DOH" and segs[0].dest == "JFK"
      and segs[0].dep_time == "930P" and segs[0].arr_day_shift == 1)

gtxt2 = """Delhi to New York
Mon, Mar 9
1:55 AM - 6:00 AM
Qatar Airways
4 hr 35 min
New Delhi (DEL) - Doha (DOH)
QR 571
A350-900
2 hr 45 min Layover in Doha
8:45 AM - 2:30 PM
Qatar Airways
13 hr 15 min
Doha (DOH) - New York (JFK)
QR 701
777-300ER
Economy"""
segs, warns, out = parse1(gtxt2)
check("google 2-leg", len(segs) == 2)
check("google leg1", segs[0].flight_no == "571" and segs[0].flight_time == "4.35"
      and (segs[0].orig, segs[0].dest) == ("DEL", "DOH"))
check("google leg2 + layover ignored", segs[1].flight_no == "701" and segs[1].flight_time == "13.15"
      and (segs[1].orig, segs[1].dest) == ("DOH", "JFK"))

# =====================================================================
# 6. Distance / duration helpers sane
# =====================================================================
d = haversine_miles("JFK", "LHR")
check("JFK-LHR ~3459 mi", d and 3300 <= d <= 3600, str(d))
d = haversine_miles("JFK", "DOH")
check("JFK-DOH ~6700 mi", d and 6500 <= d <= 6900, str(d))
check("estimate_duration_min bounds", 35 <= estimate_duration_min(300) <= 240)
check("utc offsets", utc_offset("JFK", __import__("datetime").date(2026, 1, 15)) == -5
      and utc_offset("JFK", __import__("datetime").date(2026, 7, 15)) == -4)
check("CAI DST window", utc_offset("CAI", __import__("datetime").date(2026, 6, 1)) == 3
      and utc_offset("CAI", __import__("datetime").date(2026, 1, 15)) == 2)

# =====================================================================
# 6. Explicit booking class in parentheses — reported bug "Business (Z) -> C"
# =====================================================================
VS_SAMPLE = """New York (JFK) to London (LHR) on Tue, Sep 15

New York (JFK) to London (LHR) on Tue, Sep 15
8:15 AM to 8:10 PM (6h 55m)
Virgin Atlantic 26
Boeing 787
Business (Z)
"""
VS_EXPECTED = """1 VS 26 15SEP JFK LHR 815A 810P Z 788 6.55 3442 N
DEP-JOHN F KENNEDY INTL
ARR-LONDON HEATHROW
CABIN-BUSINESS

<--additional-->
1 VS 26Z 15SEP"""
segs, warns, out = parse1(VS_SAMPLE)
check("BUGFIX Business (Z) -> Z everywhere, exact output", out == VS_EXPECTED, out.replace("\n", " | "))
check("BUGFIX VS sample zero warnings", not warns, str(warns))

segs, _, _ = parse1("UA 100 05MAY JFK SFO 8:00 AM - 11:30 AM Premium Economy (W) 737-800")
check("Premium Economy (W) kept", segs[0].booking_class.upper() == "W" and segs[0].cabin == "PREMIUM ECONOMY")
segs, _, _ = parse1("UA 100 05MAY JFK SFO 8:00 AM - 11:30 AM Economy (M) 737-800")
check("Economy (M) kept", segs[0].booking_class.upper() == "M" and segs[0].cabin == "ECONOMY")
segs, _, _ = parse1("UA 100 05MAY JFK SFO 8:00 AM - 11:30 AM First (F) 737-800")
check("First (F) kept", segs[0].booking_class.upper() == "F" and segs[0].cabin == "FIRST")
segs, _, _ = parse1("UA 100 05MAY JFK SFO 8:00 AM - 11:30 AM business (i) 737-800")
check("business (i) lowercase -> I", segs[0].booking_class.upper() == "I" and segs[0].cabin == "BUSINESS")

# guards: parenthesised NON-class words must not become a booking class
segs, _, _ = parse1("UA 100 05MAY JFK SFO 8:00 AM - 11:30 AM Economy (Main Cabin) 737-800")
check("Economy (Main Cabin) no false class", segs[0].booking_class == "Y" and segs[0].cabin == "ECONOMY")
segs, _, _ = parse1("UA 100 05MAY JFK SFO 8:00 AM - 11:30 AM economy class with extra legroom 737-800")
check("'economy class with' no false letter", segs[0].booking_class == "Y")


# -- reported bug: 4-leg Amadeus itinerary mangled into 3 legs (user, v1.0) ----
SK4 = """1 SK 1694 30SEP VIE CPH 1015A 1155A    D       738  1.40   545  N
DEP-1                                  ARR-3
SKYTEAM
CABIN-BUSINESS
2 SK  935 30SEP CPH SFO 1245P  240P    D       359 10.55  5487  N
DEP-3                                  ARR-I
SKYTEAM
CABIN-BUSINESS
3 SK  936 25NOV SFO CPH  445P 1215P\u00a51 D       359 10.30  5487  N
DEP-I                                  ARR-3
SKYTEAM
CABIN-ECONOMY
4 SK  771 26NOV CPH TLV  515P 1040P    D       ???  4.25  1954  N
DEP-3                                  ARR-3
SKYTEAM
CABIN-ECONOMY

1 SK1694Z 30SEP W VIECPH SS1 1015A 1155A  /DCSK /E
2 SK935Z  30SEP W CPHSFO SS1 1245P 240P   /DCSK /E
3 SK936L  26NOV W SFOCPH SS1 445P 1215P 26NOV Q /DCSK /E
4 SK771L  26NOV Q CPHTLV SS1 515P 1040P  /DCSK /E
"""
segs, warns, out = parse1(SK4)
check("BUGFIX SK: exactly 4 legs", len(segs) == 4, f"got {len(segs)}")
check("BUGFIX SK: no phantom SS airline", all(s.airline != "SS" for s in segs))
check("BUGFIX SK: leg1 verbatim", out.splitlines()[0] == "1 SK 1694 30SEP VIE CPH 1015A 1155A D 738 1.40 545 N", out.splitlines()[0] if out else "")
check("BUGFIX SK: leg3 marker kept", segs[2].arr_day_shift == 1 and "1215P\u00a51" in out)
check("BUGFIX SK: all class D verbatim", all(s.booking_class == "D" for s in segs))
check("BUGFIX SK: additional has 4 rows", all(f"{i} SK " in out for i in (1, 2, 3, 4)))
check("BUGFIX SK: understood aircraft stays verbatim (738)", segs[0].aircraft == "738")
check("BUGFIX SK: aircraft inferred, never ???", segs[3].aircraft == "32N",
      segs[3].aircraft)
check("BUGFIX SK: only aircraft-inference notes allowed",
      all("aircraft inferred" in w for w in warns), str(warns))

# -- reported bug: 'Canadair RJ 900' hallucinated as Royal Jordanian RJ 900 ----
DLRJ = """Mon, Sep 15
Boston (BOS) to Minneapolis (MSP)
9:00 AM to 11:32 AM (4h 32m)
Delta 918
Boeing 737-900
Economy (T)

Minneapolis (MSP) to Indianapolis (IND)
1:15 PM to 4:10 PM (1h 55m)
Delta 5408 (operated by Endeavor Air Dba Delta Connection)
Canadair RJ 900
Economy (T)
"""
segs, warns, out = parse1(DLRJ)
check("BUGFIX RJ: exactly 2 legs", len(segs) == 2, f"got {len(segs)}")
check("BUGFIX RJ: no RJ flight", all(s.airline != "RJ" for s in segs))
check("BUGFIX RJ: marketing carrier DL kept", all(s.airline == "DL" for s in segs))
check("BUGFIX RJ: seg2 route completed", segs[1].orig == "MSP" and segs[1].dest == "IND", f"{segs[1].orig}-{segs[1].dest}")
check("BUGFIX RJ: Canadair RJ 900 -> CR9", segs[1].aircraft == "CR9", "aircraft=" + segs[1].aircraft)

# =====================================================================
# 14. BUGFIX: Google-Flights multi-block paste cross-contamination
#     (each flight kept the NEXT block's route and the FIRST block's
#     times -> wrong legs / "extra legs" garbage)
# =====================================================================
GOOGLE_2BLOCK = """LH
Frankfurt (FRA) to Washington DC (IAD)

Thu, Sep 10

LH 418 (Operated by Lufthansa)

1:10 PM
to4:05 PM
(8h 55m)

Airbus A340-600 | Business Class

1h 55m layover

Washington DC, United States. This is a connecting flight in IAD.
|
UA
Washington DC (IAD) to Dallas (DFW)
|
Thu, Sep 10

UA 2116 (Operated by United Airlines)

6:00 PM
to8:24 PM
(3h 24m)

Boeing 737-800 | Economy (D)
"""
segs, warns, out = parse1(GOOGLE_2BLOCK)
check("BUGFIX XBLK: exactly 2 legs", len(segs) == 2, f"got {len(segs)}")
check("BUGFIX XBLK: leg1 keeps own route FRA-IAD",
      segs[0].orig == "FRA" and segs[0].dest == "IAD", f"{segs[0].orig}-{segs[0].dest}")
check("BUGFIX XBLK: leg1 times 110P/405P",
      segs[0].dep_time == "110P" and segs[0].arr_time == "405P",
      f"{segs[0].dep_time}/{segs[0].arr_time}")
check("BUGFIX XBLK: leg1 block duration 8.55 not layover 1.55",
      segs[0].flight_time == "8.55", segs[0].flight_time)
check("BUGFIX XBLK: leg1 date 10SEP aircraft 346 class C",
      segs[0].date_ddmmm == "10SEP" and segs[0].aircraft == "346"
      and segs[0].booking_class == "C")
check("BUGFIX XBLK: leg2 route IAD-DFW",
      segs[1].orig == "IAD" and segs[1].dest == "DFW", f"{segs[1].orig}-{segs[1].dest}")
check("BUGFIX XBLK: leg2 keeps OWN times 600P/824P",
      segs[1].dep_time == "600P" and segs[1].arr_time == "824P",
      f"{segs[1].dep_time}/{segs[1].arr_time}")
check("BUGFIX XBLK: leg2 duration 3.24",
      segs[1].flight_time == "3.24", segs[1].flight_time)
check("BUGFIX XBLK: leg2 class D cabin ECONOMY",
      segs[1].booking_class == "D" and segs[1].cabin == "ECONOMY")

# leftover old trip above + same new paste twice -> old + new, deduped
OLD_TRIP = """UA
Houston (IAH) to Frankfurt (FRA)

Sun, Sep 7

UA 2682 (Operated by United Airlines)

3:59 PM
to7:40 AM
(9h 41m)

Boeing 737-900 | First (F)

1h 20m layover

Frankfurt, Germany. This is a connecting flight in FRA.
"""
segs, warns, out = parse1(OLD_TRIP + "\n" + GOOGLE_2BLOCK + "\n" + GOOGLE_2BLOCK)
check("BUGFIX XBLK: combined+double paste -> 3 legs", len(segs) == 3,
      f"got {len(segs)}")
check("BUGFIX XBLK: old trip leg intact",
      segs[0].airline == "UA" and segs[0].flight_no == "2682"
      and segs[0].orig == "IAH" and segs[0].dest == "FRA"
      and segs[0].dep_time == "359P" and segs[0].arr_time == "740A"
      and segs[0].arr_day_shift == 1 and segs[0].flight_time == "9.41")
check("BUGFIX XBLK: duplicates removed with warning",
      any("duplicate" in w.lower() for w in warns))
check("BUGFIX XBLK: new legs not contaminated by old trip",
      segs[1].orig == "FRA" and segs[1].dest == "IAD"
      and segs[2].orig == "IAD" and segs[2].dest == "DFW"
      and segs[2].dep_time == "600P")

# prose layout must stay intact (no side headers -> no premature split)
segs, warns, out = parse1(
    "Flying UA 2116 IAD to DFW departs 6:00 PM arrives 8:24 PM on Sep 10, "
    "Boeing 737-800, economy D. Then LH 418 FRA to IAD leaving 1:10 PM "
    "getting in 4:05 PM Sep 10, A340-600 business class.")
check("BUGFIX XBLK: prose 2-leg still parses", len(segs) == 2,
      f"got {len(segs)}")
check("BUGFIX XBLK: prose routes kept (v3.3: same-day legs go earliest-clock first)",
      segs[0].orig == "FRA" and segs[0].dest == "IAD"
      and segs[1].orig == "IAD" and segs[1].dest == "DFW")
check("BUGFIX XBLK: prose times kept",
      segs[0].dep_time == "110P" and segs[1].dep_time == "600P")

# =====================================================================
# 15. AI MODEL box sanitizer + auto-rescue (the "HTTP 400 unexpected
#     model name format" failure users hit with pasted model names)
# =====================================================================
check("MODEL clean: 'models/' prefix stripped",
      A.clean_model_name(" models/gemini-3-flash-preview\n")
      == "gemini-3-flash-preview")
check("MODEL clean: inner spaces/newlines removed",
      A.clean_model_name("gemini 3 flash") == "gemini3flash")
check("MODEL clean: quotes/punct trimmed",
      A.clean_model_name('`"gpt-5",') == "gpt-5")
check("MODEL clean: None/empty stays empty", A.clean_model_name(None) == "")

_orig_call = A._call_gemini
_orig_sleep = A._sleep
A._sleep = lambda s: None
try:
    calls = []

    def _fake(text, images, key, model, timeout):
        calls.append(model)
        if model != "gemini-3-flash-preview":
            raise A.AIError(
                "Gemini HTTP 400: * GenerateContentRequest.model: "
                "unexpected model name format")
        return "1 UA 2116 10SEP IAD DFW 600P 824P D 738 3.24 1170 N"

    A._call_gemini = _fake
    out = A.convert("anything", [], "gemini", "dummy-key",
                    model="models/gemini 3 flash")
    check("MODEL rescue: bad name auto-falls-back to default model",
          out.startswith("1 UA 2116")
          and calls == ["gemini3flash", "gemini-3-flash-preview"],
          str(calls))

    # quota errors must NOT trigger the MODEL retry (they get harmless
    # same-model transient retries instead — v2.1), and must still raise
    calls.clear()

    def _fake429(text, images, key, model, timeout):
        calls.append(model)
        raise A.AIError("Gemini HTTP 429: quota exceeded")

    A._call_gemini = _fake429
    try:
        A.convert("anything", [], "gemini", "dummy-key", model="custom-x")
        check("MODEL rescue: quota error re-raised", False)
    except A.AIError as e:
        check("MODEL rescue: quota error re-raised (never swaps model)",
              "429" in str(e) and calls == ["custom-x"] * 3, str(calls))
finally:
    A._call_gemini = _orig_call
    A._sleep = _orig_sleep

# =====================================================================
# 15b. RESILIENCE (v2.1): transient 503 auto-retry + cross-engine
#      failover — the "Gemini HTTP 503 high demand" outage must never
#      again reach the user while another engine can still answer
# =====================================================================
_orig_gem = A._call_gemini
_orig_oac = A._call_openai_compatible
_orig_ant = A._call_anthropic
_orig_sleep = A._sleep
A._sleep = lambda s: None
try:
    # (a) 503 twice, third attempt succeeds — same engine, no failover
    n = {"n": 0}

    def _flaky(text, images, key, model, timeout):
        n["n"] += 1
        if n["n"] < 3:
            raise A.AIError("Gemini HTTP 503: This model is currently "
                            "experiencing high demand.")
        return "1 BA 763 06AUG OSL LHR 700A 825A Y 320 2.25 715 N"

    A._call_gemini = _flaky
    r = A.convert("anything", [], "gemini", "dummy-key")
    check("RESILIENCE: transient 503 auto-retries then succeeds",
          r.startswith("1 BA 763") and n["n"] == 3
          and r.provider == "gemini" and not r.failover_from,
          f"calls={n['n']}")

    # (b) Gemini down for good, OpenRouter key available → auto-switch
    def _dead503(text, images, key, model, timeout):
        raise A.AIError("Gemini HTTP 503: high demand")

    A._call_gemini = _dead503
    seen = {}

    def _oa_ok(text, images, key, model, timeout, base, provider_name):
        seen.setdefault(provider_name, 0)
        seen[provider_name] += 1
        return "1 BA 763 06AUG OSL LHR 700A 825A Y 320 2.25 715 N"

    A._call_openai_compatible = _oa_ok
    r = A.convert("anything", [], "gemini", "dummy-key",
                  key_resolver=lambda pid: "k2" if pid == "openrouter" else "")
    check("RESILIENCE: failover to backup engine when chosen is down",
          r.provider == "openrouter" and r.failover
          and r.failover_from == ["gemini"]
          and seen.get("openrouter") == 1,
          f"provider={getattr(r, 'provider', None)} seen={seen}")

    # failover reports as a plain string still (str subclass)
    check("RESILIENCE: result still behaves like a str",
          isinstance(r, str) and "BA 763" in r)

    # (c) screenshots are never sent to text-only backup engines
    A._call_gemini = _dead503
    try:
        A.convert("x", [b"\x89PNG\r\n\x1a\nFAKEPNG"], "gemini", "dummy-key",
                  key_resolver=lambda pid: "k2" if pid == "openrouter"
                  else ("k3" if pid == "groq" else ""))
        check("RESILIENCE: text-only backups skipped for screenshots", False)
    except A.AIError as e:
        check("RESILIENCE: text-only backups skipped for screenshots",
              "Groq" not in str(e) and "OpenRouter" not in str(e), str(e))

    # (d) everything down → one combined error listing every engine tried
    A._call_gemini = _dead503

    def _oa_dead(text, images, key, model, timeout, base, provider_name):
        raise A.AIError(f"{provider_name.title()} HTTP 429: rate limit")

    def _ant_dead(text, images, key, model, timeout):
        raise A.AIError("Anthropic HTTP 401: invalid x-api-key")

    A._call_openai_compatible = _oa_dead
    A._call_anthropic = _ant_dead
    kr_all = lambda pid: "k" if pid != "gemini" else "k"
    try:
        A.convert("x", [], "gemini", "dummy-key", key_resolver=kr_all)
        check("RESILIENCE: combined error when all engines fail", False)
    except A.AIError as e:
        msg = str(e)
        check("RESILIENCE: combined error when all engines fail",
              "Every AI engine failed" in msg and "Gemini" in msg
              and "Openrouter" in msg and "Openai" in msg, msg[:160])

    # (e) bad custom model is rescued THEN failover still arms
    seq = []

    def _gem_check(text, images, key, model, timeout):
        seq.append(("gemini", model))
        if model != "gemini-3-flash-preview":
            raise A.AIError("Gemini HTTP 400: unexpected model name format")
        raise A.AIError("Gemini HTTP 503: high demand")

    def _oa_check(text, images, key, model, timeout, base, provider_name):
        seq.append((provider_name, model))
        return "1 BA 763 06AUG OSL LHR 700A 825A Y 320 2.25 715 N"

    A._call_gemini = _gem_check
    A._call_openai_compatible = _oa_check
    r = A.convert("x", [], "gemini", "dummy-key", model="gemini-99-ultra",
                  key_resolver=lambda pid: "k2" if pid == "openrouter" else "")
    check("RESILIENCE: model rescue then failover, custom model not leaked",
          r.provider == "openrouter"
          and seq[:2] == [("gemini", "gemini-99-ultra"),
                          ("gemini", "gemini-3-flash-preview")]
          and ("openrouter", "openai/gpt-oss-20b:free") in seq, str(seq))

    # (f) status callback receives live retry/switch messages
    msgs = []
    A._call_gemini = _dead503
    A._call_openai_compatible = _oa_ok
    A.convert("x", [], "gemini", "dummy-key",
              on_status=msgs.append,
              key_resolver=lambda pid: "k2" if pid == "openrouter" else "")
    check("RESILIENCE: on_status progress messages emitted",
          any("retrying" in m.lower() for m in msgs)
          and any("answered" in m.lower() for m in msgs), str(msgs))
finally:
    A._call_gemini = _orig_gem
    A._call_openai_compatible = _orig_oac
    A._call_anthropic = _orig_ant
    A._sleep = _orig_sleep

# friendly hint for exactly the message the office hit
import app as APP
h503 = APP.friendly_ai_error(
    "Gemini HTTP 503: This model is currently experiencing high demand. "
    "Spikes in demand are usually temporary. Please try again later.")
check("FRIENDLY: 503 overload gets a real answer, not a dead end",
      "overloaded" in h503.lower() and "auto-retried" in h503, h503[:80])
check("FRIENDLY: combined all-engines failure gets the overload hint",
      "auto-retried" in APP.friendly_ai_error(
          "Every AI engine failed — Gemini: HTTP 503 high demand"))
check("VERSION bump: 3.4", APP.APP_VERSION == "3.4")

# =====================================================================
# 19. CCJ / UNKNOWN-AIRPORT HARDENING (v2.3 — the ATL-PHL-DOH-CCJ bug)
# =====================================================================
# User paste: Google multi-city "Atlanta (ATL) to Kozhikode (CCJ) ...".
# Two regressions: (a) CCJ was missing from the airport table, so the leg's
# destination came out "???" and its block vanished; (b) without a valid
# "Doha (DOH) to Kozhikode (CCJ)" header, the flight-number anchor floated
# into the NEXT itinerary block and cloned its date/route/times.
_CCJ_TXT = """Atlanta (ATL) to Kozhikode (CCJ) on Sat, Sep 5
Warning IconWarning IconWarning Icon

Atlanta (ATL) to Philadelphia (PHL) on Sat, Sep 5
9:50 AM to 11:59 AM (2h 9m)
American 3270
Airbus A319
First (I)
Layover in PHL (9h 31m)

Philadelphia (PHL) to Doha (DOH) on Sat, Sep 5
9:30 PM to 5:00 PM (12h 30m)
American 8310 (operated by Qatar Airways)
Airbus A350
Business (I)
Layover in DOH (2h 40m)

Doha (DOH) to Kozhikode (CCJ) on Sun, Sep 6
7:40 PM to 2:35 AM on Mon, Sep 7 (4h 25m)
Qatar Airways 536
Airbus A320
Business (R)"""

segs, warns, out = parse1(_CCJ_TXT)
check("CCJ: airport exists in table", "CCJ" in AIRPORTS and
      AIRPORTS["CCJ"]["name"].startswith("CALICUT"))
check("CCJ: DOH-CCJ distance computable",
      1700 < haversine_miles("DOH", "CCJ") < 2050,
      str(haversine_miles("DOH", "CCJ")))
check("CCJ bug: 3 segments parsed", len(segs) == 3, str(len(segs)))
check("CCJ bug: leg1 AA 3270 05SEP ATL-PHL preserved",
      (segs[0].airline, segs[0].flight_no, segs[0].date_ddmmm,
       segs[0].orig, segs[0].dest) == ("AA", "3270", "05SEP", "ATL", "PHL"))
check("CCJ bug: leg3 QR 536 keeps its OWN date 06SEP (not next block's)",
      segs[2].date_ddmmm == "06SEP", segs[2].date_ddmmm)
check("CCJ bug: leg3 route DOH-CCJ, never ??? and never ATL/DOH",
      segs[2].orig == "DOH" and segs[2].dest == "CCJ",
      f"{segs[2].orig}-{segs[2].dest}")
check("CCJ bug: leg3 times 740P -> 235A with ¥1 overnight",
      segs[2].dep_time == "740P" and segs[2].arr_time == "235A"
      and segs[2].arr_day_shift == 1)
check("CCJ bug: leg3 aircraft 320 / class R / block 4.25",
      segs[2].aircraft == "320" and segs[2].booking_class == "R"
      and segs[2].flight_time == "4.25")
check("CCJ bug: leg3 distance filled from haversine",
      segs[2].distance not in ("0", "") and
      not any("distance unknown" in w for w in warns))
check("CCJ bug: rendered output contains no ??? anywhere",
      "???" not in out)

# ---- multi-block isolation: the Dec flight that used to swallow Sep ----
_MULTI_TXT = _CCJ_TXT + """

Atlanta (ATL) to Doha (DOH) on Wed, Dec 3
3:55 AM to 5:55 AM on Thu, Dec 4 (4h 30m)
Qatar Airways 537
Airbus A320
Business (R)

Doha (DOH) to Atlanta (ATL) on Thu, Dec 4
7:55 AM to 3:15 PM (15h 20m)
Qatar Airways 755
Airbus A350
Business (R)"""
segs, warns, out = parse1(_MULTI_TXT)
check("MULTI: all 5 legs survive", len(segs) == 5, str(len(segs)))
check("MULTI: Sep DOH-CCJ leg intact beside Dec blocks",
      (segs[2].airline, segs[2].flight_no, segs[2].date_ddmmm,
       segs[2].orig, segs[2].dest, segs[2].dep_time)
      == ("QR", "536", "06SEP", "DOH", "CCJ", "740P"),
      f"{segs[2].airline}{segs[2].flight_no} {segs[2].date_ddmmm} "
      f"{segs[2].orig}-{segs[2].dest} {segs[2].dep_time}")
check("MULTI: Dec outbound leg stays QR 537 03DEC ATL-DOH",
      (segs[3].flight_no, segs[3].date_ddmmm, segs[3].orig, segs[3].dest)
      == ("537", "03DEC", "ATL", "DOH"))
check("MULTI: return leg QR 755 04DEC DOH-ATL",
      (segs[4].flight_no, segs[4].date_ddmmm, segs[4].orig, segs[4].dest)
      == ("755", "04DEC", "DOH", "ATL"))

# ---- hardening proven: even with an airport REMOVED from the table ----
_saved_ccj = AIRPORTS.pop("CCJ")
try:
    segs2, warns2, out2 = parse1(_CCJ_TXT)
    check("HARDEN: unknown-code header still isolates the block",
          len(segs2) == 3 and segs2[2].date_ddmmm == "06SEP",
          f"n={len(segs2)} date={segs2[2].date_ddmmm if len(segs2)>2 else '?'}")
    check("HARDEN: unknown-code route still DOH-CCJ (paren extraction)",
          segs2[2].orig == "DOH" and segs2[2].dest == "CCJ",
          f"{segs2[2].orig}-{segs2[2].dest}")
    check("HARDEN: side-header detector accepts unknown paren codes",
          any(d == "CCJ" for _p, _o, d in P.find_side_headers(_CCJ_TXT)))
finally:
    AIRPORTS["CCJ"] = _saved_ccj

# =====================================================================
# 20. GDS VARIANT LAYOUT (v2.4 — class-before-date, noon N, bare shift)
# =====================================================================
# Office paste: "1   AA 8880   I 26SEP   JFK LHR   710P 720A¥1" style rows.
# The fast path only spoke "1 UA 1 13DEC ... D 789" layout; three real-world
# variants were dropped silently: booking class BEFORE the date, noon as
# 1200N / midnight as 1200M, and overnight shift glued without a marker
# ("1225A1") or written as a bare separate token ("645A 2").
check("GDSV clock: 1200N is noon", P._gds_clock("1200N") == (12, 0))
check("GDSV clock: 1200M is midnight", P._gds_clock("1200M") == (0, 0))
check("GDSV clock: N/M only for 12:00",
      P._gds_clock("1300N") is None and P._gds_clock("1100M") is None)
check("GDSV clock: classic A/P untouched",
      P._gds_clock("1040P") == (22, 40) and P._gds_clock("800A") == (8, 0))

_GDSV_TXT = """1   AA 8880   I 26SEP   JFK LHR   710P 720A¥1
2   BA 472   Y 27SEP   LHR BCN   850A 1200N
3   BA 551   Y 10OCT   FCO LHR   215P 405P
4   AA 8883   I 10OCT   LHR JFK   725P 1025P
5   AA 2859   I 11OCT   PHX ONT   200P 316P
6   AS 1342   O 08DEC   LAX SJD   745A 1119A"""
segs, warns, out = parse1(_GDSV_TXT)
check("GDSV: all 6 rows convert offline (no AI needed)", len(segs) == 6,
      str(len(segs)))
_exp = [("AA", "8880", "26SEP", "JFK", "LHR", "710P", "720A", 1, "I"),
        ("BA", "472", "27SEP", "LHR", "BCN", "850A", "1200P", 0, "Y"),
        ("BA", "551", "10OCT", "FCO", "LHR", "215P", "405P", 0, "Y"),
        ("AA", "8883", "10OCT", "LHR", "JFK", "725P", "1025P", 0, "I"),
        ("AA", "2859", "11OCT", "PHX", "ONT", "200P", "316P", 0, "I"),
        ("AS", "1342", "08DEC", "LAX", "SJD", "745A", "1119A", 0, "O")]
for k, (al, fl, dt, o_, d_, dep, arr, sh, cl) in enumerate(_exp):
    s = segs[k]
    check(f"GDSV row{k+1}: {al} {fl} {dt} {o_}-{d_} class {cl} verbatim",
          (s.airline, s.flight_no, s.date_ddmmm, s.orig, s.dest,
           s.dep_time, s.arr_time, s.arr_day_shift, s.booking_class)
          == (al, fl, dt, o_, d_, dep, arr, sh, cl))
check("GDSV: I class stays BUSINESS cabin, never downgraded",
      segs[0].cabin == "BUSINESS" and segs[3].cabin == "BUSINESS")
check("GDSV: SJD airport present (LAX-SJD distance computed)",
      segs[5].distance not in ("0", ""))

# screenshot variant: glued-no-marker shift + bare separate shift token
_GDSV_TXT2 = """1   CX 715   I 14DEC   HKG SIN   825P 1225A1
1   UA 877   P 10DEC   SFO HKG   1115P 645A 2
2   UA 878   D 03JAN   HKG SFO   1030P 655P"""
segs2, warns2, out2 = parse1(_GDSV_TXT2)
check("GDSV2: screenshot rows all convert", len(segs2) == 3, str(len(segs2)))
# v3.3: output is ONE chronological ticket -> UA 877 (10DEC) leads,
# CX 715 (14DEC) second, UA 878 (03JAN) last; every kept.
check("GDSV2: '1225A1' glued shift kept (¥1)",
      segs2[1].arr_time == "1225A" and segs2[1].arr_day_shift == 1
      and segs2[1].flight_no == "715")
check("GDSV2: bare '2' shift token kept (¥2) on UA 877",
      segs2[0].arr_time == "645A" and segs2[0].arr_day_shift == 2
      and segs2[0].flight_no == "877")
check("GDSV2: classes I/P/D all preserved (chronological order P,I,D)",
      [s.booking_class for s in segs2] == ["P", "I", "D"])

# classic layout must be untouched by the new variant rules
_CLASSIC = "1 UA    1 13DEC SFO SIN 1040P    800A¥2 D    789 17.20  8446  N"
segs3, _, _ = parse1(_CLASSIC)
check("GDSV: classic layout regression (verbatim columns)",
      len(segs3) == 1 and segs3[0].booking_class == "D"
      and segs3[0].arr_day_shift == 2 and segs3[0].aircraft == "789"
      and segs3[0].flight_time == "17.20" and segs3[0].distance == "8446")

# =====================================================================
# 21. AI-DETOUR GUARD (v2.4 — ??? aircraft must NOT force AI)
# =====================================================================
# Regression: typed GDS rows carry no aircraft column, so offline output
# legitimately shows "???" there; the old blanket "???" check shipped the
# result to the AI engine, which 429/503'd into an empty output pane.
segs, warns, out = parse1(_GDSV_TXT)
check("GUARD: complete GDS rows never route to AI",
      not APP.output_incomplete(out, warns))
check("GUARD: no ??? anywhere in output (aircraft inferred)",
      "???" not in out and not APP.output_incomplete(out, warns))
check("GUARD: inferences disclosed, never hidden",
      warns and all("aircraft inferred" in w for w in warns), str(warns[:2]))

# =====================================================================
# 22. NO ??? EVER (v2.5 — aircraft resolution by flight)
# =====================================================================
_NT_7 = """1   AC 1095   C 16OCT   MCO YUL   155P 505P
2   TK 36   C 16OCT   YUL IST   805P 1225P¥1
3   TK 722   C 17OCT   IST DAC   340P 205A¥1
4   SV 803   V 25DEC   DAC JED   150A 625A
5   MS 670   C 19JAN   JED CAI   1100P 1215A¥1
6   MS 987   C 20JAN   CAI EWR   410A 900A
7   UA 1511   Y 20JAN   EWR MIA   230P 535P"""
segs, warns, out = parse1(_NT_7)
check("ZERO???: all 7 segments", len(segs) == 7, str(len(segs)))
check("ZERO???: curated aircraft per flight",
      [s.aircraft for s in segs] == ["223", "359", "333", "789", "738", "789", "739"],
      str([s.aircraft for s in segs]))
check("ZERO???: output contains zero ??? and zero ????",
      "???" not in out and "????" not in out)
check("ZERO???: row5 verbatim business class + Cairo",
      "5 MS 670 19JAN JED CAI 1100P 1215A¥1 C 738 2.15 756 N" in out
      and "ARR-CAIRO INTL" in out)
check("ZERO???: row6 longhaul EgyptAir 789 with timezone math",
      "6 MS 987 20JAN CAI EWR 410A 900A C 789 11.50 5618 N" in out)
check("ZERO???: classes preserved C/C/C/V/C/C/Y verbatim",
      [s.booking_class for s in segs] == ["C", "C", "C", "V", "C", "C", "Y"])
check("ZERO???: inference disclosed per missing column",
      sum(1 for w in warns if "aircraft inferred" in w) == 7, str(warns[0] if warns else ""))
check("ZERO???: AI detour guard stays quiet",
      not APP.output_incomplete(out, warns))
_LONE = """Frankfurt (FRA) to Washington DC (IAD) on Thu, Sep 10
1:10 PM to 4:05 PM (11h 55m)
Lufthansa 418
Boeing 747
Economy (M)

Sat, Sep 12
5:35 PM to 11:10 PM (3h 35m)
Lufthansa 441"""
segs_u, warns_u, out_u = parse1(_LONE)
check("GUARD: truncated paste truly loses leg2 destination",
      len(segs_u) == 2 and segs_u[1].dest == "???", out_u.splitlines()[5][:60])
check("GUARD: genuinely missing route still triggers AI rescue",
      APP.output_incomplete(out_u, warns_u))
check("GUARD: rescue signal comes from named warnings, not strings",
      any("airport unknown" in w for w in warns_u))




# =====================================================================
# 17. UPDATER + SMART BUG REPORT (v2.2)
# =====================================================================
import updater as U

check("UPDATER parse_version", U.parse_ver("v2.10.1") == (2, 10, 1))
check("UPDATER newer logic (2.10 > 2.9)",
      U.version_newer("2.10", "2.9") and not U.version_newer("2.2", "2.10")
      and not U.version_newer("2.2", "2.2"))
mv = U.validate_manifest({"version": "2.3",
                          "url": "https://x/SpicyTerminal.exe",
                          "sha256": "a" * 64, "notes": "fix"})
check("UPDATER manifest valid", mv == ("2.3", "https://x/SpicyTerminal.exe",
                                       "a" * 64, "fix"))
try:
    U.validate_manifest({"version": "abc", "url": "ftp://no"})
    check("UPDATER manifest rejects garbage", False)
except U.UpdateError:
    check("UPDATER manifest rejects garbage", True)

_orig_fetch = U._fetch
try:
    U._fetch = lambda url, timeout=10: {"version": "9.9",
                                        "url": "https://x/SpicyTerminal.exe"}
    r = U.check("2.2")
    check("UPDATER check: newer found", r["status"] == "newer"
          and r["manifest"]["version"] == "9.9")
    U._fetch = lambda url, timeout=10: {"version": "2.2", "url": ""}
    check("UPDATER check: already latest", U.check("2.2")["status"] == "latest")

    def _boom(url, timeout=10):
        raise RuntimeError("DNS resolution failed")
    U._fetch = _boom
    r = U.check("2.2")
    check("UPDATER check: offline handled gracefully",
          r["status"] == "unavailable" and "DNS" in r["error"])
finally:
    U._fetch = _orig_fetch

bat = U.build_bat_preview("C:/x/SpicyTerminal.exe.new",
                          "C:/x/SpicyTerminal.exe", pid=4321)
check("UPDATER bat: waits for our PID, swaps, relaunches",
      "PID eq 4321" in bat and "move /y" in bat
      and 'start ""' in bat and ".new" in bat)

rep = APP.build_bug_report(
    {"provider": "Google Gemini (FREE)", "mode": "Auto",
     "api_key_b64": "U0VDUkVUa2V5"},
    "British Airways 763 OSL-LHR", "1 BA 763 06AUG OSL LHR 700A 825A Y 320",
    ["READY", "AI ERROR: Gemini HTTP 503: high demand"],
    provider_state="GEMINI ✓")
check("REPORT: full diagnostics included",
      "SpicyTerminal v3.4" in rep and "British Airways 763" in rep
      and "AI ERROR: Gemini HTTP 503" in rep and "GEMINI ✓" in rep)
check("REPORT: placeholders for the user's story present",
      "WHAT I EXPECTED INSTEAD" in rep and "WHAT I PASTED" in rep)
check("REPORT: NEVER leaks API key material",
      "U0VDUkVUa2V5" not in rep and "api_key" not in rep.lower()
      and "AQ.Ab8RN6" not in rep)
check("REPORT: long input truncated honestly at max_field",
      len(APP.build_bug_report({"provider": "x", "mode": "Auto"},
                               "Z" * 9000, "", [])) < 9000)

# =====================================================================
# 16. BUGFIX: truncated Google block (no route header for last leg) —
#     lone date line "Sat, Sep 12" must start the next flight's block
# =====================================================================
TRUNC_4 = """LH
Frankfurt (FRA) to Washington DC (IAD)

Thu, Sep 10

LH 418 (Operated by Lufthansa)

1:10 PM
to4:05 PM
(8h 55m)

Airbus A340-600 | Business Class
|
UA
Washington DC (IAD) to Dallas (DFW)

Thu, Sep 10

UA 2116 (Operated by United Airlines)

6:00 PM
to8:24 PM
(3h 24m)

Boeing 737-800 | Economy (D)
|
LH

Sat, Sep 12

LH 447 (Operated by Lufthansa)

5:35 PM
to11:10 AM
(9h 35m)

Boeing 747-8 | Economy (Y)
"""
segs, warns, out = parse1(TRUNC_4)
check("BUGFIX LONE-DATE: 3 legs parsed", len(segs) == 3, f"got {len(segs)}")
check("BUGFIX LONE-DATE: leg3 keeps OWN times 535P/1110A",
      segs[2].dep_time == "535P" and segs[2].arr_time == "1110A",
      f"{segs[2].dep_time}/{segs[2].arr_time}")
check("BUGFIX LONE-DATE: leg3 own date 12SEP duration 9.35",
      segs[2].date_ddmmm == "12SEP" and segs[2].flight_time == "9.35")
check("BUGFIX LONE-DATE: leg3 orig chained from leg2 (DFW)",
      segs[2].orig == "DFW", segs[2].orig)
check("BUGFIX LONE-DATE: truthfully flags missing destination",
      any("destination" in w.lower() for w in warns))
check("BUGFIX LONE-DATE: earlier legs not contaminated",
      segs[0].orig == "FRA" and segs[0].dest == "IAD"
      and segs[1].orig == "IAD" and segs[1].dest == "DFW")

# =====================================================================
# 17. Date-sequence coherence (v1.9)
# =====================================================================
segs, warns, out = parse1(
    "AA 100 JFK to LAX departs 8:00 PM arrives 11:00 PM on Aug 10, business class.\n"
    "AA 200 LAX to SFO departs 6:00 AM arrives 7:30 AM, economy.\n")
check("DATESEQ: weak date auto-bumped to next day",
      segs[1].date_ddmmm == "11AUG", segs[1].date_ddmmm)
check("DATESEQ: auto-bump is disclosed in warnings",
      any("inferred from connection" in w for w in warns))
check("DATESEQ: leg1 date untouched", segs[0].date_ddmmm == "10AUG")

segs, warns, out = parse1(
    "AA 100 JFK to LAX departs 8:00 PM arrives 11:00 PM on Aug 10.\n"
    "AA 200 LAX to SFO departs 6:00 AM arrives 7:30 AM on Aug 10, economy.\n")
check("DATESEQ: explicit date kept (not silently rewritten)",
      segs[1].date_ddmmm == "10AUG", segs[1].date_ddmmm)
check("DATESEQ: explicit impossible connection flagged",
      any("impossible" in w.lower() for w in warns))

segs, warns, out = parse1(
    "Flight AA 100 on 08/12/2026 from JFK to LAX departs 8:00 PM arrives "
    "11:00 PM.")
check("DATESEQ: ambiguous slash date = US MM/DD (12AUG)",
      segs[0].date_ddmmm == "12AUG", segs[0].date_ddmmm)

# feasible overnight chain must NOT be touched
segs, warns, out = parse1(
    "AA 100 JFK to LAX departs 8:00 PM arrives 11:00 PM on Aug 10.\n"
    "AA 200 LAX to SFO departs 6:00 AM arrives 7:30 AM on Aug 11, economy.\n")
check("DATESEQ: feasible chain left alone",
      segs[1].date_ddmmm == "11AUG"
      and not any("impossible" in w.lower() for w in warns))


TK_PASTE = """New York (JFK) to Mumbai (BOM) on Thu, Dec 10 Warning Icon

New York (JFK) to Istanbul (IST) on Thu, Dec 10

12:20 AM to 6:10 PM (9h 50m)

Turkish Airlines 12

Boeing 787

Economy (S)

Layover in IST (2h 25m)

Istanbul (IST) to Mumbai (BOM) on Thu, Dec 10

8:35 PM to 5:20 AM on Fri, Dec 11 (6h 15m)

Turkish Airlines 720

Boeing 777

Economy (S)

Mumbai (BOM) to New York (JFK) on Sun, Jan 3

Mumbai (BOM) to Istanbul (IST) on Sun, Jan 3

7:00 AM to 11:45 AM (7h 15m)

Turkish Airlines 721

Boeing 777

Economy (H)

Layover in IST (3h 35m)

Istanbul (IST) to New York (JFK) on Sun, Jan 3

3:20 PM to 6:20 PM on Sun, Jan 3 (11h 0m)

Turkish Airlines 1

Boeing 777

Economy (H)
"""

# =====================================================================
# 18. BUGFIX TK: Google round-trip variant (summary headers, anchor
#     MID-block: header -> times -> ANCHOR -> aircraft -> cabin, inline
#     "on Fri, Dec 11" arrival dates, layover "(2h 25m)" tokens)
# =====================================================================
segs, warns, out = parse1(open("/tmp/tk_input.txt").read()
                          if __import__("os").path.exists("/tmp/tk_input.txt")
                          else TK_PASTE)
check("BUGFIX TK: 4 legs, zero warnings", len(segs) == 4 and not warns,
      f"{len(segs)} segs, warns={warns}")
check("BUGFIX TK: leg1 full row",
      (segs[0].airline, segs[0].flight_no, segs[0].date_ddmmm, segs[0].orig,
       segs[0].dest, segs[0].dep_time, segs[0].arr_time, segs[0].booking_class,
       segs[0].aircraft, segs[0].flight_time)
      == ("TK", "12", "10DEC", "JFK", "IST", "1220A", "610P", "S", "788", "9.50"))
check("BUGFIX TK: leg2 own header date 10DEC not arrival 11DEC",
      segs[1].date_ddmmm == "10DEC", segs[1].date_ddmmm)
check("BUGFIX TK: leg2 overnight ¥1 kept",
      segs[1].arr_day_shift == 1 and segs[1].arr_time == "520A")
check("BUGFIX TK: leg2 block time 6.15 not layover 2.25",
      segs[1].flight_time == "6.15", segs[1].flight_time)
check("BUGFIX TK: leg3 return BOM-IST 03JAN class H",
      (segs[2].orig, segs[2].dest, segs[2].date_ddmmm, segs[2].booking_class)
      == ("BOM", "IST", "03JAN", "H"))
check("BUGFIX TK: leg4 block 11.00 not layover 3.35",
      segs[3].flight_time == "11.00", segs[3].flight_time)
check("BUGFIX TK: summary 'JFK-BOM / BOM-JFK' titles stole nothing",
      segs[0].orig == "JFK" and segs[0].dest == "IST"
      and segs[1].orig == "IST" and segs[1].dest == "BOM"
      and segs[2].orig == "BOM" and segs[2].dest == "IST"
      and segs[3].orig == "IST" and segs[3].dest == "JFK")

# =====================================================================
# 23. WORLDWIDE AIRCRAFT DATABASE (v2.6 - type master + route database
#     + range guard/advisory, feasibility-framework implementation)
# =====================================================================
from aviation_data import (aircraft_info, AIRCRAFT_TYPES, ROUTE_EQUIPMENT,
                           FLIGHT_EQUIPMENT, AIRLINE_EQUIPMENT,
                           GENERIC_EQUIPMENT, infer_aircraft, range_advisory)

check("ACDB: master table is substantial", len(AIRCRAFT_TYPES) >= 75,
      str(len(AIRCRAFT_TYPES)))
_i388 = aircraft_info("388")
check("ACDB: 388 metadata (ICAO A388, superjumbo, range 8000nm)",
      _i388 and _i388["icao"] == "A388" and _i388["cat"] == "superjumbo"
      and _i388["range_nm"] == 8000)
_i32q = aircraft_info("32Q")
check("ACDB: 32Q = A321neo narrowbody", bool(_i32q and _i32q["cat"] == "narrowbody"))
check("ACDB: unknown code -> None", aircraft_info("X99") is None)
_db_codes = set(FLIGHT_EQUIPMENT.values())
for _nb, _wb in AIRLINE_EQUIPMENT.values():
    _db_codes.add(_nb); _db_codes.add(_wb)
_db_codes.update(GENERIC_EQUIPMENT)
_db_codes.update(ROUTE_EQUIPMENT.values())
check("ACDB integrity: every code used by any inference tier resolves",
      all(c in AIRCRAFT_TYPES for c in _db_codes),
      str([c for c in _db_codes if c not in AIRCRAFT_TYPES]))
check("ACDB: route database hit QR DOH-LHR -> 351",
      infer_aircraft("QR", "999", "DOH", "LHR") == ("351", "route database"))
check("ACDB: route database reverse-direction lookup",
      infer_aircraft("QR", "999", "LHR", "DOH") == ("351", "route database"))
check("ACDB: route-db win for EK DXB-LHR (388) and NH HND-ITM (772)",
      infer_aircraft("EK", "500", "DXB", "LHR") == ("388", "route database")
      and infer_aircraft("NH", "999", "HND", "ITM") == ("772", "route database"))
check("ACDB: curated flight table always beats route database",
      infer_aircraft("BA", "472", "LHR", "JFK") == ("320", "flight table"))
check("ACDB: range guard upgrades under-ranged narrowbody pick",
      infer_aircraft("UA", "9999", None, None, 3480) == ("772", "route estimate"),
      str(infer_aircraft("UA", "9999", None, None, 3480)))
check("ACDB: range inside narrowbody envelope stays narrow",
      infer_aircraft("UA", "9999", None, None, 2600) == ("738", "route estimate"))
check("ACDB: unknown airline generic default (short/long)",
      infer_aircraft("ZZ", "1", None, None, 100) == ("738", "route estimate")
      and infer_aircraft("ZZ", "1", None, None, 8000) == ("789", "route estimate"))
check("ACDB: never ??? from any tier",
      all(infer_aircraft(a, f, o, d, m)[0] != "???" for a, f, o, d, m in
          [("ZZ", "99999", "FAKE", "ALSOFAKE", 0),
           ("QR", "999", "DOH", "LHR", 0), ("AA", "1", None, None, 0),
           ("XX", "5", None, None, 9000)]))
_adv = range_advisory("320", "FRA", "SYD")
check("ACDB: range advisory fires on impossible pairing",
      bool(_adv) and "range check" in _adv and "verify equipment" in _adv)
check("ACDB: range advisory quiet on realistic pairing (789 SFO-SIN, 320 JFK-LAX)",
      range_advisory("789", "SFO", "SIN") is None
      and range_advisory("320", "JFK", "LAX") is None)
_RT = """1   QR 999   C 15DEC   DOH LHR   800A 100P
2   EK 500   Y 16DEC   DXB LHR   330A 710A
3   DL 999   Y 17DEC   ATL LAX   800A 955A"""
segs, warns, out = parse1(_RT)
check("ACDB: parse-level route database fill (351/388/752)",
      [s.aircraft for s in segs] == ["351", "388", "752"],
      str([s.aircraft for s in segs]))
check("ACDB: route-db fills labeled in status-bar disclosures",
      sum(1 for w in warns if "route database" in w) == 3, str(warns))
check("ACDB: classes preserved verbatim and zero ??? in output",
      [s.booking_class for s in segs] == ["C", "Y", "Y"]
      and "???" not in out and "????" not in out)
check("ACDB: AI detour guard stays quiet on inferred equipment",
      not APP.output_incomplete(out, warns))
_RAG = """Frankfurt (FRA) to Sydney (SYD) on Sat, Dec 20
9:00 PM to 7:00 PM on Sun, Dec 21 (22h 0m)

Lufthansa 9000

Airbus A320

Business (C)"""
segs_r, warns_r, out_r = parse1(_RAG)
check("ACDB: explicit absurd equipment kept verbatim in output (320 FRA-SYD)",
      len(segs_r) == 1 and segs_r[0].aircraft == "320"
      and " 320 " in out_r, out_r.splitlines()[1][:70] if out_r else "")
check("ACDB: status-bar range advisory discloses the impossibility",
      any("range check" in w and "320" in w for w in warns_r), str(warns_r))
_missing_ap = sorted({c for kv in ROUTE_EQUIPMENT for c in kv[1:]}
                     - set(AIRPORTS))
check("ACDB integrity: every route-database airport resolves (DAL/HOU/ITM)",
      not _missing_ap, str(_missing_ap))
check("ACDB: Itami + Love Field + Hobby now in the airport registry",
      all(c in AIRPORTS for c in ("ITM", "DAL", "HOU")))
segs6, warns6, out6 = parse1("6   NH 999   Y 20DEC   HND ITM   900A 1010A")
check("ACDB: NH HND-ITM shuttle fills 772 with full distance math",
      len(segs6) == 1 and segs6[0].aircraft == "772"
      and "???" not in out6 and segs6[0].distance != "0",
      out6.splitlines()[0][:80] if out6 else "")

# =====================================================================
# 24. COMPACT WELCOME + INSTALLER-AS-DEFAULT pipeline (v2.7)
# =====================================================================
_src = open("app.py", encoding="utf-8").read()
_m = re.search(r"W, H = (\d+), (\d+)", _src)
check("UI: welcome screen is compact (<=660x700, was 900x880)",
      bool(_m) and int(_m.group(1)) <= 660 and int(_m.group(2)) <= 700,
      _m.groups() if _m else "not found")
_m2 = re.search(r"^\s*tw = (\d+)", _src, re.M)
check("UI: welcome logo scaled down (<=400px wide, was 620)",
      bool(_m2) and int(_m2.group(1)) <= 400, _m2.group(1) if _m2 else "")
check("INFRA: Inno setup script + build pipeline live in the repo",
      __import__("os").path.exists("setup.iss")
      and __import__("os").path.exists("build_setup.sh"))
_iss = open("setup.iss", encoding="utf-8").read()
check("INFRA: installer puts the clean folder build in Local AppData (no admin)",
      "PrivilegesRequired=lowest" in _iss and "{localappdata}" in _iss
      and "SpicyTerminal_Portable" in _iss)

# =====================================================================
# 25. MAC PACKAGE (v2.8 - native macOS via .command bootstrapper)
# =====================================================================
import os as _os
check("MAC: launcher ships in the repo as a bash script (zip/dmg add +x)",
      _os.path.exists("mac/SpicyTerminal.command")
      and open("mac/SpicyTerminal.command").read().startswith("#!/bin/bash"))
_lc = open("mac/SpicyTerminal.command").read()
check("MAC: launcher self-bootstraps venv + dependencies, then runs app",
      ".spicy_venv" in _lc and "-m venv" in _lc
      and "customtkinter pillow darkdetect requests" in _lc
      and 'exec "$VPY" app.py' in _lc)
check("MAC: missing-python and missing-tkinter paths explained to user",
      "python.org/downloads" in _lc and "python-tk@3.12" in _lc)
check("MAC: updater guarded off Windows (no .bat self-swap on macOS)",
      'sys.platform != "win32"' in _src)
check("MAC: mono and UI fonts already fall back to Menlo/Helvetica",
      '"Menlo"' in _src and '"Helvetica Neue"' in _src)
_md = open("mac/00_READ_ME_FIRST_Mac.txt").read()
check("MAC: readme covers Gatekeeper right-click-open ritual",
      "RIGHT CLICK" in _md and "Open" in _md)

# =====================================================================
# 26. MAC .DMG INSTALLER (v2.8 - one-file macOS package like Windows)
# =====================================================================
import plistlib as _pl
import os as _os2
_pt = open("mac/dmg/Info.plist", encoding="utf-8").read().replace(
    "@APP_VERSION@", APP.APP_VERSION)
_pd = _pl.loads(_pt.encode())
check("DMG: app bundle plist valid (id, exec, icon, version 2.8)",
      _pd["CFBundleExecutable"] == "SpicyTerminal"
      and _pd["CFBundleIconFile"] == "app.icns"
      and _pd["CFBundleShortVersionString"] == APP.APP_VERSION
      and _pd["CFBundleIdentifier"] == "com.bcflights.spicyterminal")
_ln = open("mac/dmg/SpicyTerminal.launcher", encoding="utf-8").read()
check("DMG: launcher bootstraps venv in Application Support + osascript UI",
      'Application Support' in _ln and "osascript" in _ln
      and 'exec "$VPY" "$RES/app.py"' in _ln)
check("DMG: launcher explains missing-Python and missing-tkinter natively",
      "python.org/downloads" in _ln and "python-tk@3.12" in _ln)
_bd = open("mac/build_mac_dmg.sh", encoding="utf-8").read()
check("DMG: dmg pipeline = FAT32 raw image via mtools (v2.9 fix -"
      " ISO9660 dmg silently refused by macOS)",
      _os2.path.exists("mac/build_mac_dmg.sh") and "mformat" in _bd
      and "mcopy" in _bd and "SPICY" in _bd and "genisoimage" not in _bd
      and 'tr -d .' in _bd)  # volume label derives from APP_VERSION

# =====================================================================
# 27. DEAD-CONVERT-BUTTON HARDENING (v2.9 - office report: clicks
#     silently did nothing when an AI call wedged / a modal hid)
# =====================================================================
check("FIX: watchdog force-revives buttons if busy exceeds 4 minutes",
      "_ai_watchdog" in _src and "time.monotonic() - self._busy_since > 240"
      in _src and "auto-reset" in _src or "_ai_watchdog" in _src
      and "> 240" in _src)
check("FIX: busy clicks now give visible feedback (never a silent no-op)",
      "Still converting - please wait a few seconds" in _src)
check("FIX: stuck worker results are ignored via generation counter",
      "_ai_gen += 1" in _src and "gen != self._ai_gen" in _src)
check("FIX: AUTO-fallback AI capped at 60s (explicit AI keeps 180s)",
      "tmo = 60 if fallback" in _src and "timeout_s=tmo" in _src
      and "timeout_s=None" in _src)
check("FIX: convert_ai forwards the timeout to the engine",
      "timeout=int(timeout_s or cfg.get(" in _src)
check("FIX: modal dialogs are raised above the app before grab",
      "_raise_dialog" in _src and _src.count("grab_set()") >= 3
      and _src.count("_raise_dialog(self)") >= 3)

# =====================================================================
# 28. v3.0 - CONVERT FREEZE FIX (office report: 'CONVERT freezes with
#     nothing unless I click ✦ AI', status stuck on READY, v2.8/v2.9).
#     Root cause: the offline parser ran on the UI thread AND recompiled
#     ~1,100 city-alias regexes per block scan (8.6s on 300 Google
#     cards). Fix: one precompiled alternation + a worker thread with a
#     30s fuse, so the GUI can never freeze again.
# =====================================================================
_psrc = open("parser_offline.py", encoding="utf-8").read()

check("v3.0: city aliases compiled ONCE into a single alternation",
      "_city_alt_re" in _psrc and "_CITY_ALT_RE = None" in _psrc
      and "sorted(CITY_ALIASES, key=len, reverse=True)" in _psrc)
check("v3.0: old per-alias re.compile loop is GONE from the parser",
      '\\b{re.escape(city)}' not in _psrc)

import time as _time
_card = open("sample_texts.txt", encoding="utf-8").read()
_t0 = _time.time()
for _ in range(30):
    P.parse(_card * 10)
_off_ms = (_time.time() - _t0) * 1000
check("v3.0: 300-card parse is fast (was 8636ms, must stay < 2500ms)",
      _off_ms < 2500, f"{_off_ms:.0f}ms")

check("v3.0: offline convert runs in a worker thread (never the UI thread)",
      "def _run_offline" in _src and "def _offline_done" in _src
      and "threading.Thread(target=work, daemon=True).start()" in _src
      and "self._run_offline(text, imgs, mode)" in _src)
check("v3.0: instant visible status while offline engine works",
      "CONVERTING OFFLINE" in _src and "update_idletasks()" in _src)
check("v3.0: 30s offline fuse revives buttons if parsing ever hangs",
      "def _off_watchdog" in _src
      and "Offline engine took too long" in _src
      and "time.monotonic() - self._busy_since > 30" in _src)
check("v3.0: stale offline results ignored via the generation counter",
      "def _offline_done" in _src
      and "gen != self._ai_gen" in _src)
check("v3.0: parser exceptions can never take the UI down",
      "parser must never take the UI down" in _src
      and "offline engine error" in _src)

# =====================================================================
# 29. v3.1 - 'DOESN'T EVEN TRY OFFLINE FIRST' FIX (office screenshot:
#     JFK->PMO Google paste went straight to 'AI converting', OUTPUT
#     empty). Offline DID parse it, but whenever the result was partial
#     the auto-AI fallback kept the box EMPTY while spinning. Now the
#     offline partial shows immediately and is RESTORED if AI fails.
#     Plus PMO (Palermo) was missing from the airport DB -> '0 N'.
# =====================================================================
_office_paste = (
    "New York (JFK) to Palermo (PMO) on Sun, Sep 20\n"
    "Warning IconWarning Icon\n\n"
    "New York (JFK) to London (LHR) on Sun, Sep 20\n"
    "6:30 PM to 6:40 AM (7h 10m)\n"
    "British Airways 112\n"
    "Boeing 777\n"
    "Business (I)\n"
    "Layover in LHR (8h 0m)\n\n"
    "London (LHR) to Palermo (PMO) on Mon, Sep 21\n"
    "2:40 PM to 6:40 PM (3h 0m)\n"
    "British Airways 618\n"
    "Airbus A320\n"
    "Business (J)\n")

_out31, _w31 = APP.convert_offline(_office_paste)
check("v3.1: office JFK->PMO paste converts OFFLINE (never needs AI)",
      _out31 and "BA 112" in _out31 and "BA 618" in _out31
      and "???" not in _out31, str(_w31))
check("v3.1: PMO airport resolved (name + real distance, no '0 N')",
      "PMO" in getattr(__import__("aviation_data"), "AIRPORTS")
      and "PALERMO" in _out31 and " 0 N" not in _out31, _out31[-80:] if _out31 else "none")
check("v3.1: palermo/catania city aliases map to PMO/CTA",
      getattr(__import__("aviation_data"), "CITY_ALIASES")["palermo"] == "PMO")
check("v3.1: partial offline result is SHOWN while AI fills the gaps",
      "_fallback_offline = (out, warns)" in _src
      and "OFFLINE ENGINE (partial" in _src
      and "Offline converted what it could" in _src)
check("v3.1: AI error RESTORES the kept offline result (never empty box)",
      "out_fb, warns_fb = self._fallback_offline" in _src
      and "OFFLINE result kept above" in _src
      and "offline result kept" in _src)
check("v3.1: keepsake cleared on fresh convert and on AI success",
      "self._fallback_offline = None  # fresh convert" in _src
      and "AI delivered" in _src)
# order guard: inside _offline_done the partial show_output precedes run_ai
_i1 = _src.find("OFFLINE ENGINE (partial")
_i2 = _src.find("self._fallback_offline = (out, warns)")
_i3 = _src.find("self.run_ai(text, imgs, fallback=True)", _i1)
check("v3.1: show-partial -> remember -> run_ai order in _offline_done",
      -1 < _i1 < _i2 < _i3)

# =====================================================================
# 30. v3.2 - HIDDEN-STOP MERGE + never-silent-drop guard (office: DL
#     rows 5-6 vanished from a 6-row convert; user asks: 'whenever it's
#     a hidden stop, do not add it as a full segment').
# =====================================================================
_6rows = (
    "1   EY 499   D 25OCT   SIN AUH   725P 1120P\n"
    "2   EY 99    D 26OCT   AUH LIS   200A 655A\n"
    "3   AA 8574  I 30OCT   OPO MAD   1225P 245P\n"
    "4   AA 8801  I 30OCT   MAD BOS   515P 900P\n"
    "5   DL 7840  Z 16NOV   BOS ICN   1100A 435P¥1\n"
    "6   DL 7821  Z 17NOV   ICN SIN   630P 1210A1\n")
_s32, _w32 = P.parse(_6rows)
check("v3.2: all 6 GDS rows parse (Z class + ¥1/bare shifts alive)",
      len(_s32) == 6 and _s32[4].airline == "DL"
      and _s32[4].booking_class == "Z" and _s32[4].arr_day_shift == 1
      and _s32[5].flight_no == "7821",
      str(len(_s32)) + " segs; warns " + str(_w32))
check("v3.2: no merge when flight numbers DIFFER (EY 499 vs EY 99)",
      not any(s.hidden_stops for s in _s32))

_hs = ("1   EY 499   D 25OCT   SIN AUH   725P 1120P\n"
       "2   EY 499   D 26OCT   AUH LIS   200A 655A\n")
_sh, _wh = P.parse(_hs)
check("v3.2: same flight number + airport chain + sane gap = ONE segment",
      len(_sh) == 1 and _sh[0].orig == "SIN" and _sh[0].dest == "LIS"
      and _sh[0].hidden_stops == ("AUH",),
      str(len(_sh)) + " segs " + str(_wh))
check("v3.2: merged segment keeps through-times (arr 655A¥1, block sum)",
      _sh and _sh[0].arr_time == "655A" and _sh[0].arr_day_shift == 1
      and _sh[0].flight_time == "16.50"          # 7:55 + 8:55
      and int(_sh[0].distance) > 5000,           # direct SIN-LIS
      f"{_sh[0].flight_time if _sh else ''} {_sh[0].distance if _sh else ''}")
import formatter as _F32
_r32 = _F32.render_segment(_sh[0])
check("v3.2: hidden stop prints as STOP- line, not a segment",
      "STOP-AUH" in _r32 and _r32.count("CABIN-") == 1)
check("v3.2: merge is disclosed in warnings (never silent)",
      any("hidden stop" in w for w in _wh), str(_wh))

_nomatch = ("1   EY 499   D 25OCT   SIN AUH   725P 1120P\n"
            "2   EY 499   D 26OCT   DXB LHR   200A 655A\n")
check("v3.2: same number but route break -> NO merge",
      len(P.parse(_nomatch)[0]) == 2)

_badgap = ("1   EY 499   D 25OCT   SIN AUH   725P 1150P\n"
           "2   EY 499   D 25OCT   AUH LIS   200P 655A\n")
check("v3.2: same number but impossible timing (gap < 0) -> NO merge",
      len(P.parse(_badgap)[0]) == 2)

_lost = ("1   EY 499   D 25OCT   SIN AUH   725P 1120P\n"
         "2   DL 7840  Z 16NOV   BOS ICN   115A 435X\n")
_ls, _lw = P.parse(_lost)
check("v3.2: unreadable flight row is CALLED OUT by line number",
      len(_ls) == 1 and any("NOT read" in w and "line(s) 2" in w
                            for w in _lw), str(_lw))
check("v3.2: lost-row warning never fires on clean input",
      not any("NOT read" in w for w in _w32))

# =====================================================================
# 31. v3.3 - ONE-TICKET DATE ORDER (office: legs pasted ticket by
#     ticket with restarted row numbers 1,2,1,2,1,2 + a '4' typo + an
#     ASCII '435P1' instead of '¥1' - all must still parse, and the
#     OUTPUT should be ONE sequence renumbered by date, no matter the
#     input grouping/order).
# =====================================================================
_their_rows = (
    "1   EY 499   D 25OCT   SIN AUH   725P 1120P\n"
    "2   EY 99    D 26OCT   AUH LIS   200A 655A\n"
    "1   AA 8574  I 30OCT   OPO MAD   1225P 245P\n"
    "2   AA 8801  I 30OCT   MAD BOS   515P 900P\n"
    "1   DL 7840  Z 16NOV   BOS ICN   1100A 435P1\n"
    "4   DL 7821  Z 17NOV   ICN SIN   630P 1210A1\n")
_t33, _w33 = P.parse(_their_rows)
check("v3.3: office per-ticket numbering (1,2,1,2,1,2 + '4' typo + ASCII shift) parses ALL",
      len(_t33) == 6, str(len(_t33)))

_shuf = (
    "1   DL 7840  Z 16NOV   BOS ICN   1100A 435P1\n"
    "2   DL 7821  Z 17NOV   ICN SIN   630P 1210A1\n"
    "1   EY 499   D 25OCT   SIN AUH   725P 1120P\n"
    "2   EY 99    D 26OCT   AUH LIS   200A 655A\n"
    "1   AA 8801  I 30OCT   MAD BOS   515P 900P\n"
    "2   AA 8574  I 30OCT   OPO MAD   1225P 245P\n")
_s33, _ = P.parse(_shuf)
_seq = [(s.date_ddmmm, s.airline + s.flight_no) for s in _s33]
check("v3.3: shuffled tickets come out in ONE chronological sequence",
      [s.seg for s in _s33] == [1, 2, 3, 4, 5, 6]
      and _seq[0][1] == "EY499" and _seq[1][1] == "EY99"
      and _seq[2][1] == "AA8574"          # same-day: earlier clock first
      and _seq[3][1] == "AA8801"
      and _seq[4][1] == "DL7840" and _seq[5][1] == "DL7821", str(_seq))
check("v3.3: dates in the output are strictly non-decreasing",
      [s.date_ddmmm for s in _s33] ==
      ["25OCT", "26OCT", "30OCT", "30OCT", "16NOV", "17NOV"])

_turn = ("1   UA 44    Y 28DEC   SFO LHR   700P 135P\n"
         "2   UA 45    Y 03JAN   LHR SFO   1200P 400P\n")
_r33, _ = P.parse(_turn)
check("v3.3: DEC->JAN year turnover keeps DEC first (no false reorder)",
      len(_r33) == 2 and _r33[0].date_ddmmm == "28DEC"
      and _r33[1].date_ddmmm == "03JAN", str([s.date_ddmmm for s in _r33]))

_e2e, _ = APP.convert_offline(_shuf)
check("v3.3: formatted output is numbered 1-6 in date order too",
      _e2e.startswith("1 EY 499 25OCT") and "\n\n5 DL 7840 16NOV" in _e2e
      and "\n\n6 DL 7821 17NOV" in _e2e, _e2e[:60])


# ============ v3.4: digit-leading IATA codes (office 4Y report) =========
_office4y = ("1 4Y  481 13OCT MCO MUC  945P  120P\u00a51 D    333  9.35  4921  N\n"
             "DEP-C                          ARR-2\n"
             "CABIN-BUSINESS\n"
             "2 LH  109 14OCT MUC FRA  300P  400P   D    320   1.0   186  N\n"
             "DEP-NOT PRE-DETERMINED         ARR-NOT PRE-DETERMINED\n"
             "STAR\n"
             "CABIN-BUSINESS\n"
             "3 AI 2028 14OCT FRA BOM  820P  840A\u00a51 D    788  8.50  4086  N\n"
             "DEP-NOT PRE-DETERMINED         ARR-NOT PRE-DETERMINED\n"
             "STAR\n"
             "CABIN-BUSINESS")
_s4y, _w4y = P.parse(_office4y)
check("v3.4: office 4Y paste converts ALL 3 rows (was silently dropped)",
      len(_s4y) == 3, f"{len(_s4y)} segs")
check("v3.4: 4Y row fields exact (digit-leading airline, shift, class, nums)",
      _s4y[0].airline == "4Y" and _s4y[0].flight_no == "481"
      and _s4y[0].orig == "MCO" and _s4y[0].dest == "MUC"
      and _s4y[0].arr_day_shift == 1 and _s4y[0].booking_class == "D"
      and _s4y[0].aircraft == "333" and _s4y[0].distance == "4921",
      str(_s4y[0])[:80])
check("v3.4: no silent-drop warning needed (nothing dropped)",
      not any("NOT read" in w for w in _w4y), str(_w4y)[:80])
_o4y = F.render_itinerary(_s4y)
check("v3.4: rendered 4Y itinerary exact",
      _o4y.startswith("1 4Y 481 13OCT MCO MUC 945P 120P\u00a51 D 333 9.35 4921 N\n"
                      "DEP-ORLANDO INTL\nARR-MUNICH INTL\nCABIN-BUSINESS")
      and "1 4Y 481D 13OCT" in _o4y and "2 LH 109D 14OCT" in _o4y
      and "3 AI 2028D 14OCT" in _o4y and "???" not in _o4y, _o4y[:60])
_s6e, _ = P.parse("1 6E  2312 05JAN DEL BOM  600A  815A  Y  32N  2.15  708  N")
check("v3.4: other digit-leading codes fine (6E IndiGo)",
      len(_s6e) == 1 and _s6e[0].airline == "6E", str(_s6e)[:60])
_sg, _ = P.parse("4Y481 13OCT MCO MUC 945P 120P\u00a51 D 333 9.35 4921 N")
check("v3.4: glued 4Y481 token parses", len(_sg) == 1
      and _sg[0].airline == "4Y" and _sg[0].flight_no == "481", str(_sg)[:60])
check("v3.4: Discover Airlines registered with aliases",
      __import__("aviation_data").AIRLINES.get("4Y") == "Discover Airlines"
      and __import__("aviation_data").AIRLINE_ALIASES.get("discover") == "4Y"
      and __import__("aviation_data").AIRLINE_ALIASES.get("discover airlines") == "4Y", "")
_junk = P._LOST_ROW_RE.match("1 4Y  481 13OCT MCO MUC  945P  120P\u00a51 D    333")
check("v3.4: lost-row guard also recognises class-after-times rows",
      bool(_junk) and _junk.group(1) == "4Y", str(_junk))

print("=" * 50)
fails = [r for r in results if not r[1]]
print(f"{len(results) - len(fails)}/{len(results)} PASSED")
if fails:
    print("FAILURES:")
    for n, _, d in fails:
        print("  -", n, d)
    sys.exit(1)
print("ALL GREEN")
