; SpicyTerminal installer — the DEFAULT package for every version (v2.7+).
; Built by build_setup.sh (it injects the version from app.py automatically).
; Why this shape: a standard Inno Setup installer like Zoom/Chrome/Notepad++.
; Antivirus engines see this shape millions of times a day; the self-extracting
; onefile app was the shape that got flagged. User-confirmed clean in the office.
[Setup]
AppName=SpicyTerminal
AppVersion=3.4.0.0
AppPublisher=BC Flights / Lamar Garcia
AppPublisherURL=https://bcflights.com
AppSupportURL=mailto:Lamar@bcflights.com
DefaultDirName={localappdata}\SpicyTerminal
DefaultGroupName=SpicyTerminal
PrivilegesRequired=lowest
OutputDir=Z:\opt\gds-wine\inno\out
OutputBaseFilename=SpicyTerminal-Setup-v3.4
Compression=lzma2/ultra64
SolidCompression=yes
LZMAUseSeparateProcess=yes
SetupIconFile=Z:\home\user\gds_converter\assets\app_icon.ico
WizardStyle=modern
DisableProgramGroupPage=yes
UninstallDisplayName=SpicyTerminal
UninstallDisplayIcon={app}\SpicyTerminal_Portable.exe
VersionInfoVersion=3.4.0.0
VersionInfoCompany=BC Flights / Lamar Garcia
VersionInfoDescription=SpicyTerminal Installer - GDS Black Window Itinerary Converter
VersionInfoProductName=SpicyTerminal
VersionInfoCopyright=(c) 2026 Lamar Garcia / BC Flights
ArchitecturesInstallIn64BitMode=x64

[Files]
; the payload = the onedir folder build (the build that is AV-clean on office PCs)
Source: "Z:\home\user\gds_converter\release\SpicyTerminal_Portable\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion

[Tasks]
Name: "desktopicon"; Description: "Create a desktop shortcut"; GroupDescription: "Additional icons:"

[Icons]
Name: "{autoprograms}\SpicyTerminal"; Filename: "{app}\SpicyTerminal_Portable.exe"
Name: "{autodesktop}\SpicyTerminal"; Filename: "{app}\SpicyTerminal_Portable.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\SpicyTerminal_Portable.exe"; Description: "Launch SpicyTerminal"; Flags: postinstall nowait skipifsilent
