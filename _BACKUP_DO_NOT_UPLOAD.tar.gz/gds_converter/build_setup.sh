#!/usr/bin/env bash
# ==============================================================
# build_setup.sh — DEFAULT packaging pipeline for SpicyTerminal.
#
# The office rollout format (user-confirmed AV-clean, v2.6+):
#     ONE installer exe:  release/SpicyTerminal-Setup-v$VER.exe
# produced by Inno Setup around the onedir folder build.
#
# Usage:
#   bash build_setup.sh           # run tests, build onedir, compile installer
#   bash build_setup.sh --quick   # skip the test suite
#
# Prereq: wine env (rebuild_env.sh). This script bootstraps Inno Setup itself.
# XTEST note (compact welcome v2.7+): window 620x600 centered on 1280x1024;
# launch button measured before clicking (see xtest scripts in /tmp usage).
# ==============================================================
set -e
cd "$(dirname "$0")"
VER=$(sed -n 's/^APP_VERSION = "\([^"]*\)".*/\1/p' app.py)
[ -n "$VER" ] || { echo "APP_VERSION not found in app.py"; exit 1; }
echo "== SpicyTerminal v$VER — installer build pipeline =="

if [ "${1:-}" != "--quick" ]; then
  echo "== 1/4 test suite =="
  python3 tests.py | tail -2
fi

export WINE=/usr/lib/wine/wine64 WINEPREFIX=/opt/gds-wine/prefix
export WINEDEBUG=-all WINEDLLOVERRIDES="mscoree=;mshtml="
PY='C:\users\user\AppData\Local\Programs\Python\Python312\python.exe'
ISCC_EXE="$WINEPREFIX/drive_c/Program Files (x86)/Inno Setup 6/ISCC.exe"

echo "== 2/4 Inno Setup bootstrap (if needed) =="
if [ ! -f "$ISCC_EXE" ]; then
  mkdir -p /opt/gds-wine/inno
  [ -f /opt/gds-wine/inno/inno6.exe ] || wget -q --tries=2 -T 120 \
    -O /opt/gds-wine/inno/inno6.exe \
    "https://github.com/jrsoftware/issrc/releases/download/is-6_7_3/innosetup-6.7.3.exe"
  xvfb-run -a $WINE /opt/gds-wine/inno/inno6.exe /VERYSILENT /SUPPRESSMSGBOXES /NORESTART
fi

echo "== 3/4 onedir payload =="
xvfb-run -a $WINE "$PY" -m PyInstaller --noconfirm --clean --onedir --windowed \
  --name SpicyTerminal_Portable \
  --add-data "Z:/home/user/gds_converter/assets;assets" \
  --icon "Z:\home\user\gds_converter\assets\app_icon.ico" \
  --distpath release --workpath /opt/gds-wine/wb2 --specpath /opt/gds-wine/wb2 \
  --collect-all customtkinter app.py 2>&1 | tail -2
find release/SpicyTerminal_Portable -name __pycache__ -type d -exec rm -rf {} + 2>/dev/null || true

echo "== 4/4 installer compile =="
sed "s/^AppVersion=.*/AppVersion=$VER.0.0/; s/^OutputBaseFilename=.*/OutputBaseFilename=SpicyTerminal-Setup-v$VER/; s/^VersionInfoVersion=.*/VersionInfoVersion=$VER.0.0/" \
  setup.iss > /tmp/setup_gen.iss
# force output into release/ regardless of the template's OutputDir
python3 - <<'PYEOF'
t = open("/tmp/setup_gen.iss", encoding="utf-8").read()
t = t.replace("OutputDir=Z:\\opt\\gds-wine\\inno\\out",
              "OutputDir=Z:\\home\\user\\gds_converter\\release")
open("/tmp/setup_gen.iss", "w", encoding="utf-8").write(t)
PYEOF
mkdir -p release
xvfb-run -a $WINE "C:\Program Files (x86)\Inno Setup 6\ISCC.exe" "Z:\tmp\setup_gen.iss" 2>&1 | tail -3
mv /tmp/setup_gen.iss release/setup_gen.iss 2>/dev/null || true
OUT="release/SpicyTerminal-Setup-v$VER.exe"
ls -la "$OUT"
sha256sum "$OUT"
echo "DONE. Default deliverable: $OUT"
