#!/usr/bin/env bash
# rebuild_env.sh — recreate the ephemeral Windows .exe build toolchain in THIS sandbox.
#
# WHY THIS EXISTS:
#   System packages (wine, xvfb...) and anything outside /home/user are wiped
#   between turns, and a Wine prefix placed INSIDE /home/user (e.g. ~/.wine)
#   previously bloated the workspace snapshot to 1.6 GB / 10,980 files
#   (limit: 128 MB / 10,000 files — 10,945 files were dropped).
#
# THE FIX: keep the Wine prefix and the Python installer OUTSIDE /home/user
#   (under /tmp, which is never snapshotted). Only the project folder and the
#   final release/ exe live in /home/user.
#
# Usage:  bash rebuild_env.sh        (takes ~5-10 min, needs network + sudo)
set -e

# Tools that must never land inside /home/user.
# NOTE: /tmp in this sandbox is a tiny 993MB tmpfs — too small for a Wine
# prefix + Windows Python + pip packages. /opt lives on the real disk
# (25GB) and, like everything outside /home/user, is never snapshotted.
export WINE=/usr/lib/wine/wine64
sudo mkdir -p /opt/gds-wine && sudo chown $USER:$USER /opt/gds-wine
export WINEPREFIX=/opt/gds-wine/prefix     # <-- was ~/.wine (snapshotted!) then /tmp (too small)
export WINEDEBUG=-all
export WINEDLLOVERRIDES="mscoree=;mshtml="
INSTALLER=/opt/gds-wine/python-3.12.8-amd64.exe   # <-- was ~/python-installer.exe (27 MB)

PY_WIN='C:\users\user\AppData\Local\Programs\Python\Python312\python.exe'

echo '== 1/5 apt: wine64 + wine32:i386 + X test tools =='
sudo dpkg --add-architecture i386
sudo apt-get update -qq
sudo DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
    wine64 wine32:i386 xvfb xdotool xsel xclip wget ca-certificates x11-apps imagemagick

echo '== 2/5 fresh wine prefix (under /tmp) =='
rm -rf "$WINEPREFIX"
xvfb-run -a "$WINE" wineboot --init
sleep 5

echo '== 3/5 Windows Python 3.12.8 (needs wine32 for the 32-bit bootstrapper) =='
[ -f "$INSTALLER" ] || wget -q -O "$INSTALLER" https://www.python.org/ftp/python/3.12.8/python-3.12.8-amd64.exe
xvfb-run -a "$WINE" "$INSTALLER" /quiet InstallAllUsers=0 PrependPath=1 Include_test=0 Include_doc=0
sleep 10

echo '== 4/5 pip packages inside the wine prefix =='
xvfb-run -a "$WINE" "$PY_WIN" -m pip install --quiet --no-warn-script-location \
    customtkinter pillow pyinstaller requests darkdetect

echo '== 5/5 build the exe -> release/ (NEVER dist/ or build/: excluded from snapshots!) =='
cd "$(dirname "$0")"
rm -rf /opt/gds-wine/wb release
xvfb-run -a "$WINE" "$PY_WIN" -m PyInstaller --noconfirm --clean --onefile --windowed \
    --name SpicyTerminal \
    --add-data "Z:/home/user/gds_converter/assets;assets" \
    --icon "Z:\home\user\gds_converter\assets\app_icon.ico" \
    --distpath release --workpath /opt/gds-wine/wb --specpath /opt/gds-wine/wb \
    --collect-all customtkinter app.py
ls -la release/

echo '== sanity: run test suite =='
python3 tests.py | tail -3
echo 'DONE. Deliverable: release/SpicyTerminal.exe'
echo 'Cleanup handled: prefix+installer+workpath all live in /tmp (ephemeral).'
