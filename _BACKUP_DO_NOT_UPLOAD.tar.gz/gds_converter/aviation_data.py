"""
aviation_data.py — Knowledge base for the offline GDS itinerary parser.

Contains:
  - IATA airline codes + name aliases
  - Airports: IATA code -> full name, lat/lon, UTC offset, DST region
  - City aliases -> primary airport
  - Aircraft name normalization -> IATA type designator
  - Distance (haversine) + flight-time estimation helpers
"""

import math
from datetime import date

# =====================================================================
# AIRLINES : IATA code -> canonical name
# =====================================================================
AIRLINES = {
    "AA": "American Airlines", "AC": "Air Canada", "AF": "Air France",
    "AI": "Air India", "AM": "Aeromexico", "AT": "Royal Air Maroc",
    "AY": "Finnair", "AZ": "ITA Airways", "BA": "British Airways",
    "BR": "EVA Air", "CI": "China Airlines", "CX": "Cathay Pacific",
    "DL": "Delta Air Lines", "DT": "TAAG Angola Airlines", "EI": "Aer Lingus", "EK": "Emirates",
    "ET": "Ethiopian Airlines", "EY": "Etihad Airways", "FA": "FlySafair", "FI": "Icelandair",
    "GA": "Garuda Indonesia", "IB": "Iberia", "JL": "Japan Airlines",
    "JX": "Starlux Airlines", "KE": "Korean Air", "KL": "KLM",
    "LH": "Lufthansa", "LO": "LOT Polish Airlines", "LX": "Swiss International Air Lines",
    "MH": "Malaysia Airlines", "MS": "EgyptAir", "NH": "All Nippon Airways",
    "NZ": "Air New Zealand", "OK": "Czech Airlines", "OS": "Austrian Airlines",
    "OZ": "Asiana Airlines", "PR": "Philippine Airlines", "QF": "Qantas",
    "QR": "Qatar Airways", "SA": "South African Airways", "SK": "Scandinavian Airlines",
    "SN": "Brussels Airlines", "SQ": "Singapore Airlines", "SU": "Aeroflot",
    "SV": "Saudia", "TG": "Thai Airways", "TK": "Turkish Airlines",
    "TP": "TAP Air Portugal", "TR": "Scoot", "UA": "United Airlines",
    "UL": "SriLankan Airlines", "VS": "Virgin Atlantic", "WY": "Oman Air",
    "WS": "WestJet",
    # ---- extras ----
    "RJ": "Royal Jordanian", "ME": "Middle East Airlines", "GF": "Gulf Air",
    "KU": "Kuwait Airways", "FZ": "flydubai", "G9": "Air Arabia",
    "3O": "Air Arabia Maroc", "E5": "Air Arabia Egypt", "XY": "flynas",
    "F3": "flyadeal", "J9": "Jazeera Airways", "NP": "Nile Air",
    "SM": "Air Cairo", "NE": "Nesma Airlines", "AH": "Air Algerie",
    "TU": "Tunisair", "LY": "El Al", "IZ": "Arkia", "6H": "Israir",
    "OV": "SalamAir", "PC": "Pegasus Airlines", "VF": "AJet",
    "XQ": "SunExpress", "6E": "IndiGo", "SG": "SpiceJet", "QP": "Akasa Air",
    "4Y": "Discover Airlines",
    "UK": "Vistara", "IX": "Air India Express", "CA": "Air China",
    "MU": "China Eastern Airlines", "CZ": "China Southern Airlines",
    "HU": "Hainan Airlines", "MF": "XiamenAir", "3U": "Sichuan Airlines",
    "ZH": "Shenzhen Airlines", "FM": "Shanghai Airlines", "HO": "Juneyao Airlines",
    "SC": "Shandong Airlines", "VN": "Vietnam Airlines", "VJ": "VietJet Air",
    "QH": "Bamboo Airways", "FD": "Thai AirAsia", "AK": "AirAsia",
    "D7": "AirAsia X", "QZ": "Indonesia AirAsia", "Z2": "Philippines AirAsia",
    "JT": "Lion Air", "ID": "Batik Air", "QG": "Citilink", "SL": "Thai Lion Air",
    "OD": "Batik Air Malaysia", "5J": "Cebu Pacific", "BI": "Royal Brunei Airlines",
    "PG": "Bangkok Airways", "HX": "Hong Kong Airlines", "UO": "HK Express",
    "NX": "Air Macau", "MM": "Peach Aviation", "GK": "Jetstar Japan",
    "BC": "Skymark Airlines", "7G": "StarFlyer", "3K": "Jetstar Asia",
    "JQ": "Jetstar Airways", "VA": "Virgin Australia", "FJ": "Fiji Airways",
    "TN": "Air Tahiti Nui", "SB": "Aircalin", "PX": "Air Niugini",
    "HA": "Hawaiian Airlines", "AS": "Alaska Airlines", "B6": "JetBlue Airways",
    "WN": "Southwest Airlines", "NK": "Spirit Airlines", "F9": "Frontier Airlines",
    "G4": "Allegiant Air", "SY": "Sun Country Airlines", "Y4": "Volaris",
    "VB": "VivaAerobus", "AV": "Avianca", "LA": "LATAM Airlines",
    "AD": "Azul Brazilian Airlines", "G3": "GOL Linhas Aereas",
    "CM": "Copa Airlines", "AR": "Aerolineas Argentinas", "H2": "Sky Airline",
    "JA": "JetSMART", "BW": "Caribbean Airlines", "CU": "Cubana de Aviacion",
    "TS": "Air Transat", "PD": "Porter Airlines", "F8": "Flair Airlines",
    "RV": "Air Canada Rouge", "DE": "Condor", "EW": "Eurowings",
    "X3": "TUI fly", "U2": "easyJet", "FR": "Ryanair", "W6": "Wizz Air",
    "LS": "Jet2", "BY": "TUI Airways", "DY": "Norwegian Air Shuttle",
    "D8": "Norwegian Air International", "VY": "Vueling", "UX": "Air Europa",
    "I2": "Iberia Express", "OG": "PLAY Airlines", "HV": "Transavia",
    "TO": "Transavia France", "A3": "Aegean Airlines", "OA": "Olympic Air",
    "RO": "TAROM", "FB": "Bulgaria Air", "JU": "Air Serbia",
    "OU": "Croatia Airlines", "BT": "airBaltic", "BE": "BeOnd",
    "PK": "Pakistan International Airlines", "ER": "SereneAir", "PA": "Airblue",
    "BG": "Biman Bangladesh Airlines", "H9": "Himalaya Airlines", "RA": "Nepal Airlines",
    "KC": "Air Astana", "HY": "Uzbekistan Airways", "J2": "Azerbaijan Airlines",
    "A9": "Georgian Airways", "KQ": "Kenya Airways", "WB": "RwandAir",
    "PW": "Precision Air", "TC": "Air Tanzania", "FN": "Fastjet",
    "TM": "LAM Mozambique Airlines", "4Z": "Airlink", "MK": "Air Mauritius",
    "UU": "Air Austral", "HM": "Air Seychelles", "MD": "Air Madagascar",
    "BF": "French bee", "SS": "Corsair International",
}

# Extra aliases (lowercase) -> IATA. Canonical lowercased names are added automatically.
AIRLINE_ALIASES = {
    "american": "AA", "qatar": "QR", "qatar airways": "QR",
    "egyptair": "MS", "egypt air": "MS", "egyptair airlines": "MS",
    "turkish": "TK", "lufthansa": "LH", "emirates": "EK",
    "etihad": "EY", "etihad airways": "EY", "singapore": "SQ", "singapore airlines": "SQ",
    "british": "BA", "delta": "DL", "united": "UA",
    "cathay": "CX", "ana": "NH", "all nippon": "NH", "jal": "JL",
    "klm": "KL", "virgin": "VS", "qantas": "QF", "eva": "BR",
    "korean": "KE", "asiana": "OZ", "aeroflot": "SU",
    "saudia": "SV", "saudi arabian airlines": "SV", "saudi": "SV",
    "royal jordanian": "RJ", "oman air": "WY", "gulf air": "GF",
    "flydubai": "FZ", "air arabia": "G9", "kuwait airways": "KU",
    "middle east airlines": "ME", "mea": "ME",
    "swiss": "LX", "austrian": "OS", "finnair": "AY", "sas": "SK",
    "scandinavian": "SK", "lot": "LO", "tap": "TP", "tap portugal": "TP",
    "flysafair": "FA", "fly safair": "FA", "safair": "FA",
    "taag": "DT", "taag angola": "DT", "taag angola airlines": "DT",
    "south african": "SA", "south african airways": "SA",
    "aer lingus": "EI", "icelandair": "FI", "norwegian": "DY",
    "pegasus": "PC", "sunexpress": "XQ", "sun express": "XQ", "ajet": "VF",
    "wizz": "W6", "wizz air": "W6", "ryanair": "FR", "easyjet": "U2",
    "vueling": "VY", "air europa": "UX", "condor": "DE", "eurowings": "EW",
    "aegean": "A3", "air serbia": "JU", "croatia airlines": "OU",
    "airbaltic": "BT", "air baltic": "BT", "tarom": "RO",
    "air cairo": "SM", "nile air": "NP", "air algerie": "AH",
    "tunisair": "TU", "el al": "LY", "salamair": "OV",
    "indigo": "6E", "spicejet": "SG", "akasa": "QP", "vistara": "UK",
    "discover": "4Y", "discover airlines": "4Y", "eurowings discover": "4Y",
    "air china": "CA", "china eastern": "MU", "china southern": "CZ",
    "hainan": "HU", "xiamenair": "MF", "xiamen air": "MF",
    "sichuan airlines": "3U", "shenzhen airlines": "ZH",
    "vietnam airlines": "VN", "vietjet": "VJ", "bamboo airways": "QH",
    "airasia": "AK", "batik air": "ID", "malindo": "OD", "lion air": "JT",
    "citilink": "QG", "garuda": "GA", "cebu pacific": "5J",
    "royal brunei": "BI", "bangkok airways": "PG", "hong kong airlines": "HX",
    "hk express": "UO", "peach": "MM", "jetstar": "JQ", "jetstar asia": "3K",
    "virgin australia": "VA", "fiji airways": "FJ", "air tahiti nui": "TN",
    "aircalin": "SB", "air niugini": "PX", "hawaiian": "HA",
    "alaska": "AS", "jetblue": "B6", "southwest": "WN", "spirit": "NK",
    "frontier": "F9", "allegiant": "G4", "sun country": "SY",
    "volaris": "Y4", "viva aerobus": "VB", "vivaaerobus": "VB",
    "avianca": "AV", "latam": "LA", "azul": "AD", "gol": "G3",
    "copa": "CM", "aerolineas": "AR", "aerolineas argentinas": "AR",
    "sky airline": "H2", "jetsmart": "JA", "caribbean airlines": "BW",
    "cubana": "CU", "air transat": "TS", "porter": "PD", "flair": "F8",
    "westjet": "WS", "play": "OG", "french bee": "BF", "corsair": "SS",
    "pia": "PK", "biman": "BG", "srilankan": "UL", "air astana": "KC",
    "uzbekistan airways": "HY", "uzbekistan airlines": "HY",
    "azerbaijan airlines": "J2", "azal": "J2", "georgian airways": "A9",
    "kenya airways": "KQ", "rwandair": "WB", "precision air": "PW",
    "air tanzania": "TC", "fastjet": "FN", "lam": "TM", "airlink": "4Z",
    "air mauritius": "MK", "air austral": "UU", "air seychelles": "HM",
    "air madagascar": "MD", "starlux": "JX", "scoot": "TR",
    "malaysia airlines": "MH", "thai": "TG", "china airlines": "CI",
    "philippine airlines": "PR", "air india": "AI", "air india express": "IX",
}

# Auto-add canonical names as aliases (longest-first matching happens in parser)
for _code, _name in AIRLINES.items():
    AIRLINE_ALIASES.setdefault(_name.lower(), _code)

# 2-letter codes that collide with common UPPERCASE English words/acronyms.
# Matches for these require corroboration (alias in text, no space before number,
# or a valid date token nearby).
AMBIGUOUS_CODES = {
    "AM", "AT", "TO", "AS", "IS", "ON", "NO", "OK", "GO", "BY", "BE", "IT",
    "IN", "OR", "DO", "US", "WE", "ME", "MY", "SO", "AN", "IF", "HE", "HA",
    "ID", "LA", "MA", "MD", "MM", "MO", "MU", "MT", "LO", "NE", "PA", "AD",
    "UP", "EH", "EX", "PS",
}

# =====================================================================
# AIRPORTS : code -> dict(name, lat, lon, off (std UTC), dst region)
# dst regions: US, EU, AU, NZ, SHSEP (Chile), EG, NONE
# =====================================================================
A = lambda name, lat, lon, off, dst="NONE": {"name": name, "lat": lat, "lon": lon, "off": float(off), "dst": dst}

AIRPORTS = {
    # North America
    "JFK": A("JOHN F KENNEDY INTL", 40.641, -73.778, -5, "US"),
    "EWR": A("NEWARK LIBERTY INTL", 40.690, -74.175, -5, "US"),
    "LGA": A("LAGUARDIA", 40.777, -73.874, -5, "US"),
    "LAX": A("LOS ANGELES INTL", 33.942, -118.408, -8, "US"),
    "ORD": A("CHICAGO O HARE INTL", 41.974, -87.907, -6, "US"),
    "ATL": A("HARTSFIELD JACKSON INTL", 33.641, -84.428, -5, "US"),
    "DFW": A("DALLAS FORT WORTH INTL", 32.900, -97.040, -6, "US"),
    "MIA": A("MIAMI INTL", 25.796, -80.287, -5, "US"),
    "SFO": A("SAN FRANCISCO INTL", 37.621, -122.379, -8, "US"),
    "SEA": A("SEATTLE TACOMA INTL", 47.450, -122.309, -8, "US"),
    "BOS": A("BOSTON LOGAN INTL", 42.366, -71.010, -5, "US"),
    "IAD": A("WASHINGTON DULLES INTL", 38.953, -77.457, -5, "US"),
    "DCA": A("RONALD REAGAN NATIONAL", 38.851, -77.040, -5, "US"),
    "BWI": A("BALTIMORE WASHINGTON INTL", 39.177, -76.668, -5, "US"),
    "PHL": A("PHILADELPHIA INTL", 39.874, -75.242, -5, "US"),
    "DTW": A("DETROIT METRO", 42.216, -83.355, -5, "US"),
    "MSP": A("MINNEAPOLIS ST PAUL INTL", 44.885, -93.222, -6, "US"),
    "CLT": A("CHARLOTTE DOUGLAS INTL", 35.214, -80.947, -5, "US"),
    "DEN": A("DENVER INTL", 39.856, -104.674, -7, "US"),
    "PHX": A("PHOENIX SKY HARBOR INTL", 33.437, -112.008, -7),
    "LAS": A("HARRY REID INTL", 36.084, -115.154, -8, "US"),
    "SAN": A("SAN DIEGO INTL", 32.734, -117.193, -8, "US"),
    "PDX": A("PORTLAND INTL", 45.590, -122.595, -8, "US"),
    "SLC": A("SALT LAKE CITY INTL", 40.790, -111.979, -7, "US"),
    "AUS": A("AUSTIN BERGSTROM INTL", 30.198, -97.666, -6, "US"),
    "IAH": A("GEORGE BUSH INTL", 29.990, -95.337, -6, "US"),
    "MCO": A("ORLANDO INTL", 28.431, -81.308, -5, "US"),
    "TPA": A("TAMPA INTL", 27.976, -82.533, -5, "US"),
    "FLL": A("FORT LAUDERDALE HOLLYWOOD INTL", 26.074, -80.151, -5, "US"),
    "HNL": A("DANIEL K INOUYE INTL", 21.325, -157.925, -10),
    "OGG": A("KAHULUI", 20.899, -156.431, -10),
    "ANC": A("TED STEVENS ANCHORAGE INTL", 61.174, -149.976, -9, "US"),
    "YYZ": A("TORONTO PEARSON INTL", 43.678, -79.625, -5, "US"),
    "YVR": A("VANCOUVER INTL", 49.197, -123.182, -8, "US"),
    "YYC": A("CALGARY INTL", 51.131, -114.010, -7, "US"),
    "YUL": A("MONTREAL TRUDEAU INTL", 45.471, -73.741, -5, "US"),
    "YOW": A("OTTAWA MACDONALD CARTIER INTL", 45.323, -75.669, -5, "US"),
    "YEG": A("EDMONTON INTL", 53.310, -113.580, -7, "US"),
    "YWG": A("WINNIPEG INTL", 49.910, -97.240, -6, "US"),
    "YHZ": A("HALIFAX STANFIELD INTL", 44.881, -63.509, -4, "US"),
    "MEX": A("MEXICO CITY INTL", 19.436, -99.072, -6),
    "GDL": A("GUADALAJARA INTL", 20.522, -103.311, -6),
    "MTY": A("MONTERREY INTL", 25.779, -100.107, -6),
    "CUN": A("CANCUN INTL", 21.042, -86.874, -5),
    "PTY": A("TOCUMEN INTL", 9.071, -79.384, -5),
    "SJO": A("JUAN SANTAMARIA INTL", 9.994, -84.209, -6),
    "SAL": A("EL SALVADOR INTL", 13.441, -89.056, -6),
    "SJU": A("LUIS MUNOZ MARIN INTL", 18.439, -66.002, -4),
    "PUJ": A("PUNTA CANA INTL", 18.567, -68.363, -4),
    "MBJ": A("SANGSTER INTL", 18.504, -77.913, -5),
    "NAS": A("LYNDEN PINDLING INTL", 25.039, -77.466, -5, "US"),
    "HAV": A("JOSE MARTI INTL", 22.989, -82.409, -5, "US"),
    # South America
    "GRU": A("SAO PAULO GUARULHOS INTL", -23.436, -46.473, -3),
    "GIG": A("RIO GALEAO INTL", -22.810, -43.251, -3),
    "BSB": A("BRASILIA INTL", -15.869, -47.921, -3),
    "MAO": A("MANAUS EDUARDO GOMES INTL", -3.039, -60.050, -4),
    "EZE": A("BUENOS AIRES EZEIZA", -34.822, -58.536, -3),
    "SCL": A("SANTIAGO INTL", -33.393, -70.786, -4, "SHSEP"),
    "BOG": A("BOGOTA EL DORADO INTL", 4.702, -74.147, -5),
    "MDE": A("JOSE MARIA CORDOVA INTL", 6.165, -75.423, -5),
    "CTG": A("RAFAEL NUNEZ INTL", 10.442, -75.513, -5),
    "LIM": A("LIMA JORGE CHAVEZ INTL", -12.022, -77.114, -5),
    "UIO": A("MARISCAL SUCRE INTL", -0.129, -78.358, -5),
    "GYE": A("JOSE JOAQUIN DE OLMEDO INTL", -2.157, -79.884, -5),
    "CCS": A("SIMON BOLIVAR INTL", 10.601, -66.991, -4),
    "VVI": A("VIRU VIRU INTL", -17.645, -63.135, -4),
    "ASU": A("SILVIO PETTIROSSI INTL", -25.240, -57.519, -4, "AU"),
    "MVD": A("CARRASCO INTL", -34.838, -56.031, -3),
    # Europe
    "LHR": A("LONDON HEATHROW", 51.470, -0.454, 0, "EU"),
    "LGW": A("LONDON GATWICK", 51.154, -0.182, 0, "EU"),
    "STN": A("LONDON STANSTED", 51.885, 0.235, 0, "EU"),
    "LTN": A("LONDON LUTON", 51.875, -0.368, 0, "EU"),
    "LCY": A("LONDON CITY", 51.505, 0.055, 0, "EU"),
    "MAN": A("MANCHESTER INTL", 53.365, -2.273, 0, "EU"),
    "EDI": A("EDINBURGH INTL", 55.950, -3.373, 0, "EU"),
    "BHX": A("BIRMINGHAM INTL", 52.454, -1.748, 0, "EU"),
    "GLA": A("GLASGOW INTL", 55.871, -4.433, 0, "EU"),
    "DUB": A("DUBLIN INTL", 53.421, -6.270, 0, "EU"),
    "CDG": A("PARIS CHARLES DE GAULLE", 49.010, 2.548, 1, "EU"),
    "ORY": A("PARIS ORLY", 48.723, 2.379, 1, "EU"),
    "NCE": A("NICE COTE D AZUR", 43.658, 7.216, 1, "EU"),
    "LYS": A("LYON SAINT EXUPERY", 45.726, 5.081, 1, "EU"),
    "MRS": A("MARSEILLE PROVENCE", 43.437, 5.215, 1, "EU"),
    "FRA": A("FRANKFURT INTL", 50.038, 8.562, 1, "EU"),
    "MUC": A("MUNICH INTL", 48.354, 11.786, 1, "EU"),
    "BER": A("BERLIN BRANDENBURG", 52.367, 13.503, 1, "EU"),
    "DUS": A("DUSSELDORF INTL", 51.290, 6.767, 1, "EU"),
    "HAM": A("HAMBURG INTL", 53.630, 10.007, 1, "EU"),
    "STR": A("STUTTGART INTL", 48.690, 9.222, 1, "EU"),
    "CGN": A("COLOGNE BONN", 50.866, 7.143, 1, "EU"),
    "ZRH": A("ZURICH INTL", 47.465, 8.549, 1, "EU"),
    "GVA": A("GENEVA INTL", 46.237, 6.109, 1, "EU"),
    "VIE": A("VIENNA INTL", 48.110, 16.570, 1, "EU"),
    "AMS": A("AMSTERDAM SCHIPHOL", 52.311, 4.768, 1, "EU"),
    "BRU": A("BRUSSELS INTL", 50.901, 4.484, 1, "EU"),
    "LUX": A("LUXEMBOURG FINDEL", 49.627, 6.205, 1, "EU"),
    "MAD": A("MADRID BARAJAS", 40.498, -3.568, 1, "EU"),
    "BCN": A("BARCELONA EL PRAT", 41.297, 2.083, 1, "EU"),
    "AGP": A("MALAGA COSTA DEL SOL", 36.675, -4.499, 1, "EU"),
    "PMI": A("PALMA DE MALLORCA", 39.552, 2.739, 1, "EU"),
    "IBZ": A("IBIZA", 38.873, 1.373, 1, "EU"),
    "BIO": A("BILBAO INTL", 43.301, -2.911, 1, "EU"),
    "TFS": A("TENERIFE SOUTH", 28.045, -16.573, 0, "EU"),
    "LPA": A("GRAN CANARIA", 27.932, -15.387, 0, "EU"),
    "LIS": A("LISBON HUMBERTO DELGADO", 38.774, -9.134, 0, "EU"),
    "OPO": A("PORTO FRANCISCO SA CARNEIRO", 41.248, -8.681, 0, "EU"),
    "FCO": A("ROME FIUMICINO", 41.800, 12.239, 1, "EU"),
    "MXP": A("MILAN MALPENSA", 45.631, 8.728, 1, "EU"),
    "LIN": A("MILAN LINATE", 45.449, 9.278, 1, "EU"),
    "VCE": A("VENICE MARCO POLO", 45.505, 12.352, 1, "EU"),
    "NAP": A("NAPLES INTL", 40.886, 14.291, 1, "EU"),
    "PMO": A("PALERMO FALCONE BORSELLINO", 38.176, 13.091, 1, "EU"),
    "CTA": A("CATANIA FONTANAROSSA", 37.467, 15.066, 1, "EU"),
    "ATH": A("ATHENS ELEFTHERIOS VENIZELOS", 37.936, 23.945, 2, "EU"),
    "SKG": A("THESSALONIKI MAKEDONIA", 40.520, 22.971, 2, "EU"),
    "CPH": A("COPENHAGEN KASTRUP", 55.618, 12.656, 1, "EU"),
    "BLL": A("BILLUND", 55.740, 9.152, 1, "EU"),
    "ARN": A("STOCKHOLM ARLANDA", 59.652, 17.919, 1, "EU"),
    "GOT": A("GOTHENBURG LANDVETTER", 57.663, 12.280, 1, "EU"),
    "OSL": A("OSLO GARDERMOEN", 60.194, 11.100, 1, "EU"),
    "HEL": A("HELSINKI VANTAA", 60.317, 24.963, 2, "EU"),
    "WAW": A("WARSAW CHOPIN", 52.166, 20.967, 1, "EU"),
    "PRG": A("PRAGUE VACLAV HAVEL", 50.101, 14.260, 1, "EU"),
    "BUD": A("BUDAPEST LISZT FERENC INTL", 47.439, 19.252, 1, "EU"),
    "OTP": A("BUCHAREST HENRI COANDA", 44.571, 26.085, 2, "EU"),
    "SOF": A("SOFIA", 42.697, 23.411, 2, "EU"),
    "BEG": A("BELGRADE NIKOLA TESLA", 44.818, 20.309, 1, "EU"),
    "ZAG": A("ZAGREB FRANJO TUDMAN", 45.743, 16.069, 1, "EU"),
    "LJU": A("LJUBLJANA JOZE PUCNIK", 46.224, 14.458, 1, "EU"),
    "RIX": A("RIGA INTL", 56.924, 23.971, 2, "EU"),
    "VNO": A("VILNIUS INTL", 54.634, 25.286, 2, "EU"),
    "TLL": A("TALLINN LENNART MERI", 59.413, 24.833, 2, "EU"),
    "LCA": A("LARNACA INTL", 34.875, 33.625, 2, "EU"),
    "MLA": A("MALTA INTL", 35.858, 14.478, 1, "EU"),
    "KEF": A("KEFLAVIK INTL", 63.985, -22.606, 0),
    "SVO": A("MOSCOW SHEREMETYEVO", 55.973, 37.413, 3),
    "DME": A("MOSCOW DOMODEDOVO", 55.409, 37.906, 3),
    "LED": A("ST PETERSBURG PULKOVO", 59.800, 30.273, 3),
    "KBP": A("BORYSPIL INTL", 50.345, 30.895, 2, "EU"),
    # Middle East
    "IST": A("ISTANBUL AIRPORT", 41.275, 28.752, 3),
    "SAW": A("SABIHA GOKCEN INTL", 40.899, 29.309, 3),
    "ESB": A("ANKARA ESENBOGA INTL", 40.128, 32.995, 3),
    "AYT": A("ANTALYA INTL", 36.899, 30.793, 3),
    "DXB": A("DUBAI INTL", 25.253, 55.366, 4),
    "DWC": A("AL MAKTOUM INTL", 24.896, 55.161, 4),
    "AUH": A("ABU DHABI INTL (ZAYED)", 24.433, 54.651, 4),
    "SHJ": A("SHARJAH INTL", 25.329, 55.517, 4),
    "DOH": A("HAMAD INTL", 25.273, 51.608, 3),
    "BAH": A("BAHRAIN INTL", 26.271, 50.634, 3),
    "KWI": A("KUWAIT INTL", 29.227, 47.969, 3),
    "RUH": A("KING KHALID INTL", 24.958, 46.699, 3),
    "JED": A("KING ABDULAZIZ INTL", 21.680, 39.157, 3),
    "DMM": A("KING FAHD INTL", 26.471, 49.798, 3),
    "MED": A("PRINCE MOHAMMAD BIN ABDULAZIZ INTL", 24.553, 39.705, 3),
    "MCT": A("MUSCAT INTL", 23.593, 58.284, 4),
    "AMM": A("QUEEN ALIA INTL", 31.723, 35.993, 3),
    "BEY": A("BEIRUT INTL", 33.821, 35.488, 2, "EU"),
    "TLV": A("BEN GURION INTL", 32.011, 34.887, 2, "EU"),
    "BGW": A("BAGHDAD INTL", 33.263, 44.235, 3),
    "EBL": A("ERBIL INTL", 36.238, 43.963, 3),
    "BSR": A("BASRA INTL", 30.549, 47.662, 3),
    "IKA": A("TEHRAN IMAM KHOMEINI INTL", 35.416, 51.152, 3.5, "EU"),
    # Africa
    "CAI": A("CAIRO INTL", 30.122, 31.406, 2, "EG"),
    "HBE": A("BORG EL ARAB INTL", 30.918, 29.696, 2, "EG"),
    "HRG": A("HURGHADA INTL", 27.178, 33.799, 2, "EG"),
    "SSH": A("SHARM EL SHEIKH INTL", 27.977, 34.395, 2, "EG"),
    "LXR": A("LUXOR INTL", 25.671, 32.707, 2, "EG"),
    "ASW": A("ASWAN INTL", 23.964, 32.820, 2, "EG"),
    "CMN": A("MOHAMMED V INTL", 33.368, -7.590, 1),
    "RAK": A("MARRAKESH MENARA", 31.607, -8.036, 1),
    "ALG": A("ALGIERS INTL", 36.691, 3.215, 1),
    "TUN": A("TUNIS CARTHAGE INTL", 36.851, 10.227, 1),
    "MJI": A("MITIGA INTL", 32.895, 13.276, 2),
    "TIP": A("TRIPOLI INTL", 32.667, 13.160, 2),
    "KRT": A("KHARTOUM INTL", 15.590, 32.553, 2),
    "JNB": A("O R TAMBO INTL", -26.137, 28.241, 2),
    "GRJ": A("GEORGE", -34.006, 22.379, 2),
    "PLZ": A("CHIEF DAWID STUURMAN INTL", -33.985, 25.617, 2),
    "NBJ": A("DR ANTONIO AGOSTINHO NETO INTL", -9.050, 13.499, 1),
    "CPT": A("CAPE TOWN INTL", -33.972, 18.602, 2),
    "DUR": A("KING SHAKA INTL", -29.614, 31.120, 2),
    "NBO": A("JOMO KENYATTA INTL", -1.319, 36.928, 3),
    "MBA": A("MOI INTL", -4.035, 39.594, 3),
    "ADD": A("ADDIS ABABA BOLE INTL", 8.978, 38.799, 3),
    "LOS": A("MURTALA MUHAMMED INTL", 6.577, 3.321, 1),
    "ABV": A("NNAMDI AZIKIWE INTL", 9.007, 7.263, 1),
    "ACC": A("KOTOKA INTL", 5.605, -0.167, 0),
    "DSS": A("BLAISE DIAGNE INTL", 14.670, -17.073, 0),
    "DLA": A("DOUALA INTL", 4.006, 9.720, 1),
    "EBB": A("ENTEBBE INTL", 0.042, 32.444, 3),
    "DAR": A("JULIUS NYERERE INTL", -6.878, 39.203, 3),
    "ZNZ": A("ABEID AMANI KARUME INTL", -6.222, 39.225, 3),
    "HRE": A("ROBERT GABRIEL MUGABE INTL", -17.932, 31.093, 2),
    "LUN": A("KENNETH KAUNDA INTL", -15.331, 28.453, 2),
    "MRU": A("SIR SEEWOOSAGUR RAMGOOLAM INTL", -20.430, 57.684, 4),
    "TNR": A("IVATO INTL", -18.797, 47.479, 3),
    "KGL": A("KIGALI INTL", -1.969, 30.139, 2),
    # Asia
    "DEL": A("INDIRA GANDHI INTL", 28.556, 77.100, 5.5),
    "BOM": A("CHHATRAPATI SHIVAJI INTL", 19.090, 72.866, 5.5),
    "MAA": A("CHENNAI INTL", 12.994, 80.171, 5.5),
    "BLR": A("KEMPEGOWDA INTL", 13.199, 77.707, 5.5),
    "HYD": A("RAJIV GANDHI INTL", 17.240, 78.429, 5.5),
    "CCU": A("NETAJI SUBHAS CHANDRA BOSE INTL", 22.655, 88.447, 5.5),
    "GOI": A("MANOHAR INTL", 15.381, 73.831, 5.5),
    "COK": A("COCHIN INTL", 10.152, 76.402, 5.5),
    "CCJ": A("CALICUT INTL", 11.137, 75.955, 5.5),
    "TRV": A("TRIVANDRUM INTL", 8.482, 76.920, 5.5),
    "LKO": A("CHAUDHARY CHARAN SINGH INTL", 26.761, 80.889, 5.5),
    "JAI": A("JAIPUR INTL", 26.824, 75.812, 5.5),
    "ATQ": A("SRI GURU RAM DASS JEE INTL", 31.710, 74.797, 5.5),
    "CJB": A("COIMBATORE INTL", 11.030, 77.043, 5.5),
    "TRZ": A("TIRUCHIRAPPALLI INTL", 10.765, 78.710, 5.5),
    "IXE": A("MANGALORE INTL", 12.961, 74.890, 5.5),
    "IXM": A("MADURAI", 9.835, 78.093, 5.5),
    "IXB": A("BAGDOGRA", 26.681, 88.329, 5.5),
    "PAT": A("JAY PRAKASH NARAYAN INTL", 25.591, 85.088, 5.5),
    "VTZ": A("VISAKHAPATNAM", 17.721, 83.224, 5.5),
    "VGA": A("VIJAYAWADA INTL", 16.530, 80.798, 5.5),
    "IDR": A("DEVI AHILYA BAI HOLKAR", 22.722, 75.801, 5.5),
    "IXC": A("CHANDIGARH INTL", 30.673, 76.788, 5.5),
    "STV": A("SURAT", 21.114, 72.742, 5.5),
    "BBI": A("BIJU PATNAIK INTL", 20.244, 85.818, 5.5),
    "IXU": A("AURANGABAD", 19.863, 75.398, 5.5),
    "SJD": A("LOS CABOS INTL", 23.152, -109.721, -7),
    # v2.6 - Osaka Itami (route-database coverage, NH HND-ITM shuttle)
    "ITM": A("OSAKA ITAMI", 34.786, 135.438, 9),
    "MLE": A("VELANA INTL", 4.192, 73.529, 5),
    "KHI": A("JINNAH INTL", 24.907, 67.161, 5),
    "LHE": A("ALLAMA IQBAL INTL", 31.522, 74.404, 5),
    "ISB": A("ISLAMABAD INTL", 33.549, 72.826, 5),
    "DAC": A("HAZRAT SHAHJALAL INTL", 23.843, 90.398, 6),
    "KTM": A("TRIBHUVAN INTL", 27.697, 85.359, 5.75),
    "BKK": A("SUVARNABHUMI INTL", 13.690, 100.750, 7),
    "DMK": A("DON MUEANG INTL", 13.913, 100.607, 7),
    "HKT": A("PHUKET INTL", 8.113, 98.317, 7),
    "CNX": A("CHIANG MAI INTL", 18.767, 98.963, 7),
    "KUL": A("KUALA LUMPUR INTL", 2.746, 101.707, 8),
    "PEN": A("PENANG INTL", 5.297, 100.277, 8),
    "SIN": A("SINGAPORE CHANGI", 1.364, 103.992, 8),
    "CGK": A("SOEKARNO HATTA INTL", -6.126, 106.656, 7),
    "DPS": A("NGURAH RAI INTL", -8.748, 115.167, 8),
    "SUB": A("JUANDA INTL", -7.380, 112.787, 7),
    "MNL": A("NINOY AQUINO INTL", 14.509, 121.020, 8),
    "CEB": A("MACTAN CEBU INTL", 10.313, 123.983, 8),
    "SGN": A("TAN SON NHAT INTL", 10.819, 106.652, 7),
    "HAN": A("NOI BAI INTL", 21.214, 105.803, 7),
    "DAD": A("DA NANG INTL", 16.044, 108.199, 7),
    "PNH": A("PHNOM PENH INTL", 11.547, 104.844, 7),
    "REP": A("SIEM REAP ANGKOR INTL", 13.411, 103.813, 7),
    "VTE": A("WATTAY INTL", 17.988, 102.563, 7),
    "RGN": A("YANGON INTL", 16.907, 96.133, 6.5),
    "BWN": A("BRUNEI INTL", 4.944, 114.928, 8),
    "HKG": A("HONG KONG INTL", 22.308, 113.919, 8),
    "MFM": A("MACAU INTL", 22.150, 113.592, 8),
    "TPE": A("TAIWAN TAOYUAN INTL", 25.080, 121.234, 8),
    "KHH": A("KAOHSIUNG INTL", 22.577, 120.350, 8),
    "PEK": A("BEIJING CAPITAL INTL", 40.080, 116.603, 8),
    "PKX": A("BEIJING DAXING INTL", 39.510, 116.411, 8),
    "PVG": A("SHANGHAI PUDONG INTL", 31.144, 121.808, 8),
    "SHA": A("SHANGHAI HONGQIAO INTL", 31.198, 121.336, 8),
    "CAN": A("GUANGZHOU BAIYUN INTL", 23.392, 113.299, 8),
    "SZX": A("SHENZHEN BAO AN INTL", 22.639, 113.811, 8),
    "CTU": A("CHENGDU SHUANGLIU INTL", 30.579, 103.947, 8),
    "TFU": A("CHENGDU TIANFU INTL", 30.319, 104.445, 8),
    "CKG": A("CHONGQING JIANGBEI INTL", 29.719, 106.642, 8),
    "XIY": A("XI AN XIANYANG INTL", 34.447, 108.752, 8),
    "HGH": A("HANGZHOU XIAOSHAN INTL", 30.230, 120.434, 8),
    "NKG": A("NANJING LUKOU INTL", 31.742, 118.862, 8),
    "ICN": A("INCHEON INTL", 37.460, 126.441, 9),
    "GMP": A("GIMPO INTL", 37.558, 126.791, 9),
    "PUS": A("GIMHAE INTL", 35.180, 128.938, 9),
    "NRT": A("NARITA INTL", 35.772, 140.393, 9),
    "HND": A("TOKYO HANEDA", 35.549, 139.780, 9),
    "KIX": A("KANSAI INTL", 34.435, 135.244, 9),
    "FUK": A("FUKUOKA", 33.586, 130.451, 9),
    "CTS": A("NEW CHITOSE", 42.775, 141.692, 9),
    "NGO": A("CHUBU CENTRAIR INTL", 34.858, 136.805, 9),
    "OKA": A("NAHA", 26.196, 127.646, 9),
    "ULA": A("ULAANBAATAR CHINGGIS KHAAN INTL", 47.651, 106.822, 8),
    "TAS": A("TASHKENT ISLAM KARIMOV INTL", 41.258, 69.281, 5),
    "ALA": A("ALMATY INTL", 43.352, 77.041, 5),
    "NQZ": A("NURSULTAN NAZARBAYEV INTL", 51.022, 71.467, 5),
    "FRU": A("MANAS INTL", 43.061, 74.478, 6),
    "TBS": A("TBILISI INTL", 41.669, 44.955, 4),
    "EVN": A("ZVARTNOTS INTL", 40.147, 44.396, 4),
    "GYD": A("HEYDAR ALIYEV INTL", 40.468, 50.047, 4),
    # Oceania
    "SYD": A("SYDNEY KINGSFORD SMITH", -33.940, 151.175, 10, "AU"),
    "MEL": A("MELBOURNE TULLAMARINE", -37.669, 144.841, 10, "AU"),
    "BNE": A("BRISBANE", -27.384, 153.118, 10),
    "PER": A("PERTH", -31.940, 115.967, 8),
    "ADL": A("ADELAIDE", -34.945, 138.531, 9.5, "AU"),
    "CBR": A("CANBERRA", -35.306, 149.195, 10, "AU"),
    "AKL": A("AUCKLAND INTL", -37.008, 174.785, 12, "NZ"),
    "WLG": A("WELLINGTON INTL", -41.327, 174.805, 12, "NZ"),
    "CHC": A("CHRISTCHURCH INTL", -43.489, 172.532, 12, "NZ"),
    "NAN": A("NADI INTL", -17.755, 177.443, 12),
    "PPT": A("FAAA INTL", -17.554, -149.611, -10),
    "GUM": A("GUAM ANTONIO B WON PAT INTL", 13.483, 144.796, 10),
}

# =====================================================================
# CITY ALIASES -> primary airport (lowercase)
# =====================================================================
CITY_ALIASES = {
    "new york": "JFK", "nyc": "JFK", "new york city": "JFK",
    "newark": "EWR", "london": "LHR", "paris": "CDG", "tokyo": "HND",
    "osaka": "KIX", "seoul": "ICN", "busan": "PUS", "beijing": "PEK",
    "shanghai": "PVG", "guangzhou": "CAN", "shenzhen": "SZX",
    "chengdu": "TFU", "chongqing": "CKG", "hangzhou": "HGH",
    "nanjing": "NKG", "xian": "XIY", "xi'an": "XIY",
    "moscow": "SVO", "st petersburg": "LED", "saint petersburg": "LED",
    "kiev": "KBP", "kyiv": "KBP", "dubai": "DXB", "abu dhabi": "AUH",
    "sharjah": "SHJ", "doha": "DOH", "bahrain": "BAH", "manama": "BAH",
    "kuwait": "KWI", "kuwait city": "KWI", "riyadh": "RUH", "jeddah": "JED",
    "dammam": "DMM", "medina": "MED", "muscat": "MCT", "amman": "AMM",
    "beirut": "BEY", "tel aviv": "TLV", "jerusalem": "TLV",
    "baghdad": "BGW", "erbil": "EBL", "basra": "BSR", "tehran": "IKA",
    "istanbul": "IST", "ankara": "ESB", "antalya": "AYT",
    "cairo": "CAI", "alexandria": "HBE", "hurghada": "HRG",
    "sharm el sheikh": "SSH", "luxor": "LXR", "aswan": "ASW",
    "casablanca": "CMN", "marrakech": "RAK", "marrakesh": "RAK",
    "algiers": "ALG", "tunis": "TUN", "tripoli": "MJI",
    "khartoum": "KRT", "johannesburg": "JNB", "joburg": "JNB",
    "luanda": "NBJ", "port elizabeth": "PLZ", "gqeberha": "PLZ",
    "cape town": "CPT", "durban": "DUR", "nairobi": "NBO",
    "mombasa": "MBA", "addis ababa": "ADD", "lagos": "LOS",
    "abuja": "ABV", "accra": "ACC", "dakar": "DSS", "douala": "DLA",
    "entebbe": "EBB", "kampala": "EBB", "dar es salaam": "DAR",
    "zanzibar": "ZNZ", "harare": "HRE", "lusaka": "LUN",
    "mauritius": "MRU", "antananarivo": "TNR", "kigali": "KGL",
    "delhi": "DEL", "new delhi": "DEL", "mumbai": "BOM",
    "chennai": "MAA", "bangalore": "BLR", "bengaluru": "BLR",
    "hyderabad": "HYD", "kolkata": "CCU", "goa": "GOI", "kochi": "COK",
    "kozhikode": "CCJ", "calicut": "CCJ", "trivandrum": "TRV",
    "thiruvananthapuram": "TRV", "lucknow": "LKO", "jaipur": "JAI",
    "amritsar": "ATQ", "coimbatore": "CJB", "tiruchirappalli": "TRZ",
    "trichy": "TRZ", "mangalore": "IXE", "madurai": "IXM",
    "bagdogra": "IXB", "patna": "PAT", "visakhapatnam": "VTZ",
    "vizag": "VTZ", "vijayawada": "VGA", "indore": "IDR",
    "chandigarh": "IXC", "surat": "STV", "bhubaneswar": "BBI",
    "aurangabad": "IXU",
    "los cabos": "SJD", "cabo san lucas": "SJD", "cabo": "SJD",
    "san jose del cabo": "SJD",
    "colombo": "CMB", "male": "MLE", "maldives": "MLE",
    "karachi": "KHI", "lahore": "LHE", "islamabad": "ISB",
    "dhaka": "DAC", "kathmandu": "KTM", "bangkok": "BKK",
    "phuket": "HKT", "chiang mai": "CNX", "kuala lumpur": "KUL", "kl": "KUL",
    "penang": "PEN", "singapore": "SIN", "jakarta": "CGK", "bali": "DPS",
    "denpasar": "DPS", "surabaya": "SUB", "manila": "MNL", "cebu": "CEB",
    "hanoi": "HAN", "ho chi minh": "SGN", "saigon": "SGN",
    "ho chi minh city": "SGN", "da nang": "DAD", "phnom penh": "PNH",
    "siem reap": "REP", "vientiane": "VTE", "yangon": "RGN",
    "brunei": "BWN", "bandar seri begawan": "BWN", "hong kong": "HKG",
    "macau": "MFM", "taipei": "TPE", "kaohsiung": "KHH",
    "sydney": "SYD", "melbourne": "MEL", "brisbane": "BNE",
    "perth": "PER", "adelaide": "ADL", "canberra": "CBR",
    "auckland": "AKL", "wellington": "WLG", "christchurch": "CHC",
    "fiji": "NAN", "nadi": "NAN", "tahiti": "PPT", "guam": "GUM",
    "los angeles": "LAX", "la": "LAX", "san francisco": "SFO",
    "chicago": "ORD", "washington": "IAD", "washington dc": "IAD", "dc": "IAD",
    "boston": "BOS", "miami": "MIA", "atlanta": "ATL", "dallas": "DFW",
    "houston": "IAH", "denver": "DEN", "seattle": "SEA",
    "love field": "DAL", "dallas love": "DAL", "hobby": "HOU",
    "william p hobby": "HOU", "itami": "ITM", "osaka itami": "ITM",
    "las vegas": "LAS", "phoenix": "PHX", "san diego": "SAN",
    "portland": "PDX", "salt lake city": "SLC", "austin": "AUS",
    "philadelphia": "PHL", "detroit": "DTW", "minneapolis": "MSP",
    "charlotte": "CLT", "baltimore": "BWI", "orlando": "MCO",
    "tampa": "TPA", "fort lauderdale": "FLL", "honolulu": "HNL",
    "hawaii": "HNL", "maui": "OGG", "anchorage": "ANC",
    "toronto": "YYZ", "montreal": "YUL", "vancouver": "YVR",
    "calgary": "YYC", "ottawa": "YOW", "edmonton": "YEG",
    "winnipeg": "YWG", "halifax": "YHZ", "mexico city": "MEX",
    "guadalajara": "GDL", "monterrey": "MTY", "cancun": "CUN",
    "panama city": "PTY", "san jose": "SJO", "san juan": "SJU",
    "punta cana": "PUJ", "montego bay": "MBJ", "nassau": "NAS",
    "havana": "HAV", "sao paulo": "GRU", "rio": "GIG",
    "rio de janeiro": "GIG", "brasilia": "BSB", "manaus": "MAO",
    "buenos aires": "EZE", "santiago": "SCL", "bogota": "BOG",
    "medellin": "MDE", "cartagena": "CTG", "lima": "LIM", "quito": "UIO",
    "guayaquil": "GYE", "caracas": "CCS", "santa cruz": "VVI",
    "asuncion": "ASU", "montevideo": "MVD", "madrid": "MAD",
    "barcelona": "BCN", "malaga": "AGP", "palma": "PMI",
    "palma de mallorca": "PMI", "ibiza": "IBZ", "bilbao": "BIO",
    "tenerife": "TFS", "gran canaria": "LPA", "lisbon": "LIS",
    "porto": "OPO", "rome": "FCO", "roma": "FCO", "milan": "MXP",
    "milano": "MXP", "venice": "VCE", "naples": "NAP", "berlin": "BER",
    "palermo": "PMO", "catania": "CTA",
    "frankfurt": "FRA", "munich": "MUC", "hamburg": "HAM",
    "dusseldorf": "DUS", "stuttgart": "STR", "cologne": "CGN",
    "amsterdam": "AMS", "brussels": "BRU", "luxembourg": "LUX",
    "zurich": "ZRH", "geneva": "GVA", "vienna": "VIE",
    "warsaw": "WAW", "prague": "PRG", "budapest": "BUD",
    "bucharest": "OTP", "sofia": "SOF", "belgrade": "BEG",
    "zagreb": "ZAG", "ljubljana": "LJU", "riga": "RIX",
    "vilnius": "VNO", "tallinn": "TLL", "larnaca": "LCA", "malta": "MLA",
    "reykjavik": "KEF", "copenhagen": "CPH", "stockholm": "ARN",
    "oslo": "OSL", "helsinki": "HEL", "gothenburg": "GOT",
    "athens": "ATH", "thessaloniki": "SKG", "dublin": "DUB",
    "edinburgh": "EDI", "manchester": "MAN", "birmingham": "BHX",
    "glasgow": "GLA", "nice": "NCE", "lyon": "LYS", "marseille": "MRS",
    "tashkent": "TAS", "almaty": "ALA", "astana": "NQZ",
    "bishkek": "FRU", "tbilisi": "TBS", "yerevan": "EVN", "baku": "GYD",
    "ulaanbaatar": "ULA",
}

# =====================================================================
# AIRCRAFT : squashed name -> IATA type designator
# Squash rule: uppercase, vendor words removed, spaces removed
# =====================================================================
AIRCRAFT = {
    # Boeing
    "717": "717", "717-200": "717",
    "737": "738", "737-600": "736", "737-700": "73G", "737-800": "738",
    "737-900": "739", "737-900ER": "739",
    "737MAX": "73M", "737MAX7": "7M7", "737MAX8": "7M8", "737MAX9": "7M9",
    "737MAX10": "7MJ", "MAX7": "7M7", "MAX8": "7M8", "MAX9": "7M9", "MAX10": "7MJ",
    "737-7": "7M7", "737-8": "7M8", "737-9": "7M9", "737-10": "7MJ",
    "737-8MAX": "7M8", "737-9MAX": "7M9",
    "747": "744", "747-400": "744", "747-400ER": "744", "747-8": "748", "747-8I": "748",
    "757": "752", "757-200": "752", "757-300": "753",
    "767": "763", "767-200": "762", "767-300": "763", "767-300ER": "76W",
    "767-400": "764", "767-400ER": "764",
    "777": "77W", "777-200": "772", "777-200ER": "77E", "777-200LR": "77L",
    "777-300": "773", "777-300ER": "77W", "777-8": "778", "777-9": "779",
    "777X": "779", "777-8X": "778", "777-9X": "779",
    "787": "788", "787-8": "788", "787-9": "789", "787-10": "781",
    "DREAMLINER": "788",
    # Airbus
    "A220": "223", "A220-100": "221", "A220100": "221",
    "A220-300": "223", "A220300": "223",
    "A319": "319", "A319NEO": "31N", "319": "319",
    "A320": "320", "A320NEO": "32N", "320": "320",
    "A321": "321", "A321NEO": "32Q", "A321XLR": "32Q", "A321LR": "32Q",
    "A321NEOLR": "32Q", "A321NEOXLR": "32Q", "321": "321",
    "A330": "333", "A330-200": "332", "A330200": "332",
    "A330-300": "333", "A330300": "333",
    "A330-800": "338", "A330-800NEO": "338", "A330-900": "339",
    "A330-900NEO": "339", "A330NEO": "339",
    "A340": "343", "A340-300": "343", "A340-500": "345", "A340-600": "346",
    "A350": "359", "A350-900": "359", "A350900": "359",
    "A350-1000": "35K", "A3501000": "35K",
    "A380": "388", "A380-800": "388", "A380800": "388",
    # Embraer
    "E135": "E35", "EMB135": "E35", "ERJ135": "E35",
    "E140": "E40", "EMB140": "E40", "ERJ140": "E40",
    "E145": "E45", "EMB145": "E45", "ERJ145": "E45",
    "E170": "E70", "EMB170": "E70", "ERJ170": "E70",
    "E175": "E75", "EMB175": "E75", "ERJ175": "E75",
    "E190": "E90", "EMB190": "E90", "ERJ190": "E90",
    "E195": "E95", "EMB195": "E95", "ERJ195": "E95",
    "E190-E2": "290", "E190E2": "290", "E195-E2": "295", "E195E2": "295",
    # Bombardier / De Havilland
    "CRJ200": "CR2", "CRJ-200": "CR2", "CRJ700": "CR7", "CRJ-700": "CR7",
    "CRJ900": "CR9", "CRJ-900": "CR9", "CRJ1000": "CRK", "CRJ-1000": "CRK",
    "CRJ": "CR9",
    "RJ900": "CR9", "RJ 900": "CR9", "RJ-900": "CR9",
    "RJ700": "CR7", "RJ 700": "CR7", "RJ-700": "CR7",
    "RJ200": "CR2", "RJ 200": "CR2", "RJ-200": "CR2",
    "RJ1000": "CRK", "RJ 1000": "CRK", "RJ-1000": "CRK",
    "CANADAIR RJ": "CR9", "REGIONAL JET": "CR9",
    "Q100": "DH1", "Q200": "DH2", "Q300": "DH3", "Q400": "DH4",
    "DASH8": "DH4", "DASH8Q100": "DH1", "DASH8Q200": "DH2",
    "DASH8Q300": "DH3", "DASH8Q400": "DH4", "DASH8-100": "DH1",
    "DASH8-200": "DH2", "DASH8-300": "DH3", "DASH8-400": "DH4",
    "DHC8": "DH4", "DHC8-100": "DH1", "DHC8-200": "DH2",
    "DHC8-300": "DH3", "DHC8-400": "DH4", "DHC-8": "DH4",
    "DHC-8-100": "DH1", "DHC-8-200": "DH2", "DHC-8-300": "DH3", "DHC-8-400": "DH4",
    # ATR
    "ATR42": "AT4", "ATR-42": "AT4", "ATR42-600": "AT4", "AT42": "AT4",
    "ATR72": "AT7", "ATR-72": "AT7", "ATR72-600": "AT7", "AT76": "AT7", "ATR": "AT7",
    # Others
    "GRANDCARAVAN": "CN1", "CARAVAN": "CN1", "C208": "CN1", "208": "CN1",
    "SAAB340": "SF3", "SF340": "SF3",
    "BAE146": "146", "BAE146-200": "146", "BAE146-300": "146",
    "AVRORJ": "146", "AVRORJ85": "146", "AVRORJ100": "146",
    "RJ85": "146", "RJ100": "146", "146": "146",
    "SSJ100": "SU95", "SUPERJET": "SU95", "SUPERJET100": "SU95", "SSJ": "SU95",
    "C919": "919", "COMACC919": "919",
}

# IATA aircraft designators — passed through when found directly in text
IATA_ACFT_CODES = set(AIRCRAFT.values())

# Vendor prefixes stripped during squash
_AC_VENDOR = ("BOEING", "AIRBUS", "EMBRAER", "BOMBARDIER", "DE HAVILLAND",
              "CANADAIR", "CESSNA", "COMAC", "SUKHOI")


def squash_aircraft(text):
    """Normalize an aircraft string for AIRCRAFT lookup."""
    t = text.upper().replace("\u2013", "-").replace("\u2014", "-")
    embraer = "EMBRAER" in t
    for v in _AC_VENDOR:
        t = t.replace(v, "")
    sq = "".join(t.split())
    # "Embraer 175" -> "E175" (E-jet families lose their E when vendor removed)
    if embraer and sq[:1].isdigit():
        sq = "E" + sq
    return sq


def lookup_aircraft(text):
    """Return IATA designator for an aircraft name/code, else None."""
    sq = squash_aircraft(text)
    if sq in AIRCRAFT:
        return AIRCRAFT[sq]
    return None


def scan_aircraft(region_upper):
    """Scan a window of (already uppercased) text for an aircraft designator.
    Spaceless/vendor-stripped scan catches multi-word names like
    'Boeing 737 MAX 8', 'Dash 8 Q400', 'Embraer 175'."""
    import re
    sq = squash_aircraft(region_upper)
    for key in sorted(AIRCRAFT, key=len, reverse=True):
        if len(key) >= 3 and key in sq:
            return AIRCRAFT[key]
    # Embraer bare-number style ("Embraer 175", "Embraer E190-E2")
    m = re.search(r"EMBRAER\s+E?(\d{3})\s*-?\s*(E2)?", region_upper)
    if m:
        fam = "E" + m.group(1) + ("-E2" if m.group(2) else "")
        if fam in AIRCRAFT:
            return AIRCRAFT[fam]
    return None


# =====================================================================
# DST + offset logic
# =====================================================================
def _nth_weekday(year, month, weekday, n):
    """Date of the nth weekday (0=Mon..6=Sun) of month."""
    d = date(year, month, 1)
    delta = (weekday - d.weekday()) % 7
    return date.fromordinal(d.toordinal() + delta + 7 * (n - 1))


def _last_weekday(year, month, weekday):
    """Date of the last weekday of month."""
    if month == 12:
        d = date(year, 12, 31)
    else:
        d = date(year, month + 1, 1)
        d = date.fromordinal(d.toordinal() - 1)
    delta = (d.weekday() - weekday) % 7
    return date.fromordinal(d.toordinal() - delta)


def dst_active(region, d):
    """Approximate DST check for a region on a given date."""
    if region == "US":      # 2nd Sun Mar - 1st Sun Nov
        return _nth_weekday(d.year, 3, 6, 2) <= d < _nth_weekday(d.year, 11, 6, 1)
    if region == "EU":      # last Sun Mar - last Sun Oct
        return _last_weekday(d.year, 3, 6) <= d < _last_weekday(d.year, 10, 6)
    if region == "AU":      # 1st Sun Oct - 1st Sun Apr
        return d >= _nth_weekday(d.year, 10, 6, 1) or d < _nth_weekday(d.year, 4, 6, 1)
    if region == "NZ":      # last Sun Sep - 1st Sun Apr
        return d >= _last_weekday(d.year, 9, 6) or d < _nth_weekday(d.year, 4, 6, 1)
    if region == "SHSEP":   # Chile: 1st Sun Sep - 1st Sun Apr
        return d >= _nth_weekday(d.year, 9, 6, 1) or d < _nth_weekday(d.year, 4, 6, 1)
    if region == "EG":      # Egypt: last Fri Apr - last Fri Oct (approx)
        return _last_weekday(d.year, 4, 4) <= d < _last_weekday(d.year, 10, 4)
    return False


# =====================================================================
# Aircraft inference — outputs never show "???" as aircraft (v2.5)
# =====================================================================
# 1) Curated flight -> equipment table for the routes this office actually
#    sells (extend freely). 2) Per-airline narrowbody/widebody defaults used
#    with route distance as the generic safety net.
FLIGHT_EQUIPMENT = {
    ("AA", "6939"): "77W", ("AA", "6753"): "388",  # BA-operated codeshares
    ("TK", "12"): "788", ("TK", "30"): "789", ("TK", "29"): "789",
    ("TK", "36"): "359", ("TK", "720"): "77W", ("TK", "721"): "77W",
    ("TK", "722"): "333",
    ("QR", "536"): "320", ("QR", "537"): "320", ("QR", "755"): "359",
    ("KU", "118"): "32N", ("KU", "301"): "32N", ("KU", "302"): "32N",
    ("KU", "304"): "32N", ("KU", "117"): "77W",
    ("MS", "40"): "738", ("MS", "670"): "738", ("MS", "987"): "789",
    ("SV", "803"): "789",
    ("UA", "1511"): "739", ("UA", "877"): "77W", ("UA", "878"): "77W",
    ("AA", "8880"): "772", ("AA", "8883"): "772", ("AA", "2859"): "320",
    ("BA", "472"): "320", ("BA", "551"): "320",
    ("AA", "5021"): "E75",   # STL-CLT regional, Republic E175
    ("4Z", "672"): "E90",    # PLZ-CPT Airlink E190
    ("EK", "771"): "773",    # CPT-DXB 777-300
    ("EK", "191"): "773",    # DXB-LIS 777-300
    ("CX", "715"): "359",
    ("AC", "1095"): "223",
    ("AS", "1342"): "738",
    ("SK", "1694"): "738",
}

# airline -> (short/medium haul default, long haul default)
AIRLINE_EQUIPMENT = {
    "AA": ("738", "772"), "UA": ("738", "772"), "DL": ("738", "359"),
    "AC": ("223", "789"), "BA": ("320", "789"), "AF": ("320", "789"),
    "KL": ("738", "789"), "LH": ("320", "359"), "TK": ("32Q", "77W"),
    "QR": ("32Q", "359"), "EK": ("77W", "388"), "EY": ("32N", "789"),
    "CX": ("32Q", "359"), "SQ": ("32Q", "359"), "NH": ("788", "789"),
    "JL": ("788", "789"), "SV": ("320", "789"), "MS": ("738", "789"),
    "KU": ("32N", "77W"), "SK": ("32N", "333"), "LX": ("320", "77W"),
    "OS": ("320", "77W"), "AI": ("32N", "788"), "ET": ("738", "789"),
    "RJ": ("32N", "788"), "6E": ("320", "320"), "SG": ("738", "738"),
    "FZ": ("738", "738"), "XY": ("320", "320"), "G9": ("320", "320"),
}

# =====================================================================
# Worldwide Aircraft Type Master (v2.6 - feasibility-framework spec)
# iata code -> (icao code, type name, family, manufacturer, category,
#               typical_range_nm or None)
# Reference data: stable manufacturer/IATA fact set; used for inference,
# range guard, and equipment sanity advisories. Regional types carry
# None range (short-haul only, guard never fires on them).
# =====================================================================
AIRCRAFT_TYPES = {
    # --- Airbus ---
    "221": ("BCS1", "A220-100", "A220", "Airbus", "narrowbody", 3400),
    "223": ("BCS3", "A220-300", "A220", "Airbus", "narrowbody", 3350),
    "318": ("A318", "A318", "A318", "Airbus", "narrowbody", 3100),
    "319": ("A319", "A319", "A319", "Airbus", "narrowbody", 3700),
    "31N": ("A19N", "A319neo", "A319", "Airbus", "narrowbody", 3700),
    "320": ("A320", "A320", "A320", "Airbus", "narrowbody", 3300),
    "32N": ("A20N", "A320neo", "A320", "Airbus", "narrowbody", 3400),
    "321": ("A321", "A321", "A321", "Airbus", "narrowbody", 3200),
    "32Q": ("A21N", "A321neo", "A321", "Airbus", "narrowbody", 4000),
    "332": ("A332", "A330-200", "A330", "Airbus", "widebody", 7250),
    "333": ("A333", "A330-300", "A330", "Airbus", "widebody", 6350),
    "338": ("A338", "A330-800neo", "A330", "Airbus", "widebody", 8150),
    "339": ("A339", "A330-900neo", "A330", "Airbus", "widebody", 7200),
    "342": ("A342", "A340-200", "A340", "Airbus", "widebody", 7450),
    "343": ("A343", "A340-300", "A340", "Airbus", "widebody", 7400),
    "345": ("A345", "A340-500", "A340", "Airbus", "widebody", 9000),
    "346": ("A346", "A340-600", "A340", "Airbus", "widebody", 7900),
    "359": ("A359", "A350-900", "A350", "Airbus", "widebody", 8100),
    "351": ("A35K", "A350-1000", "A350", "Airbus", "widebody", 8700),
    "388": ("A388", "A380-800", "A380", "Airbus", "superjumbo", 8000),
    # --- Boeing ---
    "717": ("B712", "717-200", "717", "Boeing", "narrowbody", 1430),
    "73G": ("B737", "737-700", "737", "Boeing", "narrowbody", 3250),
    "738": ("B738", "737-800", "737", "Boeing", "narrowbody", 2935),
    "739": ("B739", "737-900/ER", "737", "Boeing", "narrowbody", 2800),
    "7M7": ("B37M", "737 MAX 7", "737 MAX", "Boeing", "narrowbody", 3850),
    "7M8": ("B38M", "737 MAX 8", "737 MAX", "Boeing", "narrowbody", 3550),
    "7M9": ("B39M", "737 MAX 9", "737 MAX", "Boeing", "narrowbody", 3550),
    "7MJ": ("B3XM", "737 MAX 10", "737 MAX", "Boeing", "narrowbody", 3300),
    "744": ("B744", "747-400", "747", "Boeing", "widebody", 7260),
    "748": ("B748", "747-8I", "747", "Boeing", "widebody", 7730),
    "752": ("B752", "757-200", "757", "Boeing", "narrowbody", 3900),
    "753": ("B753", "757-300", "757", "Boeing", "narrowbody", 3400),
    "762": ("B762", "767-200ER", "767", "Boeing", "widebody", 6590),
    "763": ("B763", "767-300ER", "767", "Boeing", "widebody", 5990),
    "764": ("B764", "767-400ER", "767", "Boeing", "widebody", 5625),
    "772": ("B772", "777-200/ER", "777", "Boeing", "widebody", 5240),
    "77L": ("B77L", "777-200LR", "777", "Boeing", "widebody", 8555),
    "773": ("B773", "777-300", "777", "Boeing", "widebody", 6015),
    "77W": ("B77W", "777-300ER", "777", "Boeing", "widebody", 7370),
    "778": ("B778", "777-8", "777X", "Boeing", "widebody", 8730),
    "779": ("B779", "777-9", "777X", "Boeing", "widebody", 7285),
    "788": ("B788", "787-8", "787", "Boeing", "widebody", 7355),
    "789": ("B789", "787-9", "787", "Boeing", "widebody", 7635),
    "781": ("B78X", "787-10", "787", "Boeing", "widebody", 6330),
    # --- Freighters (reference) ---
    "33F": ("A332", "A330-200F", "A330", "Airbus", "freighter", 4000),
    "73F": ("B738", "737-800BCF", "737", "Boeing", "freighter", 2000),
    "74Y": ("B744", "747-400F", "747", "Boeing", "freighter", 4445),
    "74N": ("B748", "747-8F", "747", "Boeing", "freighter", 4390),
    "75F": ("B752", "757-200F", "757", "Boeing", "freighter", 2600),
    "76F": ("B763", "767-300F", "767", "Boeing", "freighter", 3255),
    "77F": ("B77L", "777F", "777", "Boeing", "freighter", 4900),
    # --- Embraer (range not published in source set -> None) ---
    "ER3": ("E135", "ERJ-135", "ERJ", "Embraer", "regional_jet", None),
    "ERD": ("E140", "ERJ-140", "ERJ", "Embraer", "regional_jet", None),
    "ER4": ("E145", "ERJ-145", "ERJ", "Embraer", "regional_jet", None),
    "E70": ("E170", "E170", "E-Jet", "Embraer", "regional_jet", None),
    "E75": ("E75S", "E175", "E-Jet", "Embraer", "regional_jet", None),
    "E90": ("E190", "E190", "E-Jet", "Embraer", "regional_jet", None),
    "E95": ("E195", "E195", "E-Jet", "Embraer", "regional_jet", None),
    "E7W": ("E75L", "E175-E2", "E-Jet E2", "Embraer", "regional_jet", None),
    "290": ("E290", "E190-E2", "E-Jet E2", "Embraer", "regional_jet", None),
    "295": ("E295", "E195-E2", "E-Jet E2", "Embraer", "regional_jet", None),
    # --- ATR ---
    "AT4": ("AT43", "ATR 42", "ATR", "ATR", "turboprop", None),
    "AT5": ("AT45", "ATR 42-500", "ATR", "ATR", "turboprop", None),
    "AT7": ("AT75", "ATR 72", "ATR", "ATR", "turboprop", None),
    # --- De Havilland Canada ---
    "DH1": ("DH8A", "Dash 8-100", "Dash 8", "De Havilland", "turboprop", None),
    "DH2": ("DH8B", "Dash 8-200", "Dash 8", "De Havilland", "turboprop", None),
    "DH3": ("DH8C", "Dash 8-300", "Dash 8", "De Havilland", "turboprop", None),
    "DH4": ("DH8D", "Dash 8-400", "Dash 8", "De Havilland", "turboprop", None),
    # --- Bombardier ---
    "CR1": ("CRJ1", "CRJ-100", "CRJ", "Bombardier", "regional_jet", None),
    "CR2": ("CRJ2", "CRJ-200", "CRJ", "Bombardier", "regional_jet", None),
    "CR7": ("CRJ7", "CRJ-700", "CRJ", "Bombardier", "regional_jet", None),
    "CR9": ("CRJ9", "CRJ-900", "CRJ", "Bombardier", "regional_jet", None),
    "CRA": ("CRJX", "CRJ-1000", "CRJ", "Bombardier", "regional_jet", None),
    # --- COMAC ---
    "AJ2": ("AJ27", "ARJ21-700", "ARJ21", "COMAC", "regional_jet", None),
    "919": ("C919", "C919", "C919", "COMAC", "narrowbody", None),
    # --- Sukhoi / Irkut (UAC) ---
    "SU9": ("SU95", "Superjet 100", "Superjet", "UAC", "regional_jet", None),
    "M81": ("MC21", "MC-21-300", "MC-21", "UAC", "narrowbody", None),
    # --- Saab ---
    "SF3": ("SF34", "Saab 340B", "340", "Saab", "turboprop", None),
    "S20": ("SB20", "Saab 2000", "2000", "Saab", "turboprop", None),
}


def aircraft_info(code):
    """Dict metadata for an IATA aircraft code (icao/type/family/mfr/cat/
    range_nm). None if the code is not in the master table."""
    t = AIRCRAFT_TYPES.get(code)
    if not t:
        return None
    return {"icao": t[0], "type": t[1], "family": t[2], "mfr": t[3],
            "cat": t[4], "range_nm": t[5]}


# =====================================================================
# Route-level aircraft database (v2.6) - verified high-confidence trunk
# route assignments (feasibility-framework Part E). Primary scheduled
# type per (airline, origin, destination); reverse lookup allowed.
# Between the curated flight table and the per-airline defaults.
# =====================================================================
ROUTE_EQUIPMENT = {
    ("BA", "LHR", "JFK"): "388",   # A380/777/787 mix, A380 primary
    ("EK", "DXB", "LHR"): "388",   # A380 primary, 777 mix
    ("SQ", "SIN", "LHR"): "388",   # A380/777/A350 mix
    ("QF", "SYD", "MEL"): "738",   # shuttle
    ("DL", "ATL", "LAX"): "752",   # hub-to-hub
    ("FR", "STN", "DUB"): "738",
    ("WN", "DAL", "HOU"): "73G",
    ("NH", "HND", "ITM"): "772",   # domestic shuttle
    ("CZ", "CAN", "PEK"): "32N",
    ("ET", "ADD", "NBO"): "738",
    ("LA", "SCL", "GRU"): "789",
    ("TK", "IST", "LHR"): "333",
    ("QR", "DOH", "LHR"): "351",   # A35K primary, A359/77W/388 mix
    ("6E", "DEL", "BOM"): "32N",   # highest-frequency domestic
    ("NZ", "AKL", "SYD"): "789",
}

GENERIC_EQUIPMENT = ("738", "789")  # fallback for unlisted airlines
NM_PER_MI = 0.868976


def infer_aircraft(airline, flight_no, orig, dest, distance_mi=0):
    """Best aircraft IATA code for a flight: (code, source). Resolution
    chain (v2.6): curated flight table -> route database (airport pair)
    -> per-airline narrow/wide default chosen by distance and published
    range (range guard upgrades an under-ranged narrowbody pick to the
    widebody) -> generic default. Never returns '???'; explicit aircraft
    in input always wins (callers only invoke this when none parsed)."""
    code = FLIGHT_EQUIPMENT.get((airline, str(flight_no)))
    if code:
        return code, "flight table"
    code = (ROUTE_EQUIPMENT.get((airline, orig, dest)) or
            ROUTE_EQUIPMENT.get((airline, dest, orig)))
    if code:
        return code, "route database"
    narrow, wide = AIRLINE_EQUIPMENT.get(airline, GENERIC_EQUIPMENT)
    d = distance_mi or 0
    if not d and orig in AIRPORTS and dest in AIRPORTS:
        d = haversine_miles(orig, dest) or 0
    pick = wide if d >= 3500 else narrow
    if pick == narrow and d:
        t = AIRCRAFT_TYPES.get(pick)
        if t and t[5] and d * NM_PER_MI > t[5] * 1.02:
            pick = wide
    return pick, "route estimate"


def range_advisory(aircraft_code, orig, dest, distance_mi=0):
    """Data-integrity check (v2.6): warning string when the aircraft's
    published still-air range is clearly below the great-circle route
    distance (10% buffer, e.g. A320 scheduled FRA-SYD means the paste is
    missing a stop or carries a wrong equipment column). Advisory only -
    output rows are never altered. None when not provable/unknown."""
    t = AIRCRAFT_TYPES.get(aircraft_code)
    if not t or not t[5]:
        return None
    d = distance_mi or 0
    if not d and orig in AIRPORTS and dest in AIRPORTS:
        d = haversine_miles(orig, dest) or 0
    if not d:
        return None
    nm = int(round(d * NM_PER_MI))
    if nm > t[5] * 1.10:
        return (f"range check: {aircraft_code} range {t[5]}nm < "
                f"route {nm}nm - verify equipment")
    return None


def utc_offset(code, d):
    """Effective UTC offset (hours) for airport on date d. None if unknown."""
    ap = AIRPORTS.get(code)
    if not ap:
        return None
    off = ap["off"]
    if dst_active(ap["dst"], d):
        off += 1
    return off


# =====================================================================
# Distance + flight time estimation
# =====================================================================
_EARTH_MI = 3958.7613


def haversine_miles(code1, code2):
    """Great-circle distance in statute miles. None if a leg is unknown."""
    a, b = AIRPORTS.get(code1), AIRPORTS.get(code2)
    if not a or not b:
        return None
    lat1, lon1, lat2, lon2 = (math.radians(a["lat"]), math.radians(a["lon"]),
                              math.radians(b["lat"]), math.radians(b["lon"]))
    h = (math.sin((lat2 - lat1) / 2) ** 2 +
         math.cos(lat1) * math.cos(lat2) * math.sin((lon2 - lon1) / 2) ** 2)
    return round(2 * _EARTH_MI * math.asin(math.sqrt(h)))


def estimate_duration_min(distance_mi):
    """Rough block-time estimate from distance (minutes)."""
    if not distance_mi:
        return None
    return max(35, int(round((distance_mi / 9.0 + 30) / 5.0) * 5))


def format_h_mm(total_min):
    """'12.50' style: hours . two-digit minutes."""
    h, m = divmod(int(round(total_min)), 60)
    return f"{h}.{m:02d}"


# =====================================================================
# Expansion pack (v1.4) — broad global coverage reported as missing
# =====================================================================
AIRPORTS.update({
    # ---- United States ----
    "IND": A("INDIANAPOLIS INTL", 39.717, -86.294, -5, "US"),
    "AUS": A("AUSTIN BERGSTROM INTL", 30.194, -97.670, -6, "US"),
    "DAL": A("DALLAS LOVE FIELD", 32.847, -96.852, -6, "US"),
    "HOU": A("WILLIAM P HOBBY", 29.645, -95.279, -6, "US"),
    "BNA": A("NASHVILLE INTL", 36.124, -86.678, -6, "US"),
    "RDU": A("RALEIGH DURHAM INTL", 35.877, -78.787, -5, "US"),
    "MCI": A("KANSAS CITY INTL", 39.297, -94.713, -6, "US"),
    "CMH": A("JOHN GLENN COLUMBUS INTL", 39.998, -82.891, -5, "US"),
    "PIT": A("PITTSBURGH INTL", 40.491, -80.233, -5, "US"),
    "STL": A("ST LOUIS LAMBERT INTL", 38.748, -90.370, -6, "US"),
    "CLE": A("CLEVELAND HOPKINS INTL", 41.411, -81.849, -5, "US"),
    "CVG": A("CINCINNATI NORTHERN KY INTL", 39.048, -84.662, -5, "US"),
    "BDL": A("BRADLEY INTL", 41.938, -72.683, -5, "US"),
    "PVD": A("T F GREEN INTL", 41.724, -71.428, -5, "US"),
    "BUF": A("BUFFALO NIAGARA INTL", 42.940, -78.732, -5, "US"),
    "OAK": A("OAKLAND INTL", 37.721, -122.220, -8, "US"),
    "SJC": A("SAN JOSE MINETA INTL", 37.363, -121.928, -8, "US"),
    "SNA": A("JOHN WAYNE ORANGE COUNTY", 33.675, -117.868, -8, "US"),
    "ONT": A("ONTARIO INTL", 34.056, -117.601, -8, "US"),
    "PSP": A("PALM SPRINGS INTL", 33.830, -116.507, -8, "US"),
    "BOI": A("BOISE AIR TERMINAL", 43.564, -116.222, -7, "US"),
    "RNO": A("RENO TAHOE INTL", 39.499, -119.768, -8, "US"),
    "ABQ": A("ALBUQUERQUE INTL SUNPORT", 35.040, -106.609, -7, "US"),
    "TUS": A("TUCSON INTL", 32.116, -110.941, -7, ""),
    "OKC": A("WILL ROGERS WORLD", 35.393, -97.600, -6, "US"),
    "TUL": A("TULSA INTL", 36.198, -95.888, -6, "US"),
    "DSM": A("DES MOINES INTL", 41.534, -93.663, -6, "US"),
    "OMA": A("EPPLEY AIRFIELD", 41.303, -95.894, -6, "US"),
    "MSY": A("LOUIS ARMSTRONG INTL", 29.993, -90.259, -6, "US"),
    "BHM": A("BIRMINGHAM SHUTTLESWORTH INTL", 33.563, -86.753, -6, "US"),
    "SDF": A("LOUISVILLE MUHAMMAD ALI INTL", 38.174, -85.736, -5, "US"),
    "MEM": A("MEMPHIS INTL", 35.042, -89.977, -6, "US"),
    "CHS": A("CHARLESTON INTL", 32.899, -80.041, -5, "US"),
    "SAV": A("SAVANNAH HILTON HEAD INTL", 32.128, -81.202, -5, "US"),
    "JAX": A("JACKSONVILLE INTL", 30.494, -81.688, -5, "US"),
    "RIC": A("RICHMOND INTL", 37.505, -77.319, -5, "US"),
    "ORF": A("NORFOLK INTL", 36.894, -76.201, -5, "US"),
    "MHT": A("MANCHESTER BOSTON REGIONAL", 42.932, -71.436, -5, "US"),
    "ALB": A("ALBANY INTL", 42.748, -73.802, -5, "US"),
    "SYR": A("SYRACUSE HANCOCK INTL", 43.111, -76.106, -5, "US"),
    "ROC": A("GREATER ROCHESTER INTL", 43.119, -77.672, -5, "US"),
    "GRR": A("GERALD R FORD INTL", 42.882, -85.523, -5, "US"),
    "MKE": A("MILWAUKEE MITCHELL INTL", 42.947, -87.897, -6, "US"),
    "MSN": A("DANE COUNTY REGIONAL", 43.140, -89.337, -6, "US"),
    "FAR": A("HECTOR INTL", 46.920, -96.815, -6, "US"),
    "ANC": A("TED STEVENS ANCHORAGE INTL", 61.174, -149.996, -9, "US"),
    # ---- Canada ----
    "YYC": A("CALGARY INTL", 51.114, -114.020, -7, "US"),
    "YEG": A("EDMONTON INTL", 53.310, -113.580, -7, "US"),
    "YOW": A("OTTAWA MACDONALD CARTIER INTL", 45.322, -75.669, -5, "US"),
    "YHZ": A("HALIFAX STANFIELD INTL", 44.880, -63.508, -4, "US"),
    "YWG": A("WINNIPEG INTL", 49.910, -97.240, -6, "US"),
    "YQB": A("QUEBEC CITY JEAN LESAGE INTL", 46.791, -71.393, -5, "US"),
    # ---- Caribbean / Latin America ----
    "CUN": A("CANCUN INTL", 21.042, -86.874, -5, ""),
    "SJU": A("LUIS MUNOZ MARIN INTL", 18.439, -66.002, -4, ""),
    "SDQ": A("LAS AMERICAS INTL", 18.430, -69.669, -4, ""),
    "PUJ": A("PUNTA CANA INTL", 18.567, -68.363, -4, ""),
    "NAS": A("LYNDEN PINDLING INTL", 25.039, -77.466, -5, "US"),
    "BGI": A("GRANTLEY ADAMS INTL", 13.075, -59.492, -4, ""),
    "POS": A("PIARCO INTL", 10.595, -61.337, -4, ""),
    "GEO": A("CHEDDI JAGAN INTL", 6.499, -58.254, -4, ""),
    "AUA": A("QUEEN BEATRIX INTL", 12.501, -70.015, -4, ""),
    "CUR": A("HATO INTL", 12.189, -68.960, -4, ""),
    "SXM": A("PRINCESS JULIANA INTL", 18.041, -63.109, -4, ""),
    "KIN": A("NORMAN MANLEY INTL", 17.936, -76.787, -5, ""),
    "MBJ": A("SANGSTER INTL", 18.504, -77.913, -5, ""),
    "HAV": A("JOSE MARTI INTL", 22.989, -82.409, -5, "US"),
    "SJO": A("JUAN SANTAMARIA INTL", 9.994, -84.209, -6, ""),
    "PTY": A("TOCUMEN INTL", 9.071, -79.384, -5, ""),
    "SAL": A("EL SALVADOR INTL", 13.441, -89.056, -6, ""),
    "GUA": A("LA AURORA INTL", 14.583, -90.528, -6, ""),
    "BZE": A("PHILIP GOLDSON INTL", 17.539, -88.308, -6, ""),
    "MGA": A("AUGUSTO C SANDINO INTL", 12.141, -86.168, -6, ""),
    "LIR": A("DANIEL ODUBER INTL", 10.593, -85.544, -6, ""),
    "GYE": A("JOSE JOAQUIN DE OLMEDO INTL", -2.158, -79.884, -5, ""),
    "UIO": A("MARISCAL SUCRE INTL", -0.113, -78.358, -5, ""),
    "ASU": A("SILVIO PETTIROSSI INTL", -25.240, -57.519, -4, ""),
    "MVD": A("CARRASCO INTL", -34.838, -56.030, -3, ""),
    "REC": A("GUARARAPES GILBERTO FREYRE INTL", -8.126, -34.924, -3, ""),
    "SSA": A("DEPUTADO LUIS EDUARDO MAGALHAES INTL", -12.909, -38.331, -3, ""),
    "BSB": A("BRASILIA INTL", -15.870, -47.921, -3, ""),
    # ---- Middle East / Asia ----
    "KWI": A("KUWAIT INTL", 29.227, 47.969, 3, ""),
    "BAH": A("BAHRAIN INTL", 26.271, 50.634, 3, ""),
    "MCT": A("MUSCAT INTL", 23.593, 58.284, 4, ""),
    "JED": A("KING ABDULAZIZ INTL", 21.680, 39.157, 3, ""),
    "DMM": A("KING FAHD INTL", 26.471, 49.798, 3, ""),
    "RUH": A("KING KHALID INTL", 24.958, 46.699, 3, ""),
    "MED": A("PRINCE MOHAMMAD BIN ABDULAZIZ INTL", 24.553, 39.705, 3, ""),
    "AMM": A("QUEEN ALIA INTL", 31.722, 35.993, 3, ""),
    "BEY": A("BEIRUT RAFIC HARIRI INTL", 33.821, 35.488, 2, "EU"),
    "DAC": A("HAZRAT SHAHJALAL INTL", 23.843, 90.398, 6, ""),
    "CMB": A("BANDARANAIKE INTL", 7.173, 79.884, 5.5, ""),
    "KTM": A("TRIBHUVAN INTL", 27.697, 85.359, 5.75, ""),
    "ISB": A("ISLAMABAD INTL", 33.549, 72.826, 5, ""),
    "LHE": A("ALLAMA IQBAL INTL", 31.521, 74.404, 5, ""),
    "KHI": A("JINNAH INTL", 24.906, 67.161, 5, ""),
    "TAS": A("ISLAM KARIMOV INTL", 41.258, 69.281, 5, ""),
    "ALA": A("ALMATY INTL", 43.352, 77.041, 5, ""),
    "FRU": A("MANAS INTL", 43.061, 74.478, 6, ""),
    "EVN": A("ZVARTNOTS INTL", 40.147, 44.396, 4, ""),
    "TBS": A("SHOTA RUSTAVELI INTL", 41.669, 44.955, 4, ""),
    "GYD": A("HEYDAR ALIYEV INTL", 40.468, 50.047, 4, ""),
    "MLE": A("VELANA INTL", 4.192, 73.529, 5, ""),
    "HYD": A("RAJIV GANDHI INTL", 17.231, 78.430, 5.5, ""),
    "BLR": A("KEMPEGOWDA INTL", 13.198, 77.706, 5.5, ""),
    "MAA": A("CHENNAI INTL", 12.994, 80.171, 5.5, ""),
    "CCU": A("NETAJI SUBHAS CHANDRA BOSE INTL", 22.655, 88.447, 5.5, ""),
    "COK": A("COCHIN INTL", 10.152, 76.402, 5.5, ""),
    "PEN": A("PENANG INTL", 5.297, 100.277, 8, ""),
    "MNL": A("NINOY AQUINO INTL", 14.509, 121.020, 8, ""),
    "CEB": A("MACTAN CEBU INTL", 10.307, 123.979, 8, ""),
    "CGK": A("SOEKARNO HATTA INTL", -6.125, 106.655, 7, ""),
    "DPS": A("NGURAH RAI INTL", -8.748, 115.167, 8, ""),
    "SUB": A("JUANDA INTL", -7.380, 112.787, 7, ""),
    "HAN": A("NOI BAI INTL", 21.221, 105.807, 7, ""),
    "SGN": A("TAN SON NHAT INTL", 10.819, 106.653, 7, ""),
    "DAD": A("DA NANG INTL", 16.044, 108.199, 7, ""),
    "PNH": A("PHNOM PENH INTL", 11.547, 104.844, 7, ""),
    "RGN": A("YANGON INTL", 16.907, 96.133, 6.5, ""),
    "PUS": A("GIMHAE INTL", 35.179, 128.938, 9, ""),
    "CJU": A("JEJU INTL", 33.512, 126.493, 9, ""),
    "CTS": A("NEW CHITOSE", 42.775, 141.692, 9, ""),
    "FUK": A("FUKUOKA", 33.586, 130.451, 9, ""),
    "OKA": A("NAHA", 26.206, 127.646, 9, ""),
    "NGO": A("CHUBU CENTRAIR INTL", 34.858, 136.805, 9, ""),
    # ---- Europe ----
    "KIV": A("CHISINAU INTL", 46.928, 28.931, 2, "EU"),
    "TIA": A("TIRANA INTL", 41.415, 19.720, 1, "EU"),
    "PRN": A("ADEM JASHARI INTL", 42.573, 21.036, 1, "EU"),
    "SJJ": A("SARAJEVO INTL", 43.825, 18.331, 1, "EU"),
    "SKP": A("SKOPJE INTL", 41.962, 21.621, 1, "EU"),
    "POD": A("PODGORICA", 42.359, 19.252, 1, "EU"),
    "LJU": A("LJUBLJANA JOZE PUCNIK", 46.224, 14.458, 1, "EU"),
    "VAR": A("VARNA", 43.232, 27.825, 2, "EU"),
    "BOJ": A("BURGAS", 42.570, 27.515, 2, "EU"),
    "KRK": A("KRAKOW JOHN PAUL II INTL", 50.078, 19.785, 1, "EU"),
    "GDN": A("GDANSK LECH WALESA", 54.378, 18.466, 1, "EU"),
    "WRO": A("WROCLAW NICOLAUS COPERNICUS", 51.103, 16.886, 1, "EU"),
    "KTW": A("KATOWICE INTL", 50.474, 19.080, 1, "EU"),
    "POZ": A("POZNAN LAWICA", 52.421, 16.826, 1, "EU"),
    "BUD": A("BUDAPEST FERENC LISZT INTL", 47.437, 19.262, 1, "EU"),
    "BTS": A("M R STEFANIK", 48.170, 17.213, 1, "EU"),
    "LCA": A("LARNACA INTL", 34.875, 33.625, 2, "EU"),
    "PFO": A("PAPHOS INTL", 34.718, 32.486, 2, "EU"),
    "RHO": A("RHODES DIAGORAS", 36.405, 28.086, 2, "EU"),
    "HER": A("HERAKLION INTL", 35.340, 25.180, 2, "EU"),
    "CHQ": A("CHANIA INTL", 35.532, 24.150, 2, "EU"),
    "CFU": A("CORFU INTL", 39.602, 19.912, 2, "EU"),
    "ZTH": A("ZAKYNTHOS INTL", 37.751, 20.884, 2, "EU"),
    "JMK": A("MYKONOS", 37.435, 25.348, 2, "EU"),
    "JTR": A("SANTORINI", 36.399, 25.479, 2, "EU"),
    "KGS": A("KOS INTL", 36.793, 27.092, 2, "EU"),
    "SKG": A("THESSALONIKI MACEDONIA", 40.520, 22.971, 2, "EU"),
    "KEF": A("KEFLAVIK INTL", 63.985, -22.606, 0, ""),
    # ---- Africa ----
    "LOS": A("MURTALA MUHAMMED INTL", 6.577, 3.321, 1, ""),
    "ABV": A("NNAMDI AZIKIWE INTL", 9.007, 7.263, 1, ""),
    "ACC": A("KOTOKA INTL", 5.605, -0.167, 0, ""),
    "DKR": A("BLAISE DIAGNE INTL", 14.671, -17.073, 0, ""),
    "ALG": A("HOUARI BOUMEDIENE", 36.691, 3.215, 1, ""),
    "TUN": A("TUNIS CARTHAGE INTL", 36.851, 10.227, 1, ""),
    "CMN": A("MOHAMMED V INTL", 33.368, -7.590, 1, ""),
    "RAK": A("MARRAKECH MENARA", 31.607, -8.036, 1, ""),
    "AGA": A("AGADIR AL MASSIRA", 30.381, -9.546, 1, ""),
    "RBA": A("RABAT SALE", 34.051, -6.752, 1, ""),
    "NBO": A("JOMO KENYATTA INTL", -1.319, 36.926, 3, ""),
    "EBB": A("ENTEBBE INTL", 0.042, 32.444, 3, ""),
    "DAR": A("JULIUS NYERERE INTL", -6.878, 39.203, 3, ""),
    "KGL": A("KIGALI INTL", -1.969, 30.139, 2, ""),
    "ADD": A("BOLE INTL", 8.978, 38.799, 3, ""),
    "CPT": A("CAPE TOWN INTL", -33.969, 18.602, 2, ""),
    "DUR": A("KING SHAKA INTL", -29.614, 31.120, 2, ""),
    "HRE": A("ROBERT GABRIEL MUGABE INTL", -17.932, 31.093, 2, ""),
    "LUN": A("KENNETH KAUNDA INTL", -15.331, 28.453, 2, ""),
    "WDH": A("HOSEA KUTAKO INTL", -22.480, 17.471, 2, ""),
    "MRU": A("SIR SEEWOOSAGUR RAMGOOLAM INTL", -20.430, 57.683, 4, ""),
    "SEZ": A("SEYCHELLES INTL", -4.674, 55.522, 4, ""),
    "TNR": A("IVATO INTL", -18.797, 47.479, 3, ""),
    # ---- Oceania / Pacific ----
    "WLG": A("WELLINGTON INTL", -41.327, 174.805, 12, "NZ"),
    "CHC": A("CHRISTCHURCH INTL", -43.489, 172.532, 12, "NZ"),
    "ZQN": A("QUEENSTOWN", -45.021, 168.739, 12, "NZ"),
    "OOL": A("GOLD COAST", -28.165, 153.505, 10, "AU"),
    "CNS": A("CAIRNS INTL", -16.886, 145.755, 10, ""),
    "DRW": A("DARWIN INTL", -12.415, 130.877, 9.5, ""),
    "ADL": A("ADELAIDE", -34.945, 138.531, 9.5, "AU"),
    "PER": A("PERTH", -31.940, 115.967, 8, ""),
    "HBA": A("HOBART", -42.836, 147.510, 10, "AU"),
    "PPT": A("FAA'A INTL", -17.554, -149.607, -10, ""),
    "NAN": A("NADI INTL", -17.755, 177.443, 12, ""),
    "RAR": A("RAROTONGA INTL", -21.203, -159.805, -10, ""),
    "NOU": A("LA TONTOUTA INTL", -22.014, 166.213, 11, ""),
})

CITY_ALIASES.update({
    "indianapolis": "IND", "austin": "AUS", "nashville": "BNA",
    "raleigh": "RDU", "durham": "RDU", "kansas city": "MCI",
    "columbus": "CMH", "pittsburgh": "PIT", "st louis": "STL",
    "saint louis": "STL", "cleveland": "CLE", "cincinnati": "CVG",
    "northern kentucky": "CVG", "hartford": "BDL", "bradley": "BDL",
    "providence": "PVD", "buffalo": "BUF", "oakland": "OAK",
    "san jose": "SJC", "orange county": "SNA", "santa ana": "SNA",
    "palm springs": "PSP", "boise": "BOI", "reno": "RNO",
    "albuquerque": "ABQ", "tucson": "TUS", "oklahoma city": "OKC",
    "tulsa": "TUL", "des moines": "DSM", "omaha": "OMA",
    "new orleans": "MSY", "birmingham": "BHM", "louisville": "SDF",
    "memphis": "MEM", "charleston": "CHS", "savannah": "SAV",
    "jacksonville": "JAX", "richmond": "RIC", "norfolk": "ORF",
    "virginia beach": "ORF", "manchester": "MHT", "albany": "ALB",
    "syracuse": "SYR", "rochester": "ROC", "grand rapids": "GRR",
    "milwaukee": "MKE", "madison": "MSN", "fargo": "FAR",
    "anchorage": "ANC", "calgary": "YYC", "edmonton": "YEG",
    "ottawa": "YOW", "halifax": "YHZ", "winnipeg": "YWG",
    "quebec city": "YQB", "cancun": "CUN", "san juan": "SJU",
    "puerto rico": "SJU", "santo domingo": "SDQ", "punta cana": "PUJ",
    "nassau": "NAS", "bahamas": "NAS", "barbados": "BGI",
    "bridgetown": "BGI", "trinidad": "POS", "port of spain": "POS",
    "georgetown": "GEO", "guyana": "GEO", "aruba": "AUA",
    "curacao": "CUR", "st maarten": "SXM", "saint martin": "SXM",
    "kingston": "KIN", "jamaica": "MBJ", "montego bay": "MBJ",
    "havana": "HAV", "cuba": "HAV", "costa rica": "SJO",
    "panama city": "PTY", "panama": "PTY", "san salvador": "SAL",
    "el salvador": "SAL", "guatemala city": "GUA", "guatemala": "GUA",
    "belize": "BZE", "belize city": "BZE", "managua": "MGA",
    "nicaragua": "MGA", "liberia": "LIR", "guayaquil": "GYE",
    "quito": "UIO", "asuncion": "ASU", "montevideo": "MVD",
    "uruguay": "MVD", "recife": "REC", "salvador": "SSA",
    "brasilia": "BSB", "kuwait": "KWI", "kuwait city": "KWI",
    "manama": "BAH", "bahrain": "BAH", "muscat": "MCT", "oman": "MCT",
    "jeddah": "JED", "dammam": "DMM", "riyadh": "RUH", "medina": "MED",
    "amman": "AMM", "jordan": "AMM", "dhaka": "DAC",
    "colombo": "CMB", "sri lanka": "CMB", "kathmandu": "KTM",
    "nepal": "KTM", "islamabad": "ISB", "lahore": "LHE",
    "karachi": "KHI", "tashkent": "TAS", "uzbekistan": "TAS",
    "almaty": "ALA", "bishkek": "FRU", "kyrgyzstan": "FRU",
    "yerevan": "EVN", "armenia": "EVN", "tbilisi": "TBS",
    "baku": "GYD", "azerbaijan": "GYD", "male": "MLE",
    "maldives": "MLE", "hyderabad": "HYD", "bengaluru": "BLR",
    "bangalore": "BLR", "chennai": "MAA", "kolkata": "CCU",
    "cochin": "COK", "kochi": "COK", "penang": "PEN", "manila": "MNL",
    "cebu": "CEB", "jakarta": "CGK", "bali": "DPS", "denpasar": "DPS",
    "surabaya": "SUB", "hanoi": "HAN", "ho chi minh": "SGN",
    "saigon": "SGN", "da nang": "DAD", "phnom penh": "PNH",
    "yangon": "RGN", "rangoon": "RGN", "busan": "PUS", "jeju": "CJU",
    "sapporo": "CTS", "fukuoka": "FUK", "okinawa": "OKA",
    "naha": "OKA", "nagoya": "NGO", "chisinau": "KIV",
    "moldova": "KIV", "tirana": "TIA", "albania": "TIA",
    "pristina": "PRN", "kosovo": "PRN", "sarajevo": "SJJ",
    "bosnia": "SJJ", "skopje": "SKP", "podgorica": "POD",
    "montenegro": "POD", "ljubljana": "LJU", "slovenia": "LJU",
    "varna": "VAR", "burgas": "BOJ", "krakow": "KRK", "cracow": "KRK",
    "gdansk": "GDN", "wroclaw": "WRO", "katowice": "KTW",
    "poznan": "POZ", "budapest": "BUD", "bratislava": "BTS",
    "larnaca": "LCA", "cyprus": "LCA", "paphos": "PFO",
    "rhodes": "RHO", "heraklion": "HER", "crete": "HER",
    "chania": "CHQ", "corfu": "CFU", "zakynthos": "ZTH",
    "zante": "ZTH", "mykonos": "JMK", "santorini": "JTR",
    "thira": "JTR", "kos": "KGS", "thessaloniki": "SKG",
    "keflavik": "KEF", "reykjavik": "KEF", "iceland": "KEF",
    "lagos": "LOS", "abuja": "ABV", "accra": "ACC", "ghana": "ACC",
    "dakar": "DKR", "senegal": "DKR", "algiers": "ALG",
    "algeria": "ALG", "tunis": "TUN", "tunisia": "TUN",
    "casablanca": "CMN", "marrakech": "RAK", "marrakesh": "RAK",
    "agadir": "AGA", "rabat": "RBA", "nairobi": "NBO", "kenya": "NBO",
    "entebbe": "EBB", "kampala": "EBB", "uganda": "EBB",
    "dar es salaam": "DAR", "tanzania": "DAR", "kigali": "KGL",
    "rwanda": "KGL", "addis ababa": "ADD", "ethiopia": "ADD",
    "cape town": "CPT", "durban": "DUR", "harare": "HRE",
    "zimbabwe": "HRE", "lusaka": "LUN", "zambia": "LUN",
    "windhoek": "WDH", "namibia": "WDH", "mauritius": "MRU",
    "seychelles": "SEZ", "antananarivo": "TNR", "madagascar": "TNR",
    "wellington": "WLG", "christchurch": "CHC", "queenstown": "ZQN",
    "gold coast": "OOL", "cairns": "CNS", "darwin": "DRW",
    "adelaide": "ADL", "perth": "PER", "hobart": "HBA",
    "papeete": "PPT", "tahiti": "PPT", "nadi": "NAN", "fiji": "NAN",
    "rarotonga": "RAR", "noumea": "NOU", "new caledonia": "NOU",
})
