# GDS BLACK WINDOW ITINERARY CONVERTER

A Windows PC desktop app that converts flight data from **any source** —
Google Flights text or screenshots, airline websites, email confirmations,
PDF text, partial notes — into clean, copy-paste-ready **GDS Black Window
itineraries**, following your master conversion spec exactly.

**Paste → Convert → press COPY.** (v1.4+: nothing touches your clipboard
until you click COPY by design.)

**v2.7 — the installer is THE default package.** Office rollout ships as one
file, `SpicyTerminal-Setup-v$VER.exe`, a standard Inno Setup installer
(produced by `build_setup.sh`; script template `setup.iss`). It wraps the
onedir folder build, installs to `%LOCALAPPDATA%\SpicyTerminal` with no
admin rights, and was confirmed AV-clean on office PCs — the self-extracting
onefile exe was the shape antivirus kept flagging (PyInstaller and Nuitka
alike), so the onefile remains only an alternate. Welcome screen is now a
compact 620x600 intro (from 900x880).

**v2.8 — native macOS support, shipped as ONE installer file like Windows.**
`SpicyTerminal-$VER.dmg` (built by `mac/build_mac_dmg.sh`) opens to a real
`SpicyTerminal.app` (plist + icns + embedded engine) the user drags into
Applications; its launcher (`mac/dmg/SpicyTerminal.launcher`) bootstraps an
isolated venv in `~/Library/Application Support` and speaks native macOS
dialogs via osascript. **v2.9 fixed the "dmg does not open" issue:** modern
macOS silently refuses an ISO9660 image named .dmg, so the image is now a
FAT32 raw disk image (built with mtools) — macOS mounts msdos images
natively and the executable bit is preserved.
`SpicyTerminal_for_Mac.zip` remains as the no-frills alternate, shipping the
same engine for Mac: a double-clickable `SpicyTerminal.command` (in `mac/`) that
self-detects Python 3, creates an isolated `.spicy_venv`, installs
customtkinter/pillow/darkdetect/requests, verifies tkinter, and launches
`app.py`. The updater's .bat self-swap is guarded off non-Windows
(`sys.platform != "win32"` — Mac users get a "new zip from Lamar" note), and
all deferred `iconbitmap(.ico)` callbacks are crash-proofed via
`_safe_iconbitmap_cb` (real find from the first X11 run). Fonts fall back to
Menlo/Helvetica Neue on macOS.

**v2.9 — dead-CONVERT hardening.** A wedged AI call used to leave the
buttons silent for minutes: a 4-minute watchdog now force-revives the UI,
busy clicks give visible feedback, stuck worker results are ignored via a
generation counter, AUTO-fallback AI fails fast at 60s (explicit ✦ AI keeps
180s), and every modal dialog is lifted above the app before its grab.

**v3.0 — the CONVERT-freeze fix (office's last open ticket).** "CONVERT
freezes with nothing unless I click ✦ AI" had two compounding causes, both
fixed: (1) the offline parser re-compiled ~1,100 city-alias regexes on every
block scan — 8.6 seconds on a full-page Google paste, now ONE precompiled
alternation (254/254 tests; 300 cards parse in ~0.1s, ~79x faster); (2) the
offline engine ran inside the click handler on the UI thread — it now runs
in a worker thread with an instant "CONVERTING OFFLINE…" status and a 30s
fuse that revives the buttons even if parsing ever hangs again. The GUI can
no longer freeze on any paste.

**v3.1 — "it doesn't even try to convert offline first" fix.** Whenever
offline produced a partial result, the auto-AI fallback used to leave the
OUTPUT box empty while it spun — reading exactly like offline never ran.
Now the offline partial is SHOWN immediately ("OFFLINE ENGINE (partial —
AI finishing…)"), and if AI errors the offline result is RESTORED instead
of leaving the agent with nothing. Also added Palermo (PMO) + Catania
(CTA) airports/aliases — a JFK→PMO Google paste now converts 100%
offline with a real distance (no more bare "PMO" / "0 N").

**v3.2 — hidden stops + never-silent drops.** Same airline + SAME flight
number continuing through one airport with a sane ground time is now ONE
segment (GDS convention: `1 EY 499 … SIN LIS … 16.50 …` + `STOP-AUH`)
instead of two full segments — disclosed in the status bar, never silent.
Merges need verifiable timing (UTC offsets), so real connections with
different flight numbers (EY 499 vs EY 99) stay separate. And a GDS row
that fails to read is now called out by input line number
("flight row(s) NOT read — input line(s) 5, 6…") instead of vanishing.

**v3.3 — ONE ticket, date order.** Agents copy legs ticket by ticket
(numbered 1,2 / 1,2 / 1,2, sometimes mistyped). The output is now always
ONE continuous sequence renumbered 1..N in chronological date order
(same-day legs by departure clock), no matter how the input was grouped —
and a DEC…JAN turnover still keeps DEC first. Hidden-stop merges and the
never-silent row guard from v3.2 ride along.

**v2.0 — every Google Flights layout parses**: handles the round-trip
variant where the flight anchor sits mid-block (title headers like "New
York (JFK) to Mumbai (BOM) on Thu, Dec 10", then times, then "Turkish
Airlines 12"), summary/journey titles never steal a leg's route, parenthesised
layover tokens ("(2h 25m)") can never become block time, inline arrival
dates ("5:20 AM on Fri, Dec 11") set the ¥1 marker explicitly without
hijacking the segment date, and the date-coherence frame honours
year-turnover trips (Dec 10 -> Jan 3).

**v1.9 — dates you can trust + mandatory welcome:** new date-sequence
coherence engine: every connection must be physically possible (next leg
departs after the previous one lands, timezone-corrected) — soft dates
(inherited/guessed) get auto-repaired with a disclosure warning, explicit
dates are kept but flagged ("date sequence impossible — verify"). Ambiguous
slash dates (`08/12/2026`) now follow the US convention instead of being
dropped. Window/tab bar title is just `SpicyTerminal v{version}`. The
welcome screen (credit: LAMAR GARCIA — MADE WITH LOVE) now appears at EVERY
launch and cannot be switched off; the "show at every launch" checkbox is
gone.

**v1.8 — incomplete pastes finish themselves:** when a leg's route line
(`X (AAA) to Y (BBB)`) never makes it into the copy (collapsed Google
Flights card / partial selection), the offline engine used to emit
`???` + "destination airport unknown". Now: (1) lone date lines
("Sat, Sep 12") correctly start the next flight's block even without a
header, so the leg keeps its own date & times; (2) in Auto mode the app
notices missing fields and finishes the conversion with AI automatically;
(3) offline-only mode tells you exactly which line is missing.

**v1.7 — self-healing AI model setting:** junk in the Settings MODEL box
(pasted `models/` prefix, spaces, typos, a renamed/retired model slug) used
to kill AI conversion with `Gemini HTTP 400: unexpected model name format`.
The app now cleans the name automatically and, if the provider still rejects
it, retries once with the built-in default model — conversion just works.
The error popup for a bad model name is also much clearer.

**v1.6 — minimal modern UI:** almost all words removed from the main window.
Header is brand + tiny engine chip (`GEMINI ✓`) + three icon buttons
(`?` intro, `!` report bug, `⚙` settings). Left pane says `INPUT`, right
pane `OUTPUT` with `SAVE`/`COPY`. Buttons: `▶ CONVERT`, `✦ AI`, `+`,
`✕`. Every icon has a hover tooltip, and the input box shows a grey
placeholder that disappears when you paste. Buttons/labels use a clean
sans font; the black-window itinerary stays mono-green as required.

**v1.5 fix:** multi-flight Google-Flights pastes no longer cross-contaminate
(every leg keeps its OWN route/date/times — previously a leg could steal the
next block's route line and the first block's times, producing wrong/"extra"
legs). Parenthesised block times `(8h 55m)` always beat bare `1h 55m`
layover tokens. Exact-duplicate legs (same flight pasted twice) are removed
with a warning. New safety net: if you CONVERT while your input still
contains previously converted text, the status bar warns you to press
**[X] CLEAR ALL** between pastes — that is where "extra legs" came from.

**SpicyTerminal brand (v1.1):** launches with a branded welcome screen
(logo, "why a dedicated tool beats a prompt to AI", credit: **Lamar Garcia**,
flame-S app icon). Re-open it any time with the **[?] INTRO** button in the
header. A ready-to-send rollout mail for the office is in
**`OFFICE_ANNOUNCEMENT_EMAIL.txt`**.

> **Ready-to-run:** the prebuilt Windows app is at
> **`release\SpicyTerminal.exe`** — a single file, no Python or
> installation needed. Download/copy it and double-click. (First launch
> may show SmartScreen for unsigned apps: *More info → Run anyway*.)

---

## 1. Features

| Capability | Details |
|---|---|
| **Offline engine** | Rule-based parser. No internet or API key needed. Handles Google Flights pastes, airline emails, prose, 24h times, GDS-style times, city names, codeshares (marketing carrier), booking classes, cabins. |
| **AI engine (optional)** | Claude (Anthropic) or GPT (OpenAI), driven by your exact master system prompt. Handles *any* mess, multiple fare options, and **screenshots/images** (vision). |
| **Hybrid Auto mode** | Offline first (instant, free); automatically falls back to AI if nothing was parsed or data was image-only. Force either engine anytime. |
| **Screenshots** | Paste with **Ctrl+V** straight from the clipboard or via **Add Screenshot(s)** button. Up to 10 images per conversion. |
| **Black Window output** | Green-on-black monospace terminal view, exact 4-line segments + `<--additional-->` section, single-space fields, `¥1/¥2/¥3` overnight markers, auto-copied to clipboard, Save as `.txt`. |
| **CLI mode** | Batch-convert from the command line without the GUI. |

Converted output example (from pasted text):

```
1 QR 704 15JAN JFK DOH 930P 520P¥1 I 359 12.50 6702 N
DEP-JOHN F KENNEDY INTL
ARR-HAMAD INTL
CABIN-BUSINESS

<--additional-->
1 QR 704I 15JAN
```

---

**Verified before shipping:** 55/55 engine checks pass (`python tests.py`);
the shipped `.exe` itself was driven end-to-end (typed input → CONVERT →
itinerary rendered → clipboard auto-copied), plus Settings save, screenshot
paste, and AI error handling — all captured on screen during QA
(`app_screenshot.png`).

---

## 2. Quick start (run from source)

Requirements: **Python 3.10+** (Windows: install from python.org, tick
"Add Python to PATH").

```bat
cd gds_converter
pip install -r requirements.txt
python app.py
```

Try the samples: open `sample_texts.txt`, copy any block, paste into the
app, hit **CONVERT**.

---

## 3. Build a standalone Windows .exe

On a Windows PC with Python installed:

```bat
cd gds_converter
build_exe.bat
```

Done → `release\SpicyTerminal.exe`. It's one self-contained
file (no Python needed); copy it anywhere — e.g. the desktop or a USB
stick. Double-click to run.

> First launch may trigger a SmartScreen prompt because the exe is
> unsigned: **More info → Run anyway**.

---

## 4. AI setup (optional but recommended)

Only needed for: screenshots/images, very messy input, or multi-option
itineraries.

1. Open **⚙ SETTINGS / API KEY** in the app.
2. Pick a provider:
   - **Anthropic (Claude)** — key from <https://console.anthropic.com/settings/keys> (default model `claude-sonnet-5`)
   - **OpenAI (GPT)** — key from <https://platform.openai.com/api-keys> (default model `gpt-5`)
3. Paste the key, press **TEST** to verify, then **SAVE**.

Notes:

- The key is stored **locally on your own PC only** (lightly obfuscated
  in `%USERPROFILE%\.gds_converter_config.json`). It never leaves your
  machine except to the provider's official API.
- The model name field is editable — any current/future vision-capable
  model ID for the chosen provider works.
- AI conversions cost a few cents of API credit each at most (text-only
  is a fraction of that).
- Without a key the app remains fully usable in **Offline** mode (text
  input only).

**Engine modes** (in Settings): `Auto` = offline first, AI fallback ·
`Offline` = never call AI · `AI` = always call AI. The **CONVERT WITH AI**
button forces AI regardless of mode.

---

## 5. How it works

```
gds_converter/
├── app.py              GUI (customtkinter black-window UI) + CLI
├── parser_offline.py   rule-based offline parser
├── formatter.py        renders segments to the exact GDS format + QC
├── aviation_data.py    airlines/airports(+coords, timezones, DST)/aircraft DB
├── ai_engine.py        Anthropic + OpenAI API calls (text & images)
├── system_prompt.py    your master system prompt (used verbatim in AI mode)
├── requirements.txt
├── build_exe.bat       one-command PyInstaller build for Windows
├── tests.py            55-check engine test suite (python tests.py)
├── app_screenshot.png  screenshot of the running app (captured during QA)
└── sample_texts.txt    sample inputs for testing
```

**Offline engine** — determines flight anchors (airline + flight number),
detects whether each flight's data sits before or after its anchor
(Google Flights vs prose layout), extracts dates/times/routes/cabins/
aircraft/booking classes, computes overnight markers using **real timezone
& DST rules** per airport/date, distances via great-circle math, and block
times from your input's displayed duration when present.

**AI engine** — sends your text + screenshots to Claude or GPT with the
master system prompt attached, then extracts the itinerary code block.

> Note on Field 11/12 (flight time & distance): the offline engine
> *computes* them from actual UTC offsets/DST and great-circle distance,
> so values are internally consistent estimates (per spec rule
> "ESTIMATE... NEVER leave blank"). AI mode may instead use published
> scheduled block times. Either is spec-compliant; treat both as estimates.

The offline parser is best-effort by design — unparseable fields become
`???`/`????` with a warning in the status bar, and you're one click from
**CONVERT WITH AI** for the hard cases.

---

## 6. CLI usage

```bat
python app.py --cli --text "EK 924 12AUG CAI DXB 1250P 610P Y 77W"
python app.py --cli --file flights.txt
type flights.txt | python app.py --cli
python app.py --cli --ai --text "messy stuff..."      (uses saved API key)
python app.py --cli --text "..." --warnings           (show parser warnings)
```

Output goes to stdout, ready to redirect/copy.

---

## 7. Supported input examples

- `Qatar Airways QR 704, Jan 15, departs JFK 9:30 PM, arrives DOH 5:20 PM+1, Airbus A350-900. Business class, booking class I.`
- Raw Google Flights itinerary text (times-airline-duration-route-flight# blocks), with layovers (ignored automatically).
- `EK 924 12AUG CAI DXB 1250P 610P Y 77W` (GDS-style)
- `EgyptAir flight MS 777 on 2026-03-15, departing Cairo (CAI) at 09:40 and arriving Dubai at 15:05` (24h email style)
- City names without airport codes (`from Cairo to Dubai`) — primary international airport chosen per spec.
- Codeshares — marketing carrier always used (`QR 8112 operated by Royal Air Maroc` → `QR`).
- All-business / first class / premium economy bookings, explicit RBD
  letters (preserved verbatim), per-segment cabin overrides.

See `sample_texts.txt` for copy-paste test blocks.


## v2.1 — AI RESILIENCE (auto-retry + engine failover)
- The Gemini HTTP 503 "high demand" outage no longer kills a conversion:
  transient errors (503/502/500/429, overload, timeouts, network drops)
  are auto-retried (3 attempts with backoff on the chosen engine), then
  SpicyTerminal AUTO-SWITCHES to every other engine it has a key for
  (Gemini -> OpenRouter -> Groq -> Anthropic -> OpenAI).
- Live progress in the status bar ("OPENAI busy - retrying...",
  "OPENAI unavailable -> GEMINI answered").
- Status bar reports which engine actually answered, e.g.
  "AI (GEMINI) - 2 segment(s) - GPT down/busy -> auto-switched".
- convert() returns AIResult (str subclass) carrying .provider / .attempts /
  .failover_from. Custom MODEL names apply only to the selected engine
  (backup engines use their own defaults); the v1.7 bad-model-name rescue
  still runs first. Screenshots are never sent to text-only backup engines.
- If EVERY engine fails, one combined error lists what each engine said.
- friendly_ai_error maps 503/overload to a real explanation
  (no more dead-end "send it for support" popup).
- Proven on the shipped exe with engine=OpenAI (dead key, HTTP 429):
  auto-switched -> Gemini completed the itinerary (proof_v21_failover*.png).


## v2.2 — SMART REPORT + SELF-UPDATE + IMAGE-AWARE INPUT
- REPORT BUG rebuilt: raw mailto: silently failed on PCs with no mail
  client ('opens the browser and does nothing' — Windows also caps
  mailto URL length). New SMART BUG REPORT dialog: assembles FULL
  diagnostics (version/engine/recent errors/exact input+output — never
  API keys), copies it to the clipboard on open, and offers GMAIL /
  OUTLOOK / MAIL APP buttons using short URLs that always survive; the
  draft says 'press CTRL+V'. Your beetle icon is the header button.
- SELF-UPDATE (updater.py): Settings -> CHECK FOR UPDATES reads
  https://bcflights.com/spicyterminal/version.json
  {version,url,sha256,notes}. Newer -> INSTALL downloads the exe,
  verifies sha256, swaps via helper .bat and relaunches. A silent
  background check runs at every launch (only speaks when an update
  exists). Graceful 'server n/a' when nothing is published yet.
- IMAGE-AWARE CONVERT: a pasted screenshot (Ctrl+V) used to be ignored
  whenever the pasted text parsed offline. Now an attached screenshot
  sends the job to vision AI automatically (status: 'Screenshot
  attached — sending to AI so it's read...'), with v2.1 failover
  behind it. Offline mode says honestly that screenshots are ignored.
- New wordmark logo (welcome screen) from the office's design.
- 151/151 tests green.
