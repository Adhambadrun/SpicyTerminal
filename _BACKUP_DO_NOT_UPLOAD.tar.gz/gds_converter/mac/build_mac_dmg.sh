#!/usr/bin/env bash
# ==============================================================
# build_mac_dmg.sh — DEFAULT macOS package: SpicyTerminal-$VER.dmg
#
# Produces ONE file like the Windows installer: open the dmg, drag
# SpicyTerminal.app to Applications, done. The app bundle embeds the
# full engine; its launcher (mac/dmg/SpicyTerminal.launcher)
# bootstraps an isolated venv in ~/Library/Application Support and
# shows native dialogs (osascript) on slow/error steps.
#
# Built fully on Linux: a FAT32 raw disk image with a .dmg name,
# written by mtools (no mounts needed). macOS mounts msdos images
# natively; v2.9 switched OFF the ISO image route because modern macOS
# silently refuses ISO9660-named-.dmg (the office's "dmg does
# nothing" report). HFS+ mkfs is unavailable in this sandbox.
#
#   bash mac/build_mac_dmg.sh
# ==============================================================
set -e
cd "$(dirname "$0")/.."
VER=$(sed -n 's/^APP_VERSION = "\([^"]*\)".*/\1/p' app.py)
[ -n "$VER" ] || { echo "APP_VERSION not found"; exit 1; }
echo "== SpicyTerminal v$VER — macOS dmg =="

command -v png2icns >/dev/null 2>&1 || sudo apt-get install -y -q icnsutils >/dev/null

STAGE=/tmp/dmgstage
rm -rf "$STAGE"
APP="$STAGE/SpicyTerminal.app/Contents"
mkdir -p "$APP/MacOS" "$APP/Resources"

# --- app bundle ---
sed "s/@APP_VERSION@/$VER/g" mac/dmg/Info.plist > "$APP/Info.plist"
cp mac/dmg/SpicyTerminal.launcher "$APP/MacOS/SpicyTerminal"
chmod 755 "$APP/MacOS/SpicyTerminal"
for f in app.py parser_offline.py formatter.py ai_engine.py aviation_data.py \
         system_prompt.py updater.py requirements.txt; do
  cp "$f" "$APP/Resources/"
done
cp -r assets "$APP/Resources/assets"
# app icon: png2icns needs standard sizes (logo_mark is 316x316) —
# generate 512/256 first, abort loudly if the icns is not written
python3 -c "
from PIL import Image
im = Image.open('assets/logo_mark.png').convert('RGBA')
im.resize((512, 512), Image.LANCZOS).save('/tmp/icon512.png')
im.resize((256, 256), Image.LANCZOS).save('/tmp/icon256.png')"
png2icns /tmp/app.icns /tmp/icon512.png /tmp/icon256.png
cp /tmp/app.icns "$APP/Resources/app.icns"
[ -s "$APP/Resources/app.icns" ] || { echo "app.icns missing"; exit 1; }

# --- volume root extras ---
cat > "$STAGE/READ_ME_FIRST.txt" <<EOF
SPICYTERMINAL v$VER - MAC INSTALLER
====================================
1. Drag SpicyTerminal.app into your Applications folder.
2. First launch: RIGHT click SpicyTerminal -> Open -> Open
   (macOS asks once because the app came from the internet).
3. First launch needs internet for about 1 minute while the app
   prepares itself. After that it works fully offline.

If it asks for Python: install Python once from python.org/downloads
(the macOS package), then open the app again.

Paste flights -> CONVERT -> COPY. Correct dates, correct booking
classes, real aircraft codes. Nothing leaves this Mac.
questions or a bug: Lamar@bcflights.com (or press the beetle icon).
EOF

OUT="SpicyTerminal-$VER.dmg"
rm -f "/home/user/$OUT"
# FAT32 raw disk image named .dmg — macOS mounts msdos images natively
# (verified practice for building dmgs on Linux when HFS+ tools are
# unavailable; ISO9660-in-dmg gets silently rejected by modern macOS,
# which is exactly what the office hit with the v2.8 build).
# mtools writes files WITHOUT needing a loop mount.
for t in mformat mcopy mdir; do
  command -v $t >/dev/null 2>&1 || sudo apt-get install -y -q mtools dosfstools >/dev/null
done
IMG=/tmp/spicy_fat.img
rm -f "$IMG"
dd if=/dev/zero of="$IMG" bs=1M count=8 status=none
mformat -i "$IMG" -v "SPICY$(echo "$VER" | tr -d .)" ::
mcopy -i "$IMG" -sp "$STAGE/SpicyTerminal.app" ::
mcopy -i "$IMG" -p "$STAGE/READ_ME_FIRST.txt" ::

echo "== verify contents =="
mdir -i "$IMG" -/ :: | grep -iE "spicy|readme|icns" | head -8
file "$IMG"
mv "$IMG" "/home/user/$OUT"
sha256sum "/home/user/$OUT"
ls -la "/home/user/$OUT"
echo "DONE. Mac deliverable: $OUT"
