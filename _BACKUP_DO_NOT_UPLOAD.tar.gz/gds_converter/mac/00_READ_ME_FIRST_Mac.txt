SPICYTERMINAL v3.4 - MAC PACKAGE
================================

1. EXTRACT this zip (double click it in Finder).
   You get a folder: SpicyTerminal_Mac.

2. Open the folder. RIGHT CLICK on "SpicyTerminal.command"
   and choose Open, then Open again.
   (macOS asks once because the file came from the internet.
   After the first time, a simple double click starts the app.)

3. First run needs internet for about 1 minute while it
   prepares its components. After that it works fully offline.

   If it says Python 3 is missing: install Python once from
   python.org/downloads (macOS package), then start again.

WHAT IT DOES
Paste your flights, press CONVERT, press COPY.
Perfect GDS black window itineraries every time:
correct dates, correct booking classes, real aircraft codes.
Works offline; nothing leaves this Mac.

updates: Mac builds update as a fresh zip from Lamar.
questions or a bug: Lamar@bcflights.com (or press the beetle
icon inside the app).
