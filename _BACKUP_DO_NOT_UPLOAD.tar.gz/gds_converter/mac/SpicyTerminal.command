#!/bin/bash
# ==============================================================
#  SpicyTerminal for macOS  ·  DOUBLE CLICK THIS FILE
#  (first run prepares everything by itself, about 1 minute)
# ==============================================================
cd "$(dirname "$0")"

ORANGE='\033[38;5;208m'; GREEN='\033[0;32m'; NC='\033[0m'
echo "${ORANGE}============================================${NC}"
echo "${ORANGE}       S P I C Y T E R M I N A L           ${NC}"
echo "${ORANGE}     GDS BLACK WINDOW CONVERTER · MAC      ${NC}"
echo "${ORANGE}============================================${NC}"

PY=""
for c in python3 python3.13 python3.12 python3.11 python3.10; do
  if command -v "$c" >/dev/null 2>&1; then PY="$c"; break; fi
done

if [ -z "$PY" ]; then
  echo ""
  echo "Python 3 is not on this Mac yet. Install it once (2 minutes),"
  echo "then double click this file again:"
  echo "  · easiest: https://www.python.org/downloads/  (macOS package)"
  echo "  · or with Homebrew:  brew install python@3.12 python-tk@3.12"
  read -n 1 -s -r -p "press any key to close"
  exit 1
fi

V="$("$PY" -c 'import sys;print("%d.%d" % sys.version_info[:2])')"
echo "found python $V"

if ! "$PY" -c "import tkinter" >/dev/null 2>&1; then
  echo ""
  echo "this python has no tkinter module (needed for the window)."
  echo "fix: install the python.org package from python.org/downloads"
  echo "or with Homebrew:  brew install python-tk@3.12"
  read -n 1 -s -r -p "press any key to close"
  exit 1
fi

if [ ! -d ".spicy_venv" ]; then
  echo "first run: preparing SpicyTerminal (one time only)..."
  if ! "$PY" -m venv .spicy_venv 2>/dev/null; then
    echo "could not create the workspace venv."
    echo "fix: install the python.org package (includes venv support)."
    read -n 1 -s -r -p "press any key to close"
    exit 1
  fi
fi
VPY=".spicy_venv/bin/python"

NEED=$("$VPY" -c '
try:
    import customtkinter, PIL, darkdetect, requests
    print("ok")
except Exception:
    print("missing")')

if [ "$NEED" != "ok" ]; then
  echo "installing components (first run only, needs internet)..."
  "$VPY" -m pip install --quiet --upgrade pip
  if ! "$VPY" -m pip install --quiet customtkinter pillow darkdetect requests; then
    echo "download failed. check internet, then double click me again."
    read -n 1 -s -r -p "press any key to close"
    exit 1
  fi
fi

echo "${GREEN}starting SpicyTerminal...${NC}"
exec "$VPY" app.py
