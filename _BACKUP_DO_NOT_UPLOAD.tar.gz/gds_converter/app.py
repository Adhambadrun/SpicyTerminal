"""
app.py — GDS Black Window Itinerary Converter (desktop app).

GUI:  python app.py
CLI:  python app.py --cli "flight text..."      (offline parse to stdout)
      cat flights.txt | python app.py --cli     (reads stdin)
      python app.py --cli --ai "flight text..." (force AI)

The GUI part imports customtkinter lazily so CLI mode works without it.
"""

import argparse
import base64
import io
import json
import os
import sys
import time
import threading
from pathlib import Path

APP_TITLE = "GDS BLACK WINDOW ITINERARY CONVERTER"
BRAND = "SPICY TERMINAL"
CREDIT = "LAMAR GARCIA"
APP_VERSION = "3.4"
WINDOW_TITLE = f"SpicyTerminal v{APP_VERSION}"
CONFIG_PATH = Path.home() / ".gds_converter_config.json"


def resource_path(rel):
    """Resolve bundled assets both in source runs and frozen (PyInstaller) runs."""
    base = getattr(sys, "_MEIPASS", None) or os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, rel)


def friendly_ai_error(err):
    """Map a raw API error to a plain-language fix hint."""
    e = (err or "").lower()
    if ("401" in e or "unauthorized" in e or "api key not valid" in e
            or ("invalid" in e and "key" in e) or "authentication" in e):
        return ("The key was REJECTED. Check: (1) the selected PROVIDER "
                "matches where the key was made (aistudio.google.com = Gemini, "
                "console.groq.com = Groq, openrouter.ai = OpenRouter); "
                "(2) no spaces or line breaks around it; "
                "(3) it hasn't been deleted/regenerated.")
    if "unexpected model name format" in e or ("400" in e and "model" in e):
        return ("The MODEL box name is invalid (spaces / 'models/' prefix / "
                "wrong spelling). CLEAR the MODEL box — blank uses the "
                "built-in default. Tip: v1.7 auto-fixes this and retries "
                "with the default model by itself.")
    if ("every ai engine" in e or "503" in e or "502" in e
            or "high demand" in e or "overloaded" in e
            or "spikes in demand" in e or "service unavailable" in e):
        return ("The AI engine was overloaded on the provider's side "
                "(temporary — Google's own message). SpicyTerminal already "
                "auto-retried it and tried every backup engine with a key. "
                "Wait 1–2 minutes and press ✦ AI again — or press ▶ CONVERT "
                "to use the offline engine, which never needs the internet.")
    if "404" in e or "not found" in e:
        return ("Model not found for this key — CLEAR the MODEL box (blank = "
                "built-in default) and try again.")
    if "429" in e or "quota" in e or "rate limit" in e or "rate_limit" in e:
        return ("Free-tier quota/rate limit reached — wait a minute (or a "
                "day), or switch to another free provider in Settings.")
    if "403" in e or "permission" in e:
        return ("This key has no access to the selected model — create a "
                "fresh key or pick a different model/provider.")
    if any(k in e for k in ("network", "timeout", "connection", "resolve",
                            "ssl", "proxy")):
        return ("Cannot reach the provider — check internet/proxy/firewall "
                "(office networks sometimes block API hosts; try a hotspot).")
    return ""


def build_bug_report(cfg, input_text, output_text, history,
                     provider_state="", max_field=1500):
    """Assemble the full diagnostic report Lamar asks for — version,
    engine state, recent errors, exact input and output.
    ACCURACY LAW: NEVER includes API keys or the encoded key blob."""
    import datetime
    import platform
    lines = [
        "=== SPICY TERMINAL BUG REPORT ===",
        f"APP: SpicyTerminal v{APP_VERSION}",
        f"WHEN: {datetime.datetime.now():%Y-%m-%d %H:%M:%S}",
        f"PROVIDER: {cfg.get('provider')}  |  MODE: "
        f"{cfg.get('mode', 'Auto')}"
        + (f"  |  {provider_state}" if provider_state else ""),
    ]
    try:
        lines.append(
            f"SYSTEM: {platform.system()} {platform.release()} "
            f"({platform.version()})")
    except Exception:
        pass
    lines += ["", "=== RECENT STATUS / ERRORS ==="]
    hist = [h for h in (history or []) if h]
    lines += hist[-6:] if hist else ["(nothing noteworthy)"]
    lines += [
        "",
        "=== WHAT I PASTED ===",
        (input_text or "").strip()[:max_field] or "(nothing)",
        "",
        "=== WHAT THE APP PRODUCED ===",
        (output_text or "").strip()[:max_field] or "(nothing)",
        "",
        "=== WHAT I EXPECTED INSTEAD ===",
        "",
        "",
        "=== ANY OTHER DETAILS ===",
    ]
    return "\n".join(lines)


class _ToolTip:
    """Tiny hover tooltip — lets the UI stay word-free without becoming
    cryptic. Appears below the widget after a short delay."""

    def __init__(self, widget, text):
        self.w, self.text, self._id, self._win = widget, text, None, None
        widget.bind("<Enter>", self._schedule, add="+")
        widget.bind("<Leave>", self._hide, add="+")
        widget.bind("<ButtonPress>", self._hide, add="+")

    def _schedule(self, _=None):
        self._cancel()
        self._id = self.w.after(450, self._show)

    def _cancel(self):
        if self._id:
            try:
                self.w.after_cancel(self._id)
            except Exception:
                pass
            self._id = None

    def _show(self):
        if self._win:
            return
        try:
            import tkinter as tk
            tw = tk.Toplevel(self.w)
            tw.wm_overrideredirect(True)
            tw.attributes("-topmost", True)
            tk.Label(tw, text=self.text, bg="#111827", fg="#E5E7EB",
                     font=("Segoe UI", 10), padx=9, pady=5,
                     highlightthickness=1,
                     highlightbackground="#374151").pack()
            x = self.w.winfo_rootx() + self.w.winfo_width() // 2 \
                - tw.winfo_reqwidth() // 2
            y = self.w.winfo_rooty() + self.w.winfo_height() + 6
            tw.wm_geometry(f"+{max(x, 4)}+{y}")
            self._win = tw
        except Exception:
            self._win = None

    def _hide(self, _=None):
        self._cancel()
        if self._win:
            try:
                self._win.destroy()
            except Exception:
                pass
            self._win = None


LOGO_PATH = resource_path(os.path.join("assets", "spicy_terminal_logo.png"))
LOGO_MARK_PATH = resource_path(os.path.join("assets", "logo_mark.png"))
ICON_PATH = resource_path(os.path.join("assets", "app_icon.ico"))
BUG_ICON_PATH = resource_path(os.path.join("assets", "bug_icon.png"))

DEFAULT_CONFIG = {
    "provider": "Google Gemini (FREE)",
    "model": "",
    "api_key_b64": "",
    "mode": "Auto",            # Auto | Offline | AI
    "ai_fallback": True,       # try AI automatically if offline finds nothing
    "auto_copy": True,
    "max_images": 10,
    "show_welcome": True,      # show SpicyTerminal welcome screen at launch
}


# =====================================================================
# Config
# =====================================================================
def load_config():
    cfg = dict(DEFAULT_CONFIG)
    try:
        if CONFIG_PATH.exists():
            cfg.update(json.loads(CONFIG_PATH.read_text(encoding="utf-8")))
    except Exception:
        pass
    return cfg


def save_config(cfg):
    try:
        CONFIG_PATH.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    except Exception:
        pass


def _explicit_key(cfg):
    """The user's own saved key only (no built-in fallback)."""
    try:
        return base64.b64decode(cfg.get("api_key_b64", "")).decode().strip()
    except Exception:
        return ""


def get_api_key(cfg):
    """Effective key: personal saved key, else the built-in default key."""
    explicit = _explicit_key(cfg)
    if explicit:
        return explicit
    try:
        import ai_engine
        prov_id = ai_engine.PROVIDERS[cfg["provider"]]["id"]
        return ai_engine.DEFAULT_KEYS.get(prov_id, "")
    except Exception:
        return ""


def set_api_key(cfg, key):
    cfg["api_key_b64"] = base64.b64encode(key.strip().encode()).decode()


# =====================================================================
# Image prep (shared by GUI paths)
# =====================================================================
def prepare_image_bytes(pil_img, max_side=1568):
    img = pil_img.convert("RGB")
    w, h = img.size
    scale = min(1.0, max_side / max(w, h, 1))
    if scale < 1.0:
        img = img.resize((max(1, int(w * scale)), max(1, int(h * scale))))
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=85)
    return buf.getvalue()


# =====================================================================
# Core conversion pipeline (no GUI dependencies)
# =====================================================================
def convert_offline(text):
    from parser_offline import parse
    from formatter import render_itinerary, qc_check
    segments, warnings = parse(text)
    if not segments:
        return None, warnings
    out = render_itinerary(segments)
    qc = qc_check(out, segments)
    return out, warnings + [f"QC: {q}" for q in qc]


def output_incomplete(out, warns):
    """Should the offline result be finished by AI? True only when a ROUTE
    or a CLOCK TIME is actually missing (the classic 'leg without a header'
    Google copy). Unknown aircraft (the '???' column) and unknown distance
    (' 0 N') are perfectly normal for typed/pasted GDS availability rows and
    must never burn a paid AI round-trip (v2.4 fix: pure row pastes like
    'AA 8880 I 26SEP JFK LHR 710P 720A¥1' were wrongly detoured to AI)."""
    return (any("airport unknown" in w or "time missing" in w for w in warns)
            or "????" in out)


def convert_ai(text, image_bytes_list, cfg, on_status=None, timeout_s=None):
    from ai_engine import convert, PROVIDERS, DEFAULT_KEYS
    provider_id = PROVIDERS[cfg["provider"]]["id"]
    explicit = _explicit_key(cfg)

    def _resolver(pid):
        # a personal saved key belongs ONLY to the selected provider;
        # backup engines use their built-in default keys
        if pid == provider_id:
            return explicit or DEFAULT_KEYS.get(pid, "")
        return DEFAULT_KEYS.get(pid, "")

    return convert(text, image_bytes_list, provider_id,
                   get_api_key(cfg), model=cfg.get("model") or None,
                   timeout=int(timeout_s or cfg.get("ai_timeout", 180)),
                   on_status=on_status, key_resolver=_resolver)


# =====================================================================
# CLI
# =====================================================================
def run_cli(args):
    text = args.text
    if not text and args.file:
        text = Path(args.file).read_text(encoding="utf-8", errors="replace")
    if not text:
        text = sys.stdin.read()
    if not text.strip():
        print("No input provided.", file=sys.stderr)
        return 1

    if args.ai:
        cfg = load_config()
        try:
            out = convert_ai(text, [], cfg)
        except Exception as e:
            print(f"AI error: {e}", file=sys.stderr)
            return 2
        print(out)
        return 0

    out, warns = convert_offline(text)
    if out is None:
        print("Offline parser found no flights. Try --ai.", file=sys.stderr)
        for w in warns:
            print(f"  - {w}", file=sys.stderr)
        return 3
    print(out)
    if args.warnings:
        for w in warns:
            print(f"# {w}", file=sys.stderr)
    return 0


# =====================================================================
# GUI
# =====================================================================
def run_gui():
    # Promote GUI-only imports to module globals so the App / SettingsDialog
    # methods below can resolve them (class methods can't close over this
    # function's locals). CLI mode never calls run_gui, so customtkinter is
    # only imported when the GUI actually starts.
    global ctk, filedialog, messagebox, tkfont, Image, ImageGrab, ai_engine
    import customtkinter as ctk
    from tkinter import filedialog, messagebox, font as tkfont
    from PIL import Image
    try:
        from PIL import ImageGrab
    except Exception:
        ImageGrab = None
    import ai_engine

    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("blue")

    # -------------------------------------------------------------
    class SettingsDialog(ctk.CTkToplevel):
        def __init__(self, app):
            super().__init__(app)
            self.app = app
            self.title("Settings & AI API Key")
            self.geometry("560x780")
            self.resizable(False, False)
            self.transient(app)
            self.grab_set()
            _raise_dialog(self)
            for d in (200, 900):
                try:
                    self.after(d, lambda self=self: _safe_iconbitmap_cb(self))
                except Exception:
                    pass
            pad = {"padx": 18, "pady": 5}

            toprow = ctk.CTkFrame(self, fg_color="transparent")
            toprow.pack(fill="x", pady=(10, 0))
            ctk.CTkLabel(toprow, text="▮ " + BRAND,
                         font=(app.mono_b[0], 17, "bold"),
                         text_color="#FF7A1A").pack(side="left", padx=(18, 0))
            try:
                mark = Image.open(LOGO_MARK_PATH)
                ci = ctk.CTkImage(light_image=mark, dark_image=mark,
                                  size=(46, 46))
                ctk.CTkLabel(toprow, image=ci, text="").pack(
                    side="right", padx=16)
            except Exception:
                pass

            ctk.CTkLabel(
                self, text="AI PROVIDER — Gemini / Groq / OpenRouter offer\n"
                           "FREE keys (no credit card needed)",
                font=("Consolas", 13, "bold"), justify="left").pack(
                anchor="w", **pad)
            self.provider = ctk.CTkOptionMenu(
                self, values=list(ai_engine.PROVIDERS.keys()), width=380,
                command=self._provider_changed)
            self.provider.set(app.cfg["provider"])
            self.provider.pack(anchor="w", **pad)

            self.free_lbl = ctk.CTkLabel(self, text="", font=("Consolas", 11),
                                         text_color="#33FF66", wraplength=490,
                                         justify="left")
            self.free_lbl.pack(anchor="w", **pad)

            keyrow = ctk.CTkFrame(self, fg_color="transparent")
            keyrow.pack(anchor="w", **pad)
            ctk.CTkButton(keyrow, text="» GET FREE API KEY", width=190,
                          fg_color="#7C2D12", hover_color="#9A3412",
                          command=self._open_key_page).pack(side="left")
            self.key_hint_lbl = ctk.CTkLabel(keyrow, text="",
                                             font=("Consolas", 11),
                                             text_color="#9CA3AF")
            self.key_hint_lbl.pack(side="left", padx=10)

            ctk.CTkLabel(self, text="MODEL (blank = default; no spaces, no 'models/' prefix)",
                         font=("Consolas", 12)).pack(anchor="w", **pad)
            self.model = ctk.CTkEntry(self, width=280,
                                      placeholder_text="e.g. claude-sonnet-5 / gpt-5")
            self.model.insert(0, app.cfg.get("model", ""))
            self.model.pack(anchor="w", **pad)

            ctk.CTkLabel(self, text="API KEY (blank = built-in default key; "
                         "stored locally only)", font=("Consolas", 12),
                         justify="left").pack(anchor="w", **pad)
            row = ctk.CTkFrame(self, fg_color="transparent")
            row.pack(anchor="w", **pad)
            self.key = ctk.CTkEntry(row, width=300, show="*")
            self.key.insert(0, get_api_key(app.cfg))
            self.key.pack(side="left")
            ctk.CTkButton(row, text="TEST KEY", width=86, fg_color="#4B5563",
                          command=self.test_key).pack(side="left", padx=8)
            self.test_lbl = ctk.CTkLabel(row, text="", width=110)
            self.test_lbl.pack(side="left")

            ctk.CTkLabel(self, text="DEFAULT ENGINE MODE", font=("Consolas", 12)
                         ).pack(anchor="w", **pad)
            self.mode = ctk.CTkOptionMenu(self, values=["Auto", "Offline", "AI"],
                                          width=280)
            self.mode.set(app.cfg.get("mode", "Auto"))
            self.mode.pack(anchor="w", **pad)

            self.fallback = ctk.CTkCheckBox(
                self, text="Auto-fallback to AI when offline parser finds nothing")
            if app.cfg.get("ai_fallback", True):
                self.fallback.select()
            self.fallback.pack(anchor="w", **pad)

            ctk.CTkLabel(self,
                         text="Output is copied ONLY when you press COPY.",
                         font=("Consolas", 11),
                         text_color="#9CA3AF").pack(anchor="w", **pad)

            upd = ctk.CTkFrame(self, fg_color="transparent")
            upd.pack(anchor="w", **pad)
            ctk.CTkButton(upd, text="⟳ CHECK FOR UPDATES", width=190,
                          fg_color="#1F6AA5", hover_color="#175A8C",
                          command=self.check_updates).pack(side="left")
            self.upd_lbl = ctk.CTkLabel(upd, text=f"now: v{APP_VERSION}",
                                        font=("Consolas", 11),
                                        text_color="#9CA3AF")
            self.upd_lbl.pack(side="left", padx=10)
            self._upd_install_btn = None
            self._upd_notes_lbl = None

            btns = ctk.CTkFrame(self, fg_color="transparent")
            btns.pack(pady=14)
            ctk.CTkButton(btns, text="SAVE", width=120, fg_color="#0E7C3A",
                          hover_color="#0A5E2C",
                          command=self.save).pack(side="left", padx=8)
            ctk.CTkButton(btns, text="CANCEL", width=120, fg_color="#6B7280",
                          command=self.destroy).pack(side="left", padx=8)

            self._provider_changed()

        def _provider_changed(self, *_):
            info = ai_engine.PROVIDERS[self.provider.get()]
            self.free_lbl.configure(text=info.get("free_note", ""))
            self.key_hint_lbl.configure(text=f"key looks like {info['key_hint']}")
            if not self.model.get().strip():
                self.model.configure(placeholder_text=info["default_model"])

        def _open_key_page(self):
            import webbrowser as _wbf
            _wbf.open(ai_engine.PROVIDERS[self.provider.get()]["key_url"])

        def test_key(self):
            key = self.key.get().strip()
            if not key:
                self.test_lbl.configure(text="no key", text_color="#F59E0B")
                messagebox.showwarning(
                    "Key check", "Paste an API key first — or click "
                    "» GET FREE API KEY to create a free one.")
                return
            self.test_lbl.configure(text="testing...", text_color="#9CA3AF")
            prov = ai_engine.PROVIDERS[self.provider.get()]["id"]
            model = self.model.get().strip() or None

            def work():
                ok, msg = ai_engine.test_key(prov, key, model)
                hint = "" if ok else friendly_ai_error(msg)
                self.after(0, lambda: self._test_done(ok, msg, hint))
            threading.Thread(target=work, daemon=True).start()

        def _test_done(self, ok, msg, hint):
            self.test_lbl.configure(
                text="VALID ✓" if ok else msg[:30],
                text_color="#22C55E" if ok else "#EF4444")
            if ok:
                messagebox.showinfo(
                    "Key check ✓",
                    "VALID — the key works with "
                    f"{self.provider.get()}. Click SAVE.")
            else:
                messagebox.showerror(
                    "Key check FAILED",
                    f"Provider: {self.provider.get()}\n\nError: {msg}\n\n"
                    + (hint or "Copy the FULL error above and send it for "
                               "support."))

        def check_updates(self):
            self.upd_lbl.configure(text="checking…", text_color="#9CA3AF")
            for w in (self._upd_install_btn, self._upd_notes_lbl):
                if w:
                    w.destroy()
            self._upd_install_btn = self._upd_notes_lbl = None
            url = self.app.cfg.get("update_url") or None

            def work():
                try:
                    import updater
                    res = updater.check(APP_VERSION, url=url)
                except Exception as e:
                    res = {"status": "unavailable", "error": str(e),
                           "manifest": None}
                self.after(0, lambda: self._updates_done(res))
            threading.Thread(target=work, daemon=True).start()

        def _updates_done(self, res):
            st, man = res.get("status"), (res.get("manifest") or {})
            if st == "newer":
                self.upd_lbl.configure(text=f"v{man.get('version')} ready!",
                                       text_color="#22C55E")
                self._upd_install_btn = ctk.CTkButton(
                    self, text=f"⇩ INSTALL v{man.get('version')} NOW",
                    fg_color="#0E7C3A", hover_color="#0A5E2C",
                    command=lambda: self.install_update(man))
                self._upd_install_btn.pack(anchor="w", padx=18, pady=4)
                if man.get("notes"):
                    self._upd_notes_lbl = ctk.CTkLabel(
                        self, text=str(man["notes"])[:220],
                        font=("Consolas", 10), text_color="#D1D5DB",
                        wraplength=500, justify="left")
                    self._upd_notes_lbl.pack(anchor="w", padx=18)
            elif st == "latest":
                self.upd_lbl.configure(text=f"latest ✓ (v{APP_VERSION})",
                                       text_color="#22C55E")
            else:
                self.upd_lbl.configure(text="server n/a — ask Lamar",
                                       text_color="#F59E0B")
                self.app.set_status("Update check: release info not "
                                    "reachable yet "
                                    f"({str(res.get('error'))[:60]})",
                                    warn=True)

        def install_update(self, man):
            if sys.platform != "win32":
                messagebox.showinfo(
                    "Updates on Mac",
                    "This Mac build updates as a fresh package.\n"
                    "Ask Lamar for the new SpicyTerminal Mac zip.")
                return
            self.upd_lbl.configure(text="downloading… 0%",
                                   text_color="#9CA3AF")
            if self._upd_install_btn:
                self._upd_install_btn.configure(state="disabled")

            def work():
                err, path = None, None
                try:
                    import updater
                    path = updater.install_update(
                        man, on_progress=lambda p: self.after(
                            0, lambda p=p: self.upd_lbl.configure(
                                text=f"downloading… {p}%")))
                except Exception as e:
                    err = str(e)
                self.after(0, lambda: self._install_done(path, err, man))
            threading.Thread(target=work, daemon=True).start()

        def _install_done(self, path, err, man):
            if err:
                self.upd_lbl.configure(text="failed ✕", text_color="#EF4444")
                if self._upd_install_btn:
                    self._upd_install_btn.configure(state="normal")
                messagebox.showerror("Update failed",
                                     str(err) + "\n\nNothing was changed.")
                return
            import sys as _sys
            if getattr(_sys, "frozen", False):
                messagebox.showinfo(
                    "Update ready ✓",
                    f"v{man.get('version')} downloaded and checksum-verified.\n\n"
                    "SpicyTerminal will now close, swap itself and relaunch "
                    "— have a great day!")
                self.destroy()
                self.app.destroy()
            else:
                self.upd_lbl.configure(text="downloaded ✓",
                                       text_color="#22C55E")
                messagebox.showinfo("Downloaded ✓",
                                    f"Update verified — saved to:\n{path}")

        def save(self):
            cfg = self.app.cfg
            cfg["provider"] = self.provider.get()
            cfg["model"] = self.model.get().strip()
            set_api_key(cfg, self.key.get())
            cfg["mode"] = self.mode.get()
            cfg["ai_fallback"] = bool(self.fallback.get())
            save_config(cfg)
            self.app.refresh_engine_label()
            self.app.set_status("Settings saved. API key stored in " +
                                str(CONFIG_PATH))
            self.destroy()

    # -------------------------------------------------------------

    class WelcomeScreen(ctk.CTkToplevel):
        """Branded intro / splash shown at launch (and via the [?] INTRO button)."""

        ORANGE = "#FF7A1A"
        GREEN = "#33FF66"

        def __init__(self, app, modal=False, startup=False):
            super().__init__(app)
            self.app = app
            self.startup = startup
            self.title("Welcome — SpicyTerminal")
            self.resizable(False, False)
            self.configure(fg_color="#050705")
            try:
                self.iconbitmap(ICON_PATH)
            except Exception:
                pass
            for d in (200, 900):
                try:
                    self.after(d, lambda self=self: _safe_iconbitmap_cb(self))
                except Exception:
                    pass
            if modal:
                self.transient(app)
                self.grab_set()
            _raise_dialog(self)
            self.protocol("WM_DELETE_WINDOW", self._launch)

            W, H = 620, 600   # v2.7: compact welcome (was 900x880)
            sw = self.winfo_screenwidth()
            sh = self.winfo_screenheight()
            self.geometry(f"{W}x{H}+{max(0,(sw-W)//2)}+{max(0,(sh-H)//2)}")

            mono = app.mono
            mono_b = app.mono_b

            # ---- logo ----
            head = ctk.CTkFrame(self, fg_color="#050705")
            head.pack(fill="x", pady=(8, 1))
            shown_logo = False
            try:
                logo_pil = Image.open(LOGO_PATH)
                lw, lh = logo_pil.size
                tw = 330
                th = max(1, int(tw * lh / lw))
                ci = ctk.CTkImage(light_image=logo_pil, dark_image=logo_pil,
                                  size=(tw, th))
                ctk.CTkLabel(head, image=ci, text="").pack()
                shown_logo = True
            except Exception:
                pass
            if not shown_logo:
                ctk.CTkLabel(head, text=BRAND, font=(mono_b[0], 26, "bold"),
                             text_color=self.ORANGE).pack()

            ctk.CTkLabel(self, text="WELCOME TO " + BRAND,
                         font=(mono_b[0], 16, "bold"),
                         text_color=self.GREEN).pack(pady=(3, 0))
            ctk.CTkLabel(self, text="»  THE GDS BLACK WINDOW ITINERARY CONVERTER  «",
                         font=(mono_b[0], 10, "bold"),
                         text_color=self.ORANGE).pack(pady=(2, 5))

            # ---- why-better box ----
            why = ctk.CTkFrame(self, fg_color="#0B0F0C",
                               border_color="#1F6AA5", border_width=1,
                               corner_radius=8)
            why.pack(fill="x", padx=24, pady=2)
            ctk.CTkLabel(why, text="WHY A DEDICATED TOOL BEATS A PROMPT TO AI",
                         font=(mono_b[0], 11, "bold"),
                         text_color=self.GREEN).pack(anchor="w", padx=12,
                                                     pady=(6, 1))
            bullets = [
                ("ONE JOB, DONE PERFECTLY",
                 "SpicyTerminal is 100% dedicated to professional GDS itineraries — "
                 "nothing else. A chatbot guesses from a prompt; this engine is "
                 "locked to the specification."),
                ("NO PROMPTS TO WRITE OR MAINTAIN",
                 "Paste your flights, press CONVERT, done. The itinerary lands on "
                 "your clipboard automatically, ready for the black window."),
                ("THE SAME PERFECT OUTPUT, EVERY TIME",
                 "A deterministic offline engine — 13-field flight lines, 12-hour "
                 "clocks, overnight markers, real IATA aircraft codes, exact "
                 "booking-class handling (Z stays Z). No hallucinations, no drift, "
                 "no re-rolling the dice."),
                ("FAST, PRIVATE, OFFLINE",
                 "No internet, no API key — itineraries never leave your PC. "
                 "Optional AI vision kicks in only for messy screenshots."),
            ]
            for title, body in bullets:
                ctk.CTkLabel(why, text="»  " + title,
                             font=(mono_b[0], 10, "bold"),
                             text_color=self.ORANGE, anchor="w",
                             justify="left").pack(anchor="w", padx=16)
                ctk.CTkLabel(why, text=body, font=(mono[0], 10),
                             text_color="#D1D5DB", anchor="w", justify="left",
                             wraplength=520).pack(anchor="w", padx=28,
                                                  pady=(0, 4))

            # ---- credit ----
            credit = ctk.CTkFrame(self, fg_color="#120A05",
                                  border_color=self.ORANGE, border_width=1,
                                  corner_radius=8)
            credit.pack(fill="x", padx=130, pady=(4, 2))
            ctk.CTkLabel(credit, text="D E S I G N E D   &   B U I L T   B Y",
                         font=(mono[0], 8), text_color="#9CA3AF").pack(
                pady=(5, 0))
            ctk.CTkLabel(credit, text=CREDIT, font=(mono_b[0], 15, "bold"),
                         text_color=self.ORANGE).pack()
            ctk.CTkLabel(credit, text="M A D E   W I T H   L O V E",
                         font=(mono_b[0], 9, "bold"),
                         text_color=self.GREEN).pack(pady=(2, 5))

            # ---- controls ----
            ctl = ctk.CTkFrame(self, fg_color="transparent")
            ctl.pack(pady=(3, 1))
            ctk.CTkButton(ctl, text="LAUNCH CONVERTER »", width=250, height=38,
                          font=(mono_b[0], 13, "bold"),
                          fg_color="#C2410C", hover_color="#9A3412",
                          text_color="#FFFFFF",
                          command=self._launch).pack()

            ctk.CTkLabel(
                self,
                text=f"v{APP_VERSION}  ·  GDS Black Window spec  ·  offline"
                     f" + optional AI (Gemini/Groq/OpenRouter/Claude/GPT)",
                font=(mono[0], 8), text_color="#6B7280").pack(side="bottom",
                                                              pady=4)

        def _launch(self):
            if self.startup:
                self.app.deiconify()
                self.app.lift()
                self.app.after(150, self.app._apply_icon)
                try:
                    self.app.focus_force()
                except Exception:
                    pass
            self.destroy()

    # -------------------------------------------------------------
    class BugReportDialog(ctk.CTkToplevel):
        """Smart bug report — the old raw mailto: silently failed on any PC
        without a configured mail client ('it just opens the browser and
        does nothing'). This dialog:
          * assembles FULL diagnostics (version / engine / recent errors /
            exact input+output — no API keys, ever),
          * COPIES them to the clipboard the moment it opens,
          * sends you to Gmail / Outlook / mail-app with a SHORT Url that
            always survives Windows' URL-length limits; the draft tells
            you to press CTRL+V (the complete report rides along)."""

        TO = "Lamar@bcflights.com"

        def __init__(self, app):
            super().__init__(app)
            self.app = app
            self.title("Report a bug — SpicyTerminal")
            self.geometry("640x660")
            self.resizable(False, False)
            self.transient(app)
            self.grab_set()
            _raise_dialog(self)
            self.after(200, lambda self=self: _safe_iconbitmap_cb(self))

            self.report = build_bug_report(
                app.cfg, app.get_input(),
                app.output_box.get("1.0", "end-1c"),
                getattr(app, "_hist", []),
                provider_state=app.engine_lbl.cget("text"))
            try:                                # safety net: copy NOW
                app.clipboard_clear()
                app.clipboard_append(self.report)
            except Exception:
                pass

            head = ctk.CTkFrame(self, fg_color="transparent")
            head.pack(fill="x", padx=16, pady=(12, 4))
            try:
                im = Image.open(BUG_ICON_PATH)
                ci = ctk.CTkImage(light_image=im, dark_image=im, size=(30, 30))
                ctk.CTkLabel(head, image=ci, text="").pack(side="left",
                                                           padx=(2, 10))
            except Exception:
                pass
            ctk.CTkLabel(head, text="SMART BUG REPORT",
                         font=(app.mono_b[0], 15, "bold"),
                         text_color="#FF7A1A").pack(side="left")
            ctk.CTkLabel(
                self, text="Full report copied to your clipboard ✓\n"
                "Choose how to send it — the draft tells you to press "
                "CTRL+V.",
                font=app.ui_s, text_color="#9CA3AF", justify="left",
            ).pack(anchor="w", padx=16)

            box = ctk.CTkTextbox(self, font=(app.mono[0], 11),
                                 fg_color="#0B0F0C", text_color="#D1D5DB",
                                 wrap="word", height=320)
            box.pack(fill="both", expand=True, padx=16, pady=8)
            box.insert("1.0", self.report)
            box.configure(state="disabled")

            r1 = ctk.CTkFrame(self, fg_color="transparent")
            r1.pack(pady=(2, 2))
            for label, kind, col in (("GMAIL", "gmail", "#B45309"),
                                     ("OUTLOOK", "outlook", "#1F6AA5"),
                                     ("MAIL APP", "mail", "#4B5563")):
                ctk.CTkButton(r1, text="✉ " + label, width=150, height=38,
                              fg_color=col,
                              hover_color={"#B45309": "#8C4207",
                                           "#1F6AA5": "#175A8C",
                                           "#4B5563": "#374151"}[col],
                              command=lambda k=kind: self._open(k),
                              ).pack(side="left", padx=5)

            r2 = ctk.CTkFrame(self, fg_color="transparent")
            r2.pack(pady=(2, 12))
            ctk.CTkButton(r2, text="📋 COPY AGAIN", width=150,
                          fg_color="#374151", hover_color="#4B5563",
                          command=self._copy).pack(side="left", padx=5)
            ctk.CTkButton(r2, text="SAVE .TXT", width=150,
                          fg_color="#374151", hover_color="#4B5563",
                          command=self._save).pack(side="left", padx=5)
            ctk.CTkButton(r2, text="CLOSE", width=150,
                          fg_color="#6B7280", command=self.destroy,
                          ).pack(side="left", padx=5)

        def _copy(self):
            try:
                self.app.clipboard_clear()
                self.app.clipboard_append(self.report)
                self.app.set_status("Bug report copied ✓ — paste it into "
                                    f"any email to {self.TO}")
            except Exception as e:
                self.app.set_status(f"Copy failed: {e}", warn=True)

        def _save(self):
            p = filedialog.asksaveasfilename(
                defaultextension=".txt",
                filetypes=[("Text files", "*.txt")],
                initialfile="spicyterminal_bug_report.txt")
            if p:
                try:
                    Path(p).write_text(self.report, encoding="utf-8")
                    self.app.set_status(
                        f"Bug report saved: {p} — attach it to an email "
                        f"to {self.TO}")
                except Exception as e:
                    self.app.set_status(f"Save failed: {e}", warn=True)

        def _open(self, kind):
            import webbrowser
            from urllib.parse import quote
            subject = f"SpicyTerminal v{APP_VERSION} bug report"
            head = "\n".join(self.report.splitlines()[:8])
            body = (">>> THE FULL REPORT IS ON MY CLIPBOARD — "
                    "I PRESS CTRL+V HERE <<<\n\n" + head + "\n…")
            if kind == "gmail":
                url = ("https://mail.google.com/mail/?view=cm&fs=1"
                       f"&to={quote(self.TO)}&su={quote(subject)}"
                       f"&body={quote(body)}")
            elif kind == "outlook":
                url = ("https://outlook.live.com/mail/0/deeplink/compose"
                       f"?to={quote(self.TO)}&subject={quote(subject)}"
                       f"&body={quote(body)}")
            else:
                url = (f"mailto:{quote(self.TO)}?subject={quote(subject)}"
                       f"&body={quote(body)}")
            try:
                webbrowser.open(url)
                self.app.set_status(
                    f"Opening {kind.title()} — press CTRL+V in the message "
                    "body, then SEND. Thank you!")
                self.app._hist.append(f"BUG REPORT sent via {kind}")
            except Exception as e:
                self.app.set_status(
                    f"Could not open {kind}: {e} — report is on your "
                    f"clipboard; email it to {self.TO}", warn=True)

    # -------------------------------------------------------------
    class App(ctk.CTk):
        def __init__(self):
            super().__init__()
            self.cfg = load_config()
            self.images = []            # list of {"bytes": b, "ctk": CTkImage}
            self.busy = False
            self._busy_since = None
            self._ai_gen = 0
            self._fallback_offline = None  # (out, warns) kept while AI fills gaps (v3.1)
            self.after(2000, self._ai_watchdog)
            self._last_converted = ""   # input text of the last successful run
            self._leftover = False      # new convert started on top of old text
            self._hist = []             # recent status lines (bug reports)

            self.title(WINDOW_TITLE)
            self.geometry("1280x820")
            self.minsize(980, 640)
            self._apply_icon()
            self.after(300, self._apply_icon)

        def _apply_icon(self):
            """Flame-S icon on the window/tab and taskbar; 'default' makes it
            inherit onto all future dialogs. Re-applied after the welcome
            screen deiconifies the window (some Windows builds recreate the
            HWND and drop it)."""
            try:
                self.iconbitmap(bitmap=ICON_PATH, default=ICON_PATH)
            except Exception:
                pass
            try:
                from PIL import ImageTk
                self._icon_photo = ImageTk.PhotoImage(
                    Image.open(LOGO_MARK_PATH))
                self.iconphoto(True, self._icon_photo)
            except Exception:
                pass

            mono = self._pick_mono()
            self.mono = (mono, 13)
            self.mono_b = (mono, 13, "bold")
            ui = self._pick_ui()
            self.ui = (ui, 12)
            self.ui_b = (ui, 12, "bold")
            self.ui_s = (ui, 11)

            self.grid_columnconfigure(0, weight=2, uniform="cols")
            self.grid_columnconfigure(1, weight=3, uniform="cols")
            self.grid_rowconfigure(1, weight=1)

            self._build_header()
            self._build_left()
            self._build_right()
            self._build_status()

            self.input_box._textbox.bind("<Control-v>", self.on_paste)
            self.bind_all("<Control-v>", self.on_paste_root)

            self.after(4000, self._silent_update_check)

        # ---------- layout ----------
        def _pick_mono(self):
            try:
                fams = set(tkfont.families(self))
                for f in ("Consolas", "JetBrains Mono", "Courier New",
                          "Menlo", "DejaVu Sans Mono"):
                    if f in fams:
                        return f
            except Exception:
                pass
            return "Courier New"

        def _pick_ui(self):
            try:
                fams = set(tkfont.families(self))
                for f in ("Segoe UI", "Inter", "Helvetica Neue", "Arial",
                          "DejaVu Sans", "Liberation Sans"):
                    if f in fams:
                        return f
            except Exception:
                pass
            return "Arial"

        def _build_header(self):
            bar = ctk.CTkFrame(self, fg_color="#0B0F0C", corner_radius=0,
                               height=50)
            bar.grid(row=0, column=0, columnspan=2, sticky="ew")
            ctk.CTkLabel(
                bar, text="▮ " + BRAND,
                font=(self.mono_b[0], 16, "bold"),
                text_color="#FF7A1A").pack(side="left", padx=(16, 2))
            ctk.CTkLabel(
                bar, text=f"v{APP_VERSION}", font=(self.ui[0], 10),
                text_color="#4B5563").pack(side="left", padx=(0, 12), pady=(4, 0))
            self.engine_lbl = ctk.CTkLabel(
                bar, text="", font=self.ui_s, text_color="#6B7280")
            self.engine_lbl.pack(side="right", padx=(4, 10))

            def hbtn(txt, cmd, color, hover, tip, img_path=None):
                image = None
                if img_path:
                    try:
                        im = Image.open(img_path)
                        image = ctk.CTkImage(light_image=im, dark_image=im,
                                             size=(20, 20))
                    except Exception:
                        image = None
                b = ctk.CTkButton(
                    bar, text="" if image else txt, image=image,
                    width=40, height=34, corner_radius=9,
                    fg_color=color, hover_color=hover,
                    font=(self.ui_b[0], 14, "bold"), command=cmd)
                b.pack(side="right", padx=4, pady=8)
                _ToolTip(b, tip)
                return b

            hbtn("⚙", lambda: SettingsDialog(self), "#374151", "#4B5563",
                 "Settings — engine, mode, API key, updates")
            hbtn("!", self.report_bug, "#7F1D1D", "#991B1B",
                 "Report a bug — smart report to Lamar@bcflights.com",
                 img_path=BUG_ICON_PATH)
            hbtn("?", lambda: WelcomeScreen(self, modal=True, startup=False),
                 "#7C2D12", "#9A3412", "Welcome & intro")
            self.refresh_engine_label()

        def _build_left(self):
            left = ctk.CTkFrame(self, fg_color="#101512")
            left.grid(row=1, column=0, sticky="nsew", padx=(10, 5), pady=8)
            left.grid_rowconfigure(1, weight=1)
            left.grid_columnconfigure(0, weight=1)

            ctk.CTkLabel(left, text="INPUT", font=(self.ui_b[0], 11, "bold"),
                         text_color="#6B7280").grid(
                row=0, column=0, sticky="w", padx=12, pady=(10, 2))

            self.input_box = ctk.CTkTextbox(
                left, font=self.mono, fg_color="#1A1F1B", text_color="#E5E7EB",
                border_color="#2E3A30", border_width=1, wrap="word")
            self.input_box.grid(row=1, column=0, sticky="nsew", padx=10, pady=6)

            self._ph_text = ("Paste flights, email text or a screenshot "
                             "(Ctrl+V)")
            self._ph_on = False
            self.input_box.bind("<FocusIn>", self._ph_hide, add="+")
            self.input_box.bind("<KeyPress>", self._ph_hide, add="+")
            self.input_box.bind("<FocusOut>", self._ph_show, add="+")
            self._ph_show()

            self.thumb_frame = ctk.CTkFrame(left, fg_color="#0B0F0C", height=96)
            self.thumb_frame.grid(row=2, column=0, sticky="ew", padx=10,
                                  pady=(0, 6))

            btns = ctk.CTkFrame(left, fg_color="transparent")
            btns.grid(row=3, column=0, sticky="ew", padx=10, pady=(0, 10))
            btns.grid_columnconfigure((0, 1), weight=1)

            def abtn(txt, cmd, color, hover, font, h, tip, row, col):
                b = ctk.CTkButton(
                    btns, text=txt, height=h, corner_radius=9, font=font,
                    fg_color=color, hover_color=hover, command=cmd)
                b.grid(row=row, column=col, sticky="ew",
                       padx=(0, 4) if col == 0 else (4, 0), pady=4)
                _ToolTip(b, tip)
                return b

            self.btn_convert = abtn(
                "▶  CONVERT", lambda: self.convert(force_ai=False),
                "#0E7C3A", "#0A5E2C", (self.ui_b[0], 13, "bold"), 44,
                "Convert offline — instant, private", 0, 0)
            self.btn_ai = abtn(
                "✦  AI", lambda: self.convert(force_ai=True),
                "#B45309", "#8C4207", (self.ui_b[0], 13, "bold"), 44,
                "Convert with AI — handles messy text & screenshots", 0, 1)
            abtn("+", self.add_screenshot, "#374151", "#4B5563",
                 (self.ui_b[0], 13, "bold"), 34,
                 "Attach screenshot(s) — or press Ctrl+V", 1, 0)
            abtn("✕", self.clear_all, "#374151", "#4B5563",
                 (self.ui_b[0], 13, "bold"), 34,
                 "Clear input & output", 1, 1)

        # ---------- input placeholder ----------
        def _ph_show(self, *_):
            if self._ph_on or self.input_box.get("1.0", "end-1c").strip():
                return
            self._ph_on = True
            self.input_box.configure(text_color="#6B7280")
            self.input_box.insert("1.0", self._ph_text)

        def _ph_hide(self, *_):
            if self._ph_on:
                self._ph_on = False
                self.input_box.delete("1.0", "end")
                self.input_box.configure(text_color="#E5E7EB")

        def _ph_reset(self):
            self._ph_on = False
            self.input_box.configure(text_color="#E5E7EB")
            self._ph_show()

        def _build_right(self):
            right = ctk.CTkFrame(self, fg_color="#050705")
            right.grid(row=1, column=1, sticky="nsew", padx=(5, 10), pady=8)
            right.grid_rowconfigure(1, weight=1)
            right.grid_columnconfigure(0, weight=1)

            top = ctk.CTkFrame(right, fg_color="transparent")
            top.grid(row=0, column=0, sticky="ew", padx=8, pady=(8, 2))
            ctk.CTkLabel(top, text="OUTPUT", font=(self.ui_b[0], 11, "bold"),
                         text_color="#33FF66").pack(side="left", padx=6,
                                                   pady=(0, 1))

            def obtn(txt, cmd, tip):
                b = ctk.CTkButton(top, text=txt, width=64, height=26,
                                  corner_radius=8, font=self.ui_s,
                                  fg_color="#1F6AA5", hover_color="#175A8C",
                                  command=cmd)
                b.pack(side="right", padx=3)
                _ToolTip(b, tip)
                return b

            obtn("COPY", self.copy_output, "Copy output to clipboard")
            obtn("SAVE", self.save_output, "Save output as .txt file")

            self.output_box = ctk.CTkTextbox(
                right, font=(self.mono[0], 14), fg_color="#000000",
                text_color="#33FF66", border_color="#173A20", border_width=2,
                wrap="none")
            self.output_box.grid(row=1, column=0, sticky="nsew", padx=8,
                                 pady=(2, 8))
            self.output_box._textbox.bind(
                "<Control-a>", lambda e: (self.output_box._textbox.tag_add(
                    "sel", "1.0", "end-1c"), "break")[1])

        def _build_status(self):
            bar = ctk.CTkFrame(self, fg_color="#0B0F0C", corner_radius=0, height=30)
            bar.grid(row=2, column=0, columnspan=2, sticky="ew")
            self.status_lbl = ctk.CTkLabel(
                bar, text="READY", font=self.ui_s,
                text_color="#6B7280", anchor="w")
            self.status_lbl.pack(side="left", padx=12, fill="x", expand=True)

        # ---------- helpers ----------
        def refresh_engine_label(self):
            prov = ai_engine.PROVIDERS.get(self.cfg["provider"],
                                           ai_engine.PROVIDERS["Google Gemini (FREE)"])
            has_key = bool(_explicit_key(self.cfg)) or \
                ai_engine.has_default_key(prov["id"])
            short = {"anthropic": "CLAUDE", "openai": "GPT",
                     "gemini": "GEMINI", "groq": "GROQ",
                     "openrouter": "OPENRTR"}.get(prov["id"],
                                                  prov["id"].upper())
            mode = self.cfg.get("mode", "Auto").upper()
            if mode == "OFFLINE":
                txt, color = "OFFLINE", "#6B7280"
            else:
                txt = f"{short} {'✓' if has_key else '— NO KEY'}"
                color = "#34D399" if has_key else "#F59E0B"
                if mode == "AI":
                    txt = "AI · " + txt
            self.engine_lbl.configure(text=txt, text_color=color)

        # ---------- updates ----------
        def _silent_update_check(self):
            url = self.cfg.get("update_url") or None

            def work():
                try:
                    import updater
                    res = updater.check(APP_VERSION, url=url)
                except Exception as e:
                    res = {"status": "unavailable", "error": str(e),
                           "manifest": None}
                self.after(0, lambda: self._update_checked(res))

            threading.Thread(target=work, daemon=True).start()

        def _update_checked(self, res):
            if res.get("status") == "newer":
                man = res.get("manifest") or {}
                self.set_status(
                    f"⇩ Update v{man.get('version')} available — "
                    "⚙ Settings → CHECK FOR UPDATES", warn=True)

        def report_bug(self):
            """Smart bug report: the old mailto: silently died on PCs with
            no mail client (Windows opens the browser, nothing happens).
            Now a dialog assembles the FULL diagnostics, copies them to the
            clipboard, and offers Gmail/Outlook/mail-app buttons that are
            guaranteed to contain the report (short URL + clipboard)."""
            BugReportDialog(self)

        def set_status(self, msg, warn=False):
            self.status_lbl.configure(
                text=msg, text_color="#F59E0B" if warn else "#9CA3AF")
            if msg and msg != "READY":
                self._hist.append(msg)
                del self._hist[:-8]

        def set_busy(self, busy, note=""):
            self.busy = busy
            self._busy_since = time.monotonic() if busy else None
            state = "disabled" if busy else "normal"
            self.btn_convert.configure(state=state)
            self.btn_ai.configure(state=state)
            if busy:
                self.set_status(note or "WORKING...")

        def _ai_watchdog(self):
            """A stuck AI call (blocked office network, hung TLS...) left the
            CONVERT button dead for minutes and every click did NOTHING
            (reported by the office, v2.9). If any busy state outlives
            WATCHDOG_SEC, force the buttons live again with a clear status.
            The late worker thread is ignored via the generation counter."""
            try:
                if (self.busy and self._busy_since and
                        time.monotonic() - self._busy_since > 240):
                    self._ai_gen += 1  # stale the stuck worker's result
                    self.set_busy(False)
                    self.set_status(
                        "AI stopped after 4 min - buttons are live again. "
                        "Press CONVERT (offline needs no internet) or try "
                        "AI once more.", warn=True)
            except Exception:
                pass
            self.after(2000, self._ai_watchdog)

        # ---------- images ----------
        def attach_image(self, pil_img):
            if len(self.images) >= int(self.cfg.get("max_images", 10)):
                self.set_status("Image limit reached.", warn=True)
                return
            data = prepare_image_bytes(pil_img)
            thumb = pil_img.convert("RGB")
            thumb.thumbnail((150, 76))
            entry = {"bytes": data, "idx": len(self.images)}
            cell = ctk.CTkFrame(self.thumb_frame, fg_color="#1F2937")
            cell.pack(side="left", padx=5, pady=6)
            ci = ctk.CTkImage(light_image=thumb, dark_image=thumb,
                              size=thumb.size)
            entry["ctk"] = ci
            lbl = ctk.CTkLabel(cell, image=ci, text="")
            lbl.pack(side="left", padx=(6, 2), pady=4)
            ctk.CTkButton(cell, text="X", width=24, height=24, font=self.mono,
                          fg_color="#7F1D1D", hover_color="#991B1B",
                          command=lambda c=cell, e=entry: self.remove_image(c, e)
                          ).pack(side="left", padx=(0, 6))
            self.images.append(entry)
            self.set_status(f"{len(self.images)} screenshot(s) attached.")

        def remove_image(self, cell, entry):
            cell.destroy()
            if entry in self.images:
                self.images.remove(entry)
            self.set_status(f"{len(self.images)} screenshot(s) attached.")

        def add_screenshot(self):
            paths = filedialog.askopenfilenames(
                title="Select Google Flights / itinerary screenshots",
                filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp"),
                           ("All files", "*.*")])
            for p in paths:
                try:
                    self.attach_image(Image.open(p))
                except Exception as e:
                    self.set_status(f"Could not open {p}: {e}", warn=True)

        def on_paste(self, event=None):
            self._ph_hide()
            if ImageGrab is None:
                return None
            try:
                clip = ImageGrab.grabclipboard()
            except Exception:
                return None
            if clip is None or isinstance(clip, str):
                return None
            if isinstance(clip, list):
                for p in clip:
                    try:
                        self.attach_image(Image.open(p))
                    except Exception:
                        pass
                return "break"
            self.attach_image(clip)
            return "break"

        def on_paste_root(self, event=None):
            try:
                focused = self.focus_get()
            except Exception:
                focused = None
            if focused is self.input_box._textbox:
                return None          # handled by the widget binding
            return self.on_paste(event)

        # ---------- conversion ----------
        def get_input(self):
            if self._ph_on:
                return ""
            return self.input_box.get("1.0", "end-1c")

        def convert(self, force_ai=False):
            if self.busy:
                self.set_status(
                    "Still converting - please wait a few seconds "
                    "(auto-resets after 4 min max).", warn=True)
                return
            text = self.get_input()
            imgs = [e["bytes"] for e in self.images]
            if not text.strip() and not imgs:
                self.set_status("Paste flights or a screenshot first.",
                                warn=True)
                return
            self._fallback_offline = None  # fresh convert: drop any stale keepsake

            # leftover-text guard: converting on top of previously converted
            # text is how "extra legs keep adding" happens
            prior = self._last_converted.strip()
            self._leftover = bool(prior) and prior != text.strip() \
                and prior in text.strip()

            mode = self.cfg.get("mode", "Auto")
            use_ai = force_ai or mode == "AI"

            # a screenshot is attached — the offline engine can't see it, so
            # go straight to a vision AI (failover keeps it reliable)
            if (imgs and not use_ai and mode == "Auto"
                    and self.cfg.get("ai_fallback", True)
                    and get_api_key(self.cfg)):
                text2, imgs2 = self._ai_prep(text, imgs)
                if imgs2:
                    self.set_status(
                        "Screenshot attached — sending to ✦ AI so it's read…")
                    self.run_ai(text2, imgs2, fallback=True)
                    return

            if not use_ai:
                self._run_offline(text, imgs, mode)
                return

            if not get_api_key(self.cfg) and mode != "Offline":
                self.set_status("No AI API key — open ⚙ settings.", warn=True)
                messagebox.showinfo(
                    "API key required",
                    "AI conversion (and screenshots) need an API key.\n"
                    "Open ⚙ settings / API KEY — Gemini, Groq and "
                    "OpenRouter all offer FREE keys, no credit card needed.")
                return
            text, imgs = self._ai_prep(text, imgs)
            self.run_ai(text, imgs)

        def _run_offline(self, text, imgs, mode):
            """Offline parse in a worker thread (v3.0 freeze fix).

            The parser used to run inside the click handler on the UI
            thread: big full-page Google pastes made it chew for seconds,
            the window stopped repainting and CONVERT felt completely dead
            (the office's exact report: 'freezes unless I click ✦ AI').
            Two compounding causes were fixed: (1) the parser re-compiled
            ~1,100 city-regexes per block scan — now ONE precompiled
            alternation, 8.6s -> 0.1s on 300 cards; (2) this worker
            thread, so even a pathological paste can never wedge the UI
            again. A 30s fuse revives the buttons if parsing ever hangs.
            """
            self._ai_gen += 1
            gen = self._ai_gen
            self.set_busy(True, "CONVERTING OFFLINE…")
            self.update_idletasks()  # paint the status before the thread starts

            def work():
                out, warns, err = None, None, None
                try:
                    out, warns = convert_offline(text)
                except Exception as e:  # parser must never take the UI down
                    err = str(e)
                self.after(0, lambda: self._offline_done(
                    out, warns, err, text, imgs, mode, gen))

            threading.Thread(target=work, daemon=True).start()
            self.after(1000, lambda: self._off_watchdog(gen))

        def _off_watchdog(self, gen):
            """30s fuse for the offline worker (independent of the generic
            4-minute AI watchdog): parsing takes milliseconds, so outliving
            this means something is deeply wrong — revive the UI and say so."""
            if not (self.busy and gen == self._ai_gen):
                return  # worker finished and delivered its result
            if time.monotonic() - self._busy_since > 30:
                self._ai_gen += 1    # stale the hung worker's late result
                self.set_busy(False)
                self.set_status(
                    "Offline engine took too long on this text — press "
                    "✦ AI now, or REPORT BUG and include the input.",
                    warn=True)
                return
            self.after(1000, lambda: self._off_watchdog(gen))

        def _offline_done(self, out, warns, err, text, imgs, mode, gen):
            """Back on the UI thread with the worker's parse result — the
            flow below is exactly the old inline offline logic."""
            if gen != self._ai_gen:
                return  # stale worker (watchdog already revived the buttons)
            if err:
                out = None
                warns = (warns or []) + [f"offline engine error: {err[:100]}"]
            self.set_busy(False)
            if out is not None:
                incomplete = output_incomplete(out, warns)
                if (incomplete and mode == "Auto"
                        and self.cfg.get("ai_fallback", True)
                        and get_api_key(self.cfg)):
                    # v3.1: SHOW the offline result while AI fills the
                    # gaps. Leaving OUTPUT empty for a minute reads as
                    # 'offline never ran' (office report: 'does not even
                    # try to convert offline first'). If AI fails,
                    # _ai_done restores this instead of leaving nothing.
                    self.show_output(
                        out, source="OFFLINE ENGINE (partial — AI "
                                    "finishing…)", warns=warns)
                    self._fallback_offline = (out, warns)
                    self.set_status("Offline converted what it could — "
                                    "✦ AI is filling the missing pieces…")
                    text, imgs = self._ai_prep(text, imgs)
                    self.run_ai(text, imgs, fallback=True)
                    return
                self.show_output(out, source="OFFLINE ENGINE",
                                 warns=warns)
                self._convert_success(text)
                if incomplete:
                    self.set_status(
                        "⚠ Some flight data never reached the app (a "
                        "leg's route line 'X (AAA) to Y (BBB)' is missing "
                        "from the copy) — expand the flight card, re-copy, "
                        "or press ✦ AI to finish it.", warn=True)
                return
            if mode == "Offline":
                self.show_output("", source="", warns=warns)
                self.set_status("Offline parser found no flights — try ✦ AI."
                                + (" (screenshots ignored in Offline mode)"
                                   if imgs else ""), warn=True)
                return
            # Auto mode -> fallback
            if not imgs and not self.cfg.get("ai_fallback", True):
                self.set_status("Offline found nothing. "
                                "AI fallback disabled in Settings.", warn=True)
                return
            if not get_api_key(self.cfg):
                self.set_status("Offline found nothing and no AI key — open ⚙ settings.", warn=True)
                return
            text, imgs = self._ai_prep(text, imgs)
            self.run_ai(text, imgs, fallback=True)

        def _ai_prep(self, text, imgs):
            """Strip screenshots when the selected provider is text-only."""
            prov_id = ai_engine.PROVIDERS[self.cfg["provider"]]["id"]
            if imgs and not ai_engine.supports_vision(prov_id):
                self.set_status(
                    f"{self.cfg['provider']} is text-only — screenshots "
                    "ignored. Pick Google Gemini (FREE) in Settings for "
                    "vision.", warn=True)
                return text, []
            return text, imgs

        def run_ai(self, text, imgs, fallback=False):
            short = self.cfg["provider"].split("(")[0].strip().title()
            self._pending_text = text
            # AUTO fallbacks fail fast (60s) so a blocked network can never
            # freeze CONVERT for minutes; the explicit AI button keeps 180s.
            tmo = 60 if fallback else int(self.cfg.get("ai_timeout", 180))
            self._ai_gen += 1
            gen = self._ai_gen
            self.set_busy(True, f"AI ({short}) converting — please wait...")
            cfg_snapshot = dict(self.cfg)

            def work():
                err = None
                out = None
                try:
                    out = convert_ai(
                        text, imgs, cfg_snapshot,
                        on_status=lambda m: self.after(
                            0, lambda m=m: self.set_status(m)),
                        timeout_s=tmo)
                except Exception as e:
                    err = str(e)
                self.after(
                    0, lambda: self._ai_done(out, err, short, fallback, gen))

            threading.Thread(target=work, daemon=True).start()

        def _ai_done(self, out, err, short, fallback, gen=None):
            if gen is not None and gen != self._ai_gen:
                return  # stale worker (watchdog already revived the buttons)
            self.set_busy(False)
            if err:
                # v3.1: an offline partial was kept visible while AI ran —
                # restore it so the agent NEVER ends up with an empty box.
                if self._fallback_offline:
                    out_fb, warns_fb = self._fallback_offline
                    self._fallback_offline = None
                    self.show_output(out_fb, source="OFFLINE ENGINE",
                                     warns=warns_fb)
                    self.set_status(
                        "AI unavailable — OFFLINE result kept above; fix "
                        "the input text or press ✦ AI to try once more.",
                        warn=True)
                    messagebox.showwarning(
                        "AI failed — offline result kept",
                        f"{err}\n\nThe offline result stays in the OUTPUT "
                        "box. Fix the input text or press ✦ AI again.")
                    return
                self.set_status(f"AI ERROR: {err[:180]}", warn=True)
                messagebox.showerror(
                    "AI conversion failed",
                    f"{err}\n\n" + (friendly_ai_error(err) or
                    "Copy the FULL error text above and send it for support."))
                return
            self._fallback_offline = None  # AI delivered — nothing to restore
            actual, note = short.upper(), ""
            prov = getattr(out, "provider", None)
            if prov:
                amap = {"anthropic": "CLAUDE", "openai": "GPT",
                        "gemini": "GEMINI", "groq": "GROQ",
                        "openrouter": "OPENRTR"}
                actual = amap.get(prov, prov.upper())
                fo = getattr(out, "failover_from", None)
                if fo:
                    tried = "/".join(amap.get(p, p.upper()) for p in fo)
                    note = f" · {tried} down/busy → auto-switched ✓"
            src = f"AI ({actual})" + (" [fallback]" if fallback else "")
            self.show_output(out, source=src, warns=[])
            if note:
                self.set_status(self.status_lbl.cget("text") + note)
            self._convert_success(getattr(self, "_pending_text", ""))

        def show_output(self, out, source, warns):
            self.output_box.delete("1.0", "end")
            self.output_box.insert("1.0", out)
            parts = []
            if source:
                parts.append(source)
            segs = out.count("\nCABIN-")
            if segs:
                parts.append(f"{segs} segment(s)")
            if out.strip():
                parts.append("click COPY to copy")
            if warns:
                parts.append("⚠ " + " | ".join(warns[:3])[:120])
            self.set_status(" · ".join(parts) if parts else "READY",
                            warn=bool(warns))

        def _convert_success(self, text):
            self._last_converted = text
            if self._leftover:
                self._leftover = False
                self.set_status(
                    "⚠ Extra legs? Input still contains text you already "
                    "converted — press ✕ before pasting a new trip.",
                    warn=True)

        def copy_output(self, silent=False):
            text = self.output_box.get("1.0", "end-1c")
            try:
                self.clipboard_clear()
                self.clipboard_append(text)
                if not silent:
                    self.set_status("Output copied to clipboard ✓")
            except Exception as e:
                if not silent:
                    self.set_status(f"Copy failed: {e}", warn=True)

        def save_output(self):
            text = self.output_box.get("1.0", "end-1c")
            if not text.strip():
                self.set_status("Nothing to save.", warn=True)
                return
            p = filedialog.asksaveasfilename(
                defaultextension=".txt",
                filetypes=[("Text files", "*.txt")],
                initialfile="gds_itinerary.txt")
            if p:
                try:
                    Path(p).write_text(text, encoding="utf-8")
                    self.set_status(f"Saved: {p}")
                except Exception as e:
                    self.set_status(f"Save failed: {e}", warn=True)

        def clear_all(self):
            self.input_box.delete("1.0", "end")
            self.output_box.delete("1.0", "end")
            for w in list(self.thumb_frame.winfo_children()):
                w.destroy()
            self.images.clear()
            self._last_converted = ""
            self._leftover = False
            self._ph_reset()
            self.set_status("READY")

    app = App()
    app.withdraw()  # welcome screen is mandatory at every launch
    WelcomeScreen(app, modal=False, startup=True)
    app.mainloop()


# =====================================================================
def _raise_dialog(win):
    """Dialogs with grab_set() must be forced ABOVE the main window, or a
    hidden modal silently swallows every main-window click and the whole app
    looks dead (office report, v2.9)."""
    try:
        win.lift()
        win.attributes("-topmost", True)
        win.after(350, lambda: win.attributes("-topmost", False))
        win.focus_force()
    except Exception:
        pass


def _safe_iconbitmap_cb(win):
    """iconbitmap throws on X11/macOS with .ico files; never let the deferred
    callback print a traceback (found by the mac run, v2.8)."""
    try:
        win.iconbitmap(ICON_PATH)
    except Exception:
        pass


def main():
    ap = argparse.ArgumentParser(description=APP_TITLE)
    ap.add_argument("--cli", action="store_true", help="run in console mode")
    ap.add_argument("--ai", action="store_true", help="force AI in CLI mode")
    ap.add_argument("--text", default="", help="input text (CLI)")
    ap.add_argument("--file", default="", help="input file (CLI)")
    ap.add_argument("--warnings", action="store_true", help="print parser warnings")
    args = ap.parse_args()

    if args.cli:
        sys.exit(run_cli(args))
    run_gui()


if __name__ == "__main__":
    main()
