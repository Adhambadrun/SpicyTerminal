"""
formatter.py — Renders FlightSegment objects into the GDS Black Window
itinerary format defined by the master system prompt.
"""

from dataclasses import dataclass, field
from typing import List

from aviation_data import AIRPORTS

MONTHS = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN",
          "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"]

CABIN_DEFAULT_CLASS = {
    "FIRST": "F",
    "BUSINESS": "C",
    "PREMIUM ECONOMY": "W",
    "ECONOMY": "Y",
}

# Letter -> cabin heuristic, used only when no cabin word is present
CLASS_TO_CABIN = {
    "F": "FIRST", "A": "FIRST", "P": "FIRST", "R": "FIRST",
    "J": "BUSINESS", "C": "BUSINESS", "D": "BUSINESS", "I": "BUSINESS",
    "Z": "BUSINESS", "O": "BUSINESS",
    "W": "PREMIUM ECONOMY", "S": "PREMIUM ECONOMY",
}


@dataclass
class FlightSegment:
    seg: int = 0
    airline: str = ""            # 2-letter IATA marketing code
    flight_no: str = ""          # numeric string
    date_ddmmm: str = ""         # e.g. 15JAN
    orig: str = ""               # 3-letter IATA
    dest: str = ""
    dep_time: str = ""           # e.g. 930P
    arr_time: str = ""           # e.g. 520P (marker added separately)
    arr_day_shift: int = 0       # 0,1,2,3 -> ¥N on arrival
    booking_class: str = ""      # single letter
    aircraft: str = "???"        # IATA type designator
    flight_time: str = ""        # H.MM
    distance: str = ""           # statute miles, whole number
    cabin: str = "ECONOMY"       # FIRST / BUSINESS / PREMIUM ECONOMY / ECONOMY
    warnings: List[str] = field(default_factory=list)
    hidden_stops: tuple = ()     # airport codes of merged hidden stops (v3.2)


def fmt_clock(hh24: int, mm: int) -> str:
    """24h hh/mm -> e.g. 930P, 1255A, 1200P, 100A."""
    suffix = "A" if hh24 < 12 else "P"
    h12 = hh24 % 12
    if h12 == 0:
        h12 = 12
    return f"{h12}{mm:02d}{suffix}"


def make_date(day: int, month: int) -> str:
    return f"{day:02d}{MONTHS[month - 1]}"


def airport_name(code: str, terminal: str = "") -> str:
    ap = AIRPORTS.get(code)
    name = ap["name"] if ap else (code if code else "???")
    if terminal:
        name = f"{name} T{terminal}"
    return name


def render_segment(seg: FlightSegment) -> str:
    """One segment = flight line + DEP + ARR + CABIN (4 lines)."""
    cls = (seg.booking_class or CABIN_DEFAULT_CLASS.get(seg.cabin, "Y")).upper()
    arr = seg.arr_time
    if seg.arr_day_shift >= 1:
        arr = f"{arr}\u00a5{seg.arr_day_shift}"
    line1 = " ".join([
        str(seg.seg), seg.airline, seg.flight_no, seg.date_ddmmm,
        seg.orig, seg.dest, seg.dep_time, arr, cls,
        seg.aircraft or "???", seg.flight_time or "0.00",
        str(seg.distance) if seg.distance else "0", "N",
    ])
    lines = [
        line1,
        *[f"STOP-{c}" for c in seg.hidden_stops],
        f"DEP-{airport_name(seg.orig)}",
        f"ARR-{airport_name(seg.dest)}",
        f"CABIN-{seg.cabin}",
    ]
    return "\n".join(lines)


def render_additional(segments: List[FlightSegment]) -> List[str]:
    out = ["<--additional-->"]
    for s in segments:
        cls = (s.booking_class or CABIN_DEFAULT_CLASS.get(s.cabin, "Y")).upper()
        out.append(f"{s.seg} {s.airline} {s.flight_no}{cls} {s.date_ddmmm}")
    return out


def render_itinerary(segments: List[FlightSegment]) -> str:
    """Full itinerary: all segments + additional section. No fences."""
    blocks = [render_segment(s) for s in segments]
    body = "\n\n".join(blocks)
    additional = "\n".join(render_additional(segments))
    return f"{body}\n\n{additional}"


def qc_check(text: str, segments: List[FlightSegment]) -> List[str]:
    """Silent-QC -> returns a list of violation messages (for the status bar)."""
    issues = []
    lines = text.split("\n")
    if not segments:
        issues.append("no segments parsed")
        return issues
    for i, s in enumerate(segments, 1):
        if s.seg != i:
            issues.append(f"segment {i} numbering broken")
    flight_lines = [l for l in lines if l.rstrip().endswith(" N")]
    for fl in flight_lines:
        parts = fl.split(" ")
        if len(parts) != 13:
            issues.append(f"flight line has {len(parts)} fields (expected 13): {fl[:40]}...")
    if "<--additional-->" not in text:
        issues.append("additional section missing")
    return issues
