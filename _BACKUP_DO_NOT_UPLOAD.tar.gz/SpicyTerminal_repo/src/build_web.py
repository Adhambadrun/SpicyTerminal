#!/usr/bin/env python3
"""build_web.py — assemble the single-file Netlify-ready index.html.
Logos: uploads/logo.png (favicon tile) + uploads/logo_wordmark new.png (header).
Inlines: spicy_data.js + spicy_engine.js + app.js. Emits to repo root AND web/."""
import base64, pathlib, subprocess, tempfile, os

W = pathlib.Path("/home/user/web")
U = pathlib.Path("/home/user/uploads")

def png64(src, resize):
    out = tempfile.mktemp(suffix=".png")
    subprocess.run(["convert", str(src), "-resize", resize, out], check=True)
    b = base64.b64encode(open(out, "rb").read()).decode()
    os.unlink(out)
    return b

tpl = (W / "index_template.html").read_text(encoding="utf-8")
mark = png64(U / "logo.png", "128x128")                 # tab favicon (the S tile)
full = png64(W / "wordmark_alpha.png", "640x")          # transparent-bg wordmark (header + welcome)
data = (W / "spicy_data.js").read_text(encoding="utf-8")
engine = (W / "spicy_engine.js").read_text(encoding="utf-8")
app = (W / "app.js").read_text(encoding="utf-8")
html = (tpl.replace("__LOGO_MARK_B64__", mark)
           .replace("__LOGO_FULL_B64__", full)
           .replace("__SPICY_DATA__", data)
           .replace("__SPICY_ENGINE__", engine)
           .replace("__APP_JS__", app))
for dst in (W / "index.html", pathlib.Path("/home/user/index.html")):
    dst.write_text(html, encoding="utf-8")
    print(dst, len(html), "bytes")
