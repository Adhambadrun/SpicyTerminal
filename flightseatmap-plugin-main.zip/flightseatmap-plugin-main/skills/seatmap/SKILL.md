---
name: seatmap
description: This skill should be used when the user asks about "seat map", "seatmap", "seat selection", "best seat", "window seat", "aisle seat", "legroom", "exit row", "seat availability", "airplane seats", "flight seats", "seat pitch", "seat review", "bulkhead", "quiet zone", mentions specific flight numbers (e.g. QF1, BA178, AA716), or wants to check, compare, or find seats on a flight.
version: 1.0.0
---

# FlightSeatMap

Look up flight seat maps, find the best available seats, and check seat-level details for 150+ airlines.

## Available MCP Tools

### get_seatmap
Get the full seat map for a flight. Shows all seats by cabin class with availability status, characteristics (window, aisle, legroom, etc.), and pricing.

**Parameters:**
- `flight_number`: Flight number with airline code (e.g. "QF1", "BA178", "AA716")
- `flight_date`: Optional, YYYY-MM-DD format

Returns seat counts per cabin, availability breakdown, and a link to the interactive seatmap.

### get_seat_info
Get detailed information about a specific seat on a flight.

**Parameters:**
- `flight_number`: Flight number (e.g. "QF1")
- `seat_number`: Seat number (e.g. "12A", "1F", "32K")
- `flight_date`: Optional, YYYY-MM-DD format

Returns cabin class, characteristics (window/aisle/legroom/exit row), availability, and pricing.

### find_best_seats
Find the best available seats matching user preferences. Returns a ranked list.

**Parameters:**
- `flight_number`: Flight number (e.g. "QF1")
- `preferences`: Array of preferences: "window", "aisle", "extra_legroom", "exit_row", "quiet_zone", "front", "rear", "bulkhead"
- `cabin_class`: Optional filter: "ECONOMY", "PREMIUM_ECONOMY", "BUSINESS", "FIRST"
- `flight_date`: Optional, YYYY-MM-DD format

### search_flight
Search for a flight and get fresh seatmap data. Requires an API token (paid plan).

**Parameters:**
- `flight_number`: Flight number (e.g. "QF1")
- `api_token`: FlightSeatMap API token (get from flightseatmap.com)
- `flight_date`: Optional, YYYY-MM-DD format

## Workflow: Finding the Best Seat

1. **Get the seatmap** with `get_seatmap` to see the full layout and availability.
2. **Ask about preferences** — window or aisle? Extra legroom? Quiet zone? Front or rear?
3. **Find best seats** with `find_best_seats` using their preferences.
4. **Show details** for top recommendations using `get_seat_info`.
5. **Link to interactive map** — always include the seatmap URL from the response.

## Workflow: Checking a Specific Seat

1. Use `get_seat_info` with the flight and seat number.
2. Explain the characteristics in plain English (e.g., "12A is a window seat in economy with extra legroom near the exit row").
3. Mention availability and pricing if available.

## Seat Characteristics

| Code | Meaning |
|------|---------|
| W | Window seat |
| A | Aisle seat |
| E | Exit row |
| L | Extra legroom |
| 1 | Bulkhead |
| Q | Quiet zone |
| 9 | Middle seat |

## API Token (Paid Users)

For fresh flight searches, users need a paid plan. Get a token at https://flightseatmap.com/pricing

Add to `~/.claude/mcp.json` for automatic auth:
```json
{
  "mcpServers": {
    "flightseatmap": {
      "type": "url",
      "url": "https://mcp.flightseatmap.com/mcp",
      "headers": {
        "Authorization": "Bearer your-api-token"
      }
    }
  }
}
```
