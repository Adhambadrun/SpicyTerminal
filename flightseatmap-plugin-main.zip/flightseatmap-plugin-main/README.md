> [!IMPORTANT]
> **This repo has moved to [FlightSeatmap/mcp](https://github.com/FlightSeatmap/mcp).**
>
> That repo is the single home for FlightSeatMap's AI and MCP connection
> artifacts — the MCP server declaration, agent skills, slash commands, and the
> manifests for Claude Code, Cursor / Agent Plugins, xAI Grok and the official
> MCP Registry. Everything here was folded into it.
>
> The MCP endpoint itself is unchanged: `https://mcp.flightseatmap.com/mcp`.

# FlightSeatMap — Claude Code Plugin & MCP Server

Look up flight seat maps, find the best available seats, and check real-time seat availability for 150+ airlines — all from Claude Code. The #1 SeatGuru alternative, now accessible via AI.

**Works with Claude Code CLI, Claude Desktop, and any MCP-compatible client.**

## Quick Install

### Claude Code Plugin (recommended)

```bash
claude plugin add flightseatmap
```

### Manual MCP Server Setup

Add to your `~/.claude/mcp.json` or Claude Desktop config:

```json
{
  "mcpServers": {
    "flightseatmap": {
      "command": "npx",
      "args": ["mcp-remote", "https://mcp.flightseatmap.com/mcp"]
    }
  }
}
```

## What You Can Do

### Look Up Any Flight's Seat Map

```
"Show me the seat map for QF1 on June 15th"
"What's the layout of BA178?"
"How many business class seats are available on EK1?"
```

Or use the slash command:

```
/fsm:seatmap QF1 2026-06-15
/fsm:seatmap BA178
```

### Find the Best Seat for You

```
"Find me a window seat with extra legroom on QF1"
"What's the best aisle seat in economy on BA178?"
"I want a quiet zone seat near the front on AA716"
```

```
/fsm:best-seats QF1 window extra_legroom
/fsm:best-seats BA178 aisle front business
```

### Check a Specific Seat

```
"Is seat 12A on QF1 a window seat?"
"What are the characteristics of seat 1F on EK1?"
"Is 32K available on BA178?"
```

## MCP Tools

| Tool | Description | Auth |
|------|-------------|------|
| `get_seatmap` | Get full seat map for a flight (cached data) | Free |
| `get_seat_info` | Get details about a specific seat | Free |
| `find_best_seats` | Find seats matching your preferences | Free |
| `search_flight` | Search for fresh seatmap data | Paid |

## Seat Preferences

When using `find_best_seats`, you can filter by:

| Preference | Description |
|-----------|-------------|
| `window` | Window seats |
| `aisle` | Aisle seats |
| `extra_legroom` | Seats with extra legroom |
| `exit_row` | Exit row seats |
| `quiet_zone` | Quiet zone seats |
| `bulkhead` | Bulkhead seats |
| `front` | Front of cabin (row 1-10) |
| `rear` | Rear of cabin (row 30+) |

Combine with cabin class: `ECONOMY`, `PREMIUM_ECONOMY`, `BUSINESS`, or `FIRST`.

## Slash Commands

| Command | Description |
|---------|-------------|
| `/fsm:seatmap` | Look up a flight's seat map |
| `/fsm:best-seats` | Find best seats matching preferences |

## Skills

The `seatmap` skill activates automatically when you mention seat maps, seat selection, legroom, specific flight numbers, or anything about airplane seats. Just ask naturally.

## Paid Plan (Optional)

Free lookups use cached seatmap data from our database. For fresh, real-time searches of any flight:

1. Get a plan at [flightseatmap.com/pricing](https://flightseatmap.com/pricing)
2. Add your API token:

```json
{
  "mcpServers": {
    "flightseatmap": {
      "type": "url",
      "url": "https://mcp.flightseatmap.com/mcp",
      "headers": {
        "Authorization": "Bearer your-api-token"
      }
    }
  }
}
```

## 150+ Airlines Supported

Emirates, Qantas, British Airways, American Airlines, Delta, United, Qatar Airways, Singapore Airlines, Cathay Pacific, Lufthansa, Air France, KLM, and many more. If an airline flies it, we probably have the seat map.

## Plugin Structure

```
flightseatmap-plugin/
  .claude-plugin/
    plugin.json          # Plugin metadata
  .mcp.json              # MCP server connection config
  commands/
    seatmap.md           # /fsm:seatmap command
    best-seats.md        # /fsm:best-seats command
  skills/
    seatmap/
      SKILL.md           # AI skill for natural language queries
```

## How It Works

This plugin connects Claude to the [FlightSeatMap MCP server](https://mcp.flightseatmap.com), which provides seat map data for flights across 150+ airlines. Data comes from the Amadeus API and airline direct sources, covering aircraft configurations, seat characteristics, availability, and pricing.

## Links

- [FlightSeatMap](https://flightseatmap.com) — Interactive seat maps for every flight
- [MCP Server](https://mcp.flightseatmap.com) — API endpoint
- [Pricing](https://flightseatmap.com/pricing) — Plans for real-time searches
- [Award Travel Finder](https://awardtravelfinder.com) — Search award flights with points & miles

## License

MIT
