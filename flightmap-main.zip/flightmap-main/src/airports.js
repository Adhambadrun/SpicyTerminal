import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const dbPath = join(__dirname, '..', 'data', 'airports.json');

let airports = null;
function load() {
  if (airports) return airports;
  airports = JSON.parse(readFileSync(dbPath, 'utf8'));
  return airports;
}

export function lookupAirport(iata) {
  const db = load();
  return db[iata.toUpperCase()] || null;
}
