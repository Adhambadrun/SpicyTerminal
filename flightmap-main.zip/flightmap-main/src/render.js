import { chromium } from 'playwright';
import { readFileSync, writeFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join, resolve } from 'path';
import { greatCircle } from '@turf/great-circle';
import { point, featureCollection } from '@turf/helpers';
import { lookupAirport } from './airports.js';

const __dirname = dirname(fileURLToPath(import.meta.url));

function parseRoutes(routes) {
  const segments = [];
  for (const r of routes) {
    const parts = r.toUpperCase().split('-');
    if (parts.length !== 2 || !parts[0] || !parts[1]) {
      throw new Error(`invalid route "${r}" — use format ORIGIN-DEST (e.g. JFK-LHR)`);
    }
    const [from, to] = parts;
    const fromAirport = lookupAirport(from);
    const toAirport = lookupAirport(to);
    if (!fromAirport) throw new Error(`unknown airport code "${from}"`);
    if (!toAirport) throw new Error(`unknown airport code "${to}"`);
    if (from === to) throw new Error(`route "${r}" has the same origin and destination`);
    segments.push({ from: fromAirport, to: toAirport });
  }
  return segments;
}

function buildPayload({ segments, style, watermark }) {
  const arcs = segments.map((s) => {
    const start = point([s.from.lon, s.from.lat]);
    const end = point([s.to.lon, s.to.lat]);
    return greatCircle(start, end, { npoints: 100 });
  });

  const airportMap = new Map();
  for (const s of segments) {
    airportMap.set(s.from.iata, s.from);
    airportMap.set(s.to.iata, s.to);
  }
  const airports = Array.from(airportMap.values());

  return {
    style: `https://tiles.openfreemap.org/styles/${style}`,
    arcs: featureCollection(arcs),
    airports,
    watermark,
  };
}

function buildHtml(template, data) {
  // Embed payload as a JSON island; keep it injection-safe by escaping `<` in any string values.
  const json = JSON.stringify(data).replace(/</g, '\\u003c');
  return template.replace('"__FLIGHTMAP_DATA__"', json);
}

export async function renderMap({ routes, output, style, width, height, watermark, html }) {
  const segments = parseRoutes(routes);
  const data = buildPayload({ segments, style, watermark });

  const template = readFileSync(join(__dirname, 'template.html'), 'utf8');
  const populated = buildHtml(template, data);

  if (html) {
    writeFileSync(resolve(output), populated);
    return { airports: data.airports.length, arcs: segments.length };
  }

  const browser = await chromium.launch({ args: ['--no-sandbox'] });
  try {
    const context = await browser.newContext({
      viewport: { width, height },
      deviceScaleFactor: 2,
    });
    const page = await context.newPage();

    page.on('pageerror', (err) => {
      console.error(`[render] page error: ${err.message}`);
    });

    await page.setContent(populated, { waitUntil: 'load' });
    await page.waitForFunction(() => window.__FLIGHTMAP_READY__ === true, null, {
      timeout: 60_000,
    });

    await page.screenshot({ path: resolve(output), type: 'png' });
  } finally {
    await browser.close();
  }

  return { airports: data.airports.length, arcs: segments.length };
}
