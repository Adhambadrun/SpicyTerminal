# flightmap

Generate beautiful flight path maps from IATA airport codes. A free CLI tool powered by [OpenFreeMap](https://openfreemap.org/) and [MapLibre GL JS](https://maplibre.org/).

![Round-the-world example](docs/example-dark.png)

```
npx @flightseatmap/flightmap JFK-LHR LHR-DXB DXB-SYD --style dark --output trip.png
```

## Install

```sh
npm install -g @flightseatmap/flightmap
```

Or run without installing:

```sh
npx @flightseatmap/flightmap LAX-HND
```

> First run downloads a headless Chromium (~150 MB) via Playwright.

## Usage

```sh
flightmap <route>... [options]
```

A route is a pair of IATA airport codes joined with a hyphen (e.g. `JFK-LHR`). Pass as many as you want — they all render on the same map.

### Examples

Single route:

```sh
flightmap JFK-LHR
```

Multi-leg trip:

```sh
flightmap JFK-CDG CDG-FCO FCO-JFK
```

Round-the-world:

```sh
flightmap LAX-NRT NRT-SIN SIN-DXB DXB-LHR LHR-LAX --style dark --width 2000
```

Save as interactive HTML instead of PNG:

```sh
flightmap SFO-SYD --html --output trip.html
```

### Options

| Flag | Default | Description |
|------|---------|-------------|
| `-o, --output <file>` | `flightmap.png` | Output file path |
| `-s, --style <style>` | `positron` | Map style: `liberty`, `positron`, `bright`, `dark`, `fiord` |
| `-w, --width <px>` | `1600` | Image width |
| `-H, --height <px>` | `900` | Image height |
| `--html` | off | Output a standalone interactive HTML file |
| `--no-watermark` | watermark on | Hide the `flightseatmap.com` watermark |
| `-V, --version` | | Print version |
| `--help` | | Show help |

### Styles

- **liberty** — colorful OpenStreetMap-style
- **positron** — minimal light grey (great default for prints)
- **bright** — vivid OSM colors
- **dark** — dark mode
- **fiord** — muted blue/green

## How it works

1. Parses your IATA pairs and looks up coordinates from a bundled OpenFlights airport database.
2. Computes a great-circle arc for each route using `@turf/great-circle`.
3. Spawns a headless Chromium, loads MapLibre GL JS with OpenFreeMap vector tiles, draws the arcs and airport markers, and screenshots the result.

## Credits

- Map tiles by [OpenFreeMap](https://openfreemap.org/) (© OpenStreetMap contributors)
- Renderer: [MapLibre GL JS](https://maplibre.org/)
- Airport data: [OpenFlights](https://openflights.org/data.html) (ODbL)
- Made with ✈️ by [FlightSeatmap](https://flightseatmap.com)

## License

MIT
