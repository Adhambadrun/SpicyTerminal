#!/usr/bin/env node
// Downloads OpenFlights airports.dat and produces data/airports.json (IATA -> {iata,name,city,country,lat,lon}).
import { writeFileSync, mkdirSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const SOURCE = 'https://raw.githubusercontent.com/jpatokal/openflights/master/data/airports.dat';

const __dirname = dirname(fileURLToPath(import.meta.url));
const dataDir = join(__dirname, '..', 'data');
const outPath = join(dataDir, 'airports.json');

function parseCSVLine(line) {
  const fields = [];
  let cur = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '"') { inQuotes = !inQuotes; continue; }
    if (c === ',' && !inQuotes) { fields.push(cur); cur = ''; continue; }
    cur += c;
  }
  fields.push(cur);
  return fields;
}

const res = await fetch(SOURCE);
if (!res.ok) {
  console.error(`Failed to fetch ${SOURCE}: ${res.status}`);
  process.exit(1);
}
const text = await res.text();

const out = {};
let kept = 0;
let skipped = 0;
for (const line of text.split('\n')) {
  if (!line.trim()) continue;
  const f = parseCSVLine(line);
  if (f.length < 8) { skipped++; continue; }
  const iata = (f[4] || '').trim();
  const lat = parseFloat(f[6]);
  const lon = parseFloat(f[7]);
  if (!iata || iata === '\\N' || iata.length !== 3) { skipped++; continue; }
  if (!Number.isFinite(lat) || !Number.isFinite(lon)) { skipped++; continue; }
  out[iata] = {
    iata,
    name: (f[1] || '').trim(),
    city: (f[2] || '').trim(),
    country: (f[3] || '').trim(),
    lat,
    lon,
  };
  kept++;
}

mkdirSync(dataDir, { recursive: true });
writeFileSync(outPath, JSON.stringify(out));
console.log(`Wrote ${kept} airports (skipped ${skipped}) → ${outPath}`);
