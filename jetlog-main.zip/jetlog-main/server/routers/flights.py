from server.database import database
from server.environment import ENABLE_EXTERNAL_APIS
from server.models import AirlineModel, AirportModel, ClassType, CustomModel, FlightModel, AircraftSide, FlightPurpose, SeatType, User
from server.auth.users import get_current_user

from fastapi import APIRouter, Depends, HTTPException
from enum import Enum
import datetime
import pytz
import math

router = APIRouter(
    prefix="/flights",
    tags=["flights"],
    redirect_slashes=True
)

class Order(str, Enum):
    ASCENDING = "ASC"
    DESCENDING = "DESC"

class Sort(str, Enum):
    DATE = "date"
    SEAT = "seat"
    AIRCRAFT_SIDE = "aircraft_side"
    TICKET_CLASS = "ticket_class"
    DURATION = "duration"
    DISTANCE = "distance"

async def check_flight_authorization(id: int, user: User) -> None:
    res = database.execute_read_query(f"SELECT username FROM flights WHERE id = ?;", [id])
    flight_username = res[0][0]

    if flight_username != user.username and not user.is_admin:
        raise HTTPException(status_code=403, detail="Only admins can modify other users' flights")

# https://en.wikipedia.org/wiki/Haversine_formula
async def spherical_distance(origin: AirportModel|str, destination: AirportModel|str) -> int:
    from server.routers.airports import get_airport_from_icao

    # make sure we have object types
    if type(origin) == str:
        origin = await get_airport_from_icao(origin)
    if type(destination) == str:
        destination = await get_airport_from_icao(destination)

    assert type(origin) == AirportModel and type(destination) == AirportModel

    if not origin.latitude or not origin.longitude or not destination.latitude or not destination.longitude:
        return 0

    #convert to radian
    origin_lat = origin.latitude * math.pi / 180.0;
    origin_lon = origin.longitude * math.pi / 180.0;
    destination_lat = destination.latitude * math.pi / 180.0;
    destination_lon = destination.longitude * math.pi / 180.0;

    # get deltas
    delta_lat = origin_lat - destination_lat;
    delta_lon = origin_lon - destination_lon;

    # apply Haversine formulas
    hav_delta_lat = math.sin(delta_lat / 2) ** 2;
    hav_delta_lon = math.sin(delta_lon / 2) ** 2;

    hav_theta = hav_delta_lat + (hav_delta_lon * math.cos(origin_lat) * math.cos(destination_lat))

    earth_radius = 6371; # km
    distance = 2 * earth_radius * math.asin(math.sqrt(hav_theta));

    return round(distance);

def to_utc(dt: datetime.datetime, airport: str|AirportModel) -> datetime.datetime:
    if type(airport) != AirportModel:
        tz_name = database.execute_read_query("SELECT timezone FROM airports WHERE icao = ?;", [airport])[0][0]
    else:
        tz_name = airport.timezone

    tz = pytz.timezone(tz_name)
    utc_dt = tz.localize(dt).astimezone(pytz.utc)

    return utc_dt

def duration(departure: datetime.datetime, arrival: datetime.datetime) -> int:
    if arrival.time() <= departure.time():
        arrival_date = arrival.date() + datetime.timedelta(days=1)
        arrival = arrival.replace(day=arrival_date.day)

    delta = arrival - departure
    delta_minutes = delta.seconds // 60
    return delta_minutes

@router.post("/many", status_code=201)
async def add_many_flights(flights: list[FlightModel], timezones: bool = True, user: User = Depends(get_current_user)) -> int:
    creator_flight_id = -1
    for flight in flights:
        if flight.username != user.username and not user.is_admin:
            raise HTTPException(status_code=403, detail="Only admins can add flights for other users")

        flight_id = await add_flight(flight, timezones, user)
        if flight.username == user.username:
            creator_flight_id = flight_id

    return creator_flight_id

@router.post("", status_code=201)
async def add_flight(flight: FlightModel, timezones: bool = True, user: User = Depends(get_current_user)) -> int:
    # only admins may add flights for other users
    if flight.username != user.username and not user.is_admin:
        raise HTTPException(status_code=403, detail="Only admins can add flights for other users")

    if not (flight.date and flight.origin and flight.destination):
        raise HTTPException(status_code=404,
                            detail="Insufficient flight data. Date, Origin, and Destination are required")

    # if distance not given, calculate it
    if not flight.distance:
        flight.distance = await spherical_distance(flight.origin, flight.destination)

    # if duration not given, calculate it
    if not flight.duration and flight.departure_time and flight.arrival_time:
        # create datetime objects
        departure = datetime.datetime.strptime(f"{flight.date} {flight.departure_time}", "%Y-%m-%d %H:%M")
        arrival = datetime.datetime.strptime(f"{flight.arrival_date if flight.arrival_date else flight.date} {flight.arrival_time}", "%Y-%m-%d %H:%M")

        # if using timezones, convert to UTC
        if timezones:
            departure = to_utc(departure, flight.origin)
            arrival = to_utc(arrival, flight.destination)

        flight.duration = duration(departure, arrival)

    columns = FlightModel.get_attributes(ignore=["id"])

    query = "INSERT INTO flights ("
    for attr in columns:
        query += f"{attr},"
    query = query[:-1]
    query += ") VALUES (" + ('?,' * len(columns))
    query = query[:-1]
    query += ") RETURNING id;"


    explicit = {"username": user.username} if not flight.username else {}
    values = flight.get_values(ignore=["id"], explicit=explicit)

    new_id = database.execute_query(query, values)[0]
    return new_id

class FlightPatchModel(CustomModel):
    date:             datetime.date|None = None
    origin:           AirportModel|str|None = None
    destination:      AirportModel|str|None = None
    departure_time:   str|None = None
    arrival_time:     str|None = None
    arrival_date:     datetime.date|None = None
    seat:             SeatType|None = None
    aircraft_side:    AircraftSide|None = None
    ticket_class:     ClassType|None = None
    purpose:          FlightPurpose|None = None
    duration:         int|None = None
    distance:         int|None = None
    airplane:         str|None = None
    airline:          AirlineModel|str|None = None
    tail_number:      str|None = None
    flight_number:    str|None = None
    notes:            str|None = None
    connection:       int|None = None

@router.patch("", status_code=200)
async def update_flight(id: int,
                        new_flight: FlightPatchModel,
                        timezones: bool = True,
                        user: User = Depends(get_current_user)) -> int:
    await check_flight_authorization(id, user)

    if new_flight.empty():
        return id

    # if airports changed, update distance (unless specified)
    if new_flight.origin or new_flight.destination and not new_flight.distance:
        # first must have both airports
        original_flight = await get_flights(id=id)
        assert type(original_flight) == FlightModel

        new_origin = new_flight.origin if new_flight.origin else original_flight.origin
        new_destination = new_flight.destination if new_flight.destination else original_flight.destination

        new_flight.distance = await spherical_distance(new_origin, new_destination)

    # if arrival / departure date or arrival date changed, update duration (unless specified)
    if not new_flight.duration:
        if new_flight.date or new_flight.departure_time or new_flight.arrival_date or new_flight.arrival_time:
            original_flight = await get_flights(id=id)
            assert type(original_flight) == FlightModel

            new_departure_date = new_flight.date if new_flight.date else original_flight.date
            new_departure_time = new_flight.departure_time if new_flight.departure_time else original_flight.departure_time
            new_arrival_date = new_flight.arrival_date if new_flight.arrival_date else original_flight.arrival_date
            new_arrival_time = new_flight.arrival_time if new_flight.arrival_time else original_flight.arrival_time

            # if arrival or departure times still not available, skip
            if new_arrival_time and new_departure_time:
                # create datetime objects
                new_departure = datetime.datetime.strptime(f"{new_departure_date} {new_departure_time}", "%Y-%m-%d %H:%M")
                new_arrival = datetime.datetime.strptime(f"{new_arrival_date if new_arrival_date else new_departure_date} {new_arrival_time}", "%Y-%m-%d %H:%M")

                # if using timezones, convert to UTC
                if timezones:
                    new_departure = to_utc(new_departure, new_flight.origin if new_flight.origin else original_flight.origin)
                    new_arrival = to_utc(new_arrival, new_flight.destination if new_flight.destination else original_flight.destination)

                new_flight.duration = duration(new_departure, new_arrival)

    query = "UPDATE flights SET "

    for attr in FlightPatchModel.get_attributes():
        value = getattr(new_flight, attr)
        if value:
            query += f"{attr}=?," if value else ""

    if query[-1] == ',':
        query = query[:-1]

    query += f" WHERE id = {str(id)} RETURNING id;"

    values = [value for value in new_flight.get_values() if value is not None]

    new_id = database.execute_query(query, values)[0]
    return new_id

@router.delete("", status_code=200)
async def delete_flight(id: int, user: User = Depends(get_current_user)) -> int:
    await check_flight_authorization(id, user)

    deleted_id = database.execute_query("DELETE FROM flights WHERE id = ? RETURNING id;", [id])[0]
    return deleted_id

@router.get("", status_code=200)
async def get_flights(id: int|None = None,
                      metric: bool = True,
                      limit: int = 50,
                      offset: int = 0,
                      order: Order = Order.DESCENDING,
                      sort: Sort = Sort.DATE,
                      start: datetime.date|None = None,
                      end: datetime.date|None = None,
                      origin: str|None = None,
                      destination: str|None = None,
                      username: str|None = None,
                      user: User = Depends(get_current_user)) -> list[FlightModel]|FlightModel:

    username_filter = None if id else username if username else user.username

    if sort == Sort.DATE:
        sort_clause = f"ORDER BY f.date {order.value}, f.departure_time {order.value}"
    else:
        sort_clause = f"ORDER BY f.{sort.value} {order.value}"

    query = f"""
        SELECT
            f.*,
            o.*,
            d.*,
            a.*
        FROM flights f
        JOIN airports o ON UPPER(f.origin) = o.icao
        JOIN airports d ON UPPER(f.destination) = d.icao
        LEFT JOIN airlines a ON UPPER(f.airline) = a.icao
        WHERE (? IS NULL OR f.id = ?)
        AND   (? IS NULL OR f.username = ?)
        AND   (? IS NULL OR JULIANDAY(date) >= JULIANDAY(?))
        AND   (? IS NULL OR JULIANDAY(date) <= JULIANDAY(?))
        AND   (? IS NULL OR f.origin = UPPER(?))
        AND   (? IS NULL OR f.destination = UPPER(?))
        {sort_clause}
        LIMIT {limit}
        OFFSET {offset};"""

    values = []
    for value in [id, username_filter, start, end, origin, destination]:
        values.append(value)
        values.append(value)

    res = database.execute_read_query(query, values);

    # get rid of origin, destination, and airline ICAOs for proper conversion
    # after this, each flight_db is in the format:
    # [id, username, date, departure_time, ..., AirportModel, AirportModel, AirlineModel]
    res = [ db_flight[:3] + db_flight[5:15] + db_flight[16:] for db_flight in res ]

    flights = []

    for db_flight in res:
        begin = len(FlightModel.get_attributes()) - 3
        airport_length = len(AirportModel.get_attributes())
        airline_length = len(AirlineModel.get_attributes())

        db_origin = db_flight[begin:begin + airport_length]
        db_destination = db_flight[begin + airport_length:begin + 2*airport_length]
        db_airline = db_flight[begin + 2*airport_length:begin + 2*airport_length + airline_length]

        origin = AirportModel.from_database(db_origin)
        destination = AirportModel.from_database(db_destination)
        airline = AirlineModel.from_database(db_airline) if db_airline[0] != None else None

        flight = FlightModel.from_database(db_flight, { "origin": origin,
                                                        "destination": destination,
                                                        "airline": airline } )

        if not metric and flight.distance:
            flight.distance = round(flight.distance * 0.6213711922)

        flights.append(flight)

    if id and not flights:
        raise HTTPException(status_code=404, detail=f"Flight not found.")

    if id:
        return FlightModel.model_validate(flights[0])
    return [ FlightModel.model_validate(flight) for flight in flights ]

@router.post("/connections", status_code=200)
async def compute_connections(user: User = Depends(get_current_user)) -> dict:
    query = """
        WITH plausible AS (
            SELECT f.id  AS flight_id, c.id AS conn_id
            FROM flights AS f
            JOIN flights AS c ON
                c.origin = f.destination
                AND c.destination != f.origin
                AND JULIANDAY(c.date) BETWEEN JULIANDAY(f.date) - 1 AND JULIANDAY(f.date) + 2
                AND c.username = ?
            WHERE f.username = ? AND f.connection IS NULL
        ),
        one_conn AS (
            SELECT flight_id, MAX(conn_id) AS conn_id
            FROM plausible
            GROUP BY flight_id
            HAVING COUNT(*) = 1
        ),
        multi_conn AS (
            SELECT flight_id FROM plausible
            GROUP BY flight_id
            HAVING COUNT(*) > 1
        )

        UPDATE flights SET connection = (
            SELECT conn_id
            FROM one_conn
            WHERE one_conn.flight_id = flights.id
        )
        WHERE id IN (SELECT flight_id FROM one_conn)
        RETURNING
            ( SELECT COUNT(*) FROM multi_conn ) AS amount_skipped,
            ( SELECT COUNT(*) FROM one_conn ) AS amount_updated;"""

    res = database.execute_query(query, [user.username]*2)

    if not res:
        res = (0, 0)

    return { "amountSkipped": res[0], "amountUpdated": res[1] }

@router.post("/airlines_from_callsigns", status_code=200)
async def fetch_airlines_from_callsigns(user: User = Depends(get_current_user)) -> dict:
    if not ENABLE_EXTERNAL_APIS:
        raise HTTPException(status_code=400, detail="This endpoint relies on the use of an external API, which you have opted out of.")
    import requests

    res = database.execute_read_query("""SELECT flight_number, COUNT(*)
                                         FROM flights
                                         WHERE flight_number IS NOT NULL AND airline IS NULL AND username = ?
                                         GROUP BY flight_number;""", [user.username])

    updates = 0
    skips = 0
    for callsign, amount in res:
        adsbdb_res = requests.get(f"https://api.adsbdb.com/v0/callsign/{callsign}")

        print(callsign, amount, adsbdb_res.status_code)

        if adsbdb_res.status_code != 200:
            skips += amount
            continue

        data = adsbdb_res.json()

        airline_icao = data["response"]["flightroute"]["airline"]["icao"];

        query = """UPDATE flights
                   SET airline = ?
                   WHERE flight_number = ? AND airline IS NULL AND username = ?;"""

        database.execute_query(query, [airline_icao, callsign, user.username])
        updates += amount

    return { "amountSkipped": skips, "amountUpdated": updates }
