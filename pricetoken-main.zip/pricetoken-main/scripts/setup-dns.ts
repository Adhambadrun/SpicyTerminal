/**
 * One-time Cloudflare DNS + email routing setup for pricetoken.ai
 *
 * Usage: infisical run --projectId 730076b1-5f72-4691-b271-139dc721529e --env dev -- npx tsx scripts/setup-dns.ts
 *
 * Required env: CF_DNS_API_TOKEN, CF_ZONE_ID, CF_ACCOUNT_ID, HETZNER_IP, EMAIL_FORWARD_TO
 */

const CF_API = 'https://api.cloudflare.com/client/v4';

interface DnsRecord {
  id: string;
  type: string;
  name: string;
  content: string;
  proxied: boolean;
}

interface CfListResponse {
  success: boolean;
  result: DnsRecord[];
  errors: { message: string }[];
}

interface CfMutateResponse {
  success: boolean;
  result: DnsRecord;
  errors: { message: string }[];
}

interface CfGenericResponse {
  success: boolean;
  result: Record<string, unknown>;
  errors: { message: string }[];
}

const REQUIRED_ENV = ['CF_DNS_API_TOKEN', 'CF_ZONE_ID', 'CF_ACCOUNT_ID', 'HETZNER_IP', 'EMAIL_FORWARD_TO'] as const;

function getEnv(key: string): string {
  const value = process.env[key];
  if (!value) {
    console.error(`Missing required env var: ${key}`);
    process.exit(1);
  }
  return value;
}

async function cfFetch<T>(path: string, options?: RequestInit): Promise<T> {
  const token = getEnv('CF_DNS_API_TOKEN');
  const res = await fetch(`${CF_API}${path}`, {
    ...options,
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
      ...options?.headers,
    },
  });
  const json = (await res.json()) as T;
  return json;
}

async function getExistingRecords(zoneId: string): Promise<DnsRecord[]> {
  const response = await cfFetch<CfListResponse>(
    `/zones/${zoneId}/dns_records?per_page=100`
  );
  if (!response.success) {
    console.error('Failed to list DNS records:', response.errors);
    process.exit(1);
  }
  return response.result;
}

async function upsertRecord(
  zoneId: string,
  existing: DnsRecord[],
  record: { type: string; name: string; content: string; proxied: boolean }
): Promise<void> {
  const match = existing.find(
    (r) => r.type === record.type && r.name === record.name
  );

  if (match && match.content === record.content && match.proxied === record.proxied) {
    console.log(`  SKIP  ${record.type} ${record.name} → ${record.content} (already exists)`);
    return;
  }

  if (match) {
    const response = await cfFetch<CfMutateResponse>(
      `/zones/${zoneId}/dns_records/${match.id}`,
      {
        method: 'PUT',
        body: JSON.stringify(record),
      }
    );
    if (!response.success) {
      console.error(`  FAIL  update ${record.name}:`, response.errors);
      return;
    }
    console.log(`  UPDATE ${record.type} ${record.name} → ${record.content}`);
  } else {
    const response = await cfFetch<CfMutateResponse>(
      `/zones/${zoneId}/dns_records`,
      {
        method: 'POST',
        body: JSON.stringify(record),
      }
    );
    if (!response.success) {
      console.error(`  FAIL  create ${record.name}:`, response.errors);
      return;
    }
    console.log(`  CREATE ${record.type} ${record.name} → ${record.content}`);
  }
}

async function main() {
  for (const key of REQUIRED_ENV) {
    getEnv(key);
  }

  const zoneId = getEnv('CF_ZONE_ID');
  const ip = getEnv('HETZNER_IP');

  console.log('Fetching existing DNS records...');
  const existing = await getExistingRecords(zoneId);
  console.log(`Found ${existing.length} existing records\n`);

  const records = [
    { type: 'A', name: 'pricetoken.ai', content: ip, proxied: true },
    { type: 'A', name: 'www.pricetoken.ai', content: ip, proxied: true },
    { type: 'CNAME', name: 'api.pricetoken.ai', content: 'pricetoken.ai', proxied: true },
  ];

  console.log('Upserting DNS records:');
  for (const record of records) {
    await upsertRecord(zoneId, existing, record);
  }

  // ---- Email Routing ----
  const accountId = getEnv('CF_ACCOUNT_ID');
  const forwardTo = getEnv('EMAIL_FORWARD_TO');

  console.log('\nSetting up email routing...');

  // 1. Enable email routing (auto-creates MX + SPF records)
  const enableRes = await cfFetch<CfGenericResponse>(
    `/zones/${zoneId}/email/routing/dns`,
    { method: 'POST', body: JSON.stringify({}) }
  );
  if (enableRes.success) {
    console.log('  Email routing enabled (MX + SPF records created)');
  } else {
    const alreadyEnabled = enableRes.errors.some((e) =>
      e.message.toLowerCase().includes('already')
    );
    if (alreadyEnabled) {
      console.log('  SKIP  Email routing already enabled');
    } else {
      console.error('  WARN  Enable email routing:', enableRes.errors);
    }
  }

  // 2. Create destination address (requires manual verification via email)
  const destRes = await cfFetch<CfGenericResponse>(
    `/accounts/${accountId}/email/routing/addresses`,
    { method: 'POST', body: JSON.stringify({ email: forwardTo }) }
  );
  if (destRes.success) {
    console.log(`  CREATE destination: ${forwardTo} (check inbox to verify)`);
  } else {
    const alreadyExists = destRes.errors.some((e) =>
      e.message.toLowerCase().includes('already')
    );
    if (alreadyExists) {
      console.log(`  SKIP  Destination ${forwardTo} already exists`);
    } else {
      console.error('  WARN  Create destination:', destRes.errors);
    }
  }

  // 3. Set catch-all rule → forward everything to destination
  const catchAllRes = await cfFetch<CfGenericResponse>(
    `/zones/${zoneId}/email/routing/rules/catch_all`,
    {
      method: 'PUT',
      body: JSON.stringify({
        enabled: true,
        name: 'Catch-all forward to personal email',
        matchers: [{ type: 'all' }],
        actions: [{ type: 'forward', value: [forwardTo] }],
      }),
    }
  );
  if (catchAllRes.success) {
    console.log(`  UPDATE catch-all → ${forwardTo}`);
  } else {
    console.error('  FAIL  Update catch-all:', catchAllRes.errors);
  }

  console.log('\nDone.');
}

main().catch((err) => {
  console.error('DNS setup failed:', err);
  process.exit(1);
});
