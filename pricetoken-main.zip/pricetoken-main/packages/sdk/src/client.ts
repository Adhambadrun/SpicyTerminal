import type {
  ModelPricing,
  ModelHistory,
  ProviderSummary,
  ImageModelPricing,
  ImageModelHistory,
  ImageProviderSummary,
  PriceTokenResponse,
  PriceTokenError,
  VideoModelPricing,
  VideoModelHistory,
  VideoProviderSummary,
  AvatarModelPricing,
  AvatarModelHistory,
  AvatarProviderSummary,
  TtsModelPricing,
  TtsModelHistory,
  TtsProviderSummary,
  SttModelPricing,
  SttModelHistory,
  SttProviderSummary,
  MusicModelPricing,
  MusicModelHistory,
  MusicProviderSummary,
} from './types';

const SDK_VERSION = '0.10.0';

export interface ClientOptions {
  baseUrl?: string;
  apiKey?: string;
  telemetry?: boolean;
}

export class PriceTokenClient {
  private readonly baseUrl: string;
  private readonly apiKey?: string;
  private readonly telemetryEnabled: boolean;
  private telemetrySent = false;

  constructor(options?: ClientOptions) {
    this.baseUrl = (options?.baseUrl ?? 'https://pricetoken.ai').replace(/\/$/, '');
    this.apiKey = options?.apiKey;
    this.telemetryEnabled = options?.telemetry ?? false;
  }

  private sendTelemetry(): void {
    if (!this.telemetryEnabled || this.telemetrySent) return;
    this.telemetrySent = true;

    const runtime =
      typeof globalThis.process !== 'undefined'
        ? `node-${globalThis.process.version?.replace('v', '') ?? 'unknown'}`
        : 'browser';

    fetch(`${this.baseUrl}/api/v1/telemetry`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ sdk: 'js', version: SDK_VERSION, runtime }),
    }).catch(() => {
      // fire-and-forget
    });
  }

  private async request<T>(path: string): Promise<T> {
    this.sendTelemetry();
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };

    if (this.apiKey) {
      headers['Authorization'] = `Bearer ${this.apiKey}`;
    }

    const res = await fetch(`${this.baseUrl}${path}`, { headers });

    if (!res.ok) {
      const body = (await res.json().catch(() => null)) as PriceTokenError | null;
      const error = new Error(body?.error ?? `HTTP ${res.status}`);
      (error as Error & { status: number }).status = res.status;
      throw error;
    }

    const json = (await res.json()) as PriceTokenResponse<T>;
    return json.data;
  }

  async getPricing(opts?: { provider?: string; currency?: string; after?: string; before?: string }): Promise<ModelPricing[]> {
    const params = new URLSearchParams();
    if (opts?.provider) params.set('provider', opts.provider);
    if (opts?.currency) params.set('currency', opts.currency);
    if (opts?.after) params.set('after', opts.after);
    if (opts?.before) params.set('before', opts.before);
    const qs = params.toString();
    return this.request<ModelPricing[]>(`/api/v1/text${qs ? `?${qs}` : ''}`);
  }

  async getModel(modelId: string, opts?: { currency?: string }): Promise<ModelPricing> {
    const params = new URLSearchParams();
    if (opts?.currency) params.set('currency', opts.currency);
    const qs = params.toString();
    return this.request<ModelPricing>(`/api/v1/text/${encodeURIComponent(modelId)}${qs ? `?${qs}` : ''}`);
  }

  async getHistory(opts?: {
    days?: number;
    modelId?: string;
    provider?: string;
  }): Promise<ModelHistory[]> {
    const params = new URLSearchParams();
    if (opts?.days) params.set('days', String(opts.days));
    if (opts?.modelId) params.set('modelId', opts.modelId);
    if (opts?.provider) params.set('provider', opts.provider);
    const qs = params.toString();
    return this.request<ModelHistory[]>(`/api/v1/text/history${qs ? `?${qs}` : ''}`);
  }

  async getProviders(): Promise<ProviderSummary[]> {
    return this.request<ProviderSummary[]>('/api/v1/text/providers');
  }

  async compare(modelIds: string[], opts?: { currency?: string }): Promise<ModelPricing[]> {
    const params = new URLSearchParams({ models: modelIds.join(',') });
    if (opts?.currency) params.set('currency', opts.currency);
    return this.request<ModelPricing[]>(`/api/v1/text/compare?${params}`);
  }

  async getCheapest(opts?: { provider?: string; currency?: string; after?: string; before?: string }): Promise<ModelPricing> {
    const params = new URLSearchParams();
    if (opts?.provider) params.set('provider', opts.provider);
    if (opts?.currency) params.set('currency', opts.currency);
    if (opts?.after) params.set('after', opts.after);
    if (opts?.before) params.set('before', opts.before);
    const qs = params.toString();
    return this.request<ModelPricing>(`/api/v1/text/cheapest${qs ? `?${qs}` : ''}`);
  }

  // Image pricing methods

  async getImagePricing(opts?: { provider?: string; currency?: string; after?: string; before?: string }): Promise<ImageModelPricing[]> {
    const params = new URLSearchParams();
    if (opts?.provider) params.set('provider', opts.provider);
    if (opts?.currency) params.set('currency', opts.currency);
    if (opts?.after) params.set('after', opts.after);
    if (opts?.before) params.set('before', opts.before);
    const qs = params.toString();
    return this.request<ImageModelPricing[]>(`/api/v1/image${qs ? `?${qs}` : ''}`);
  }

  async getImageModel(modelId: string, opts?: { currency?: string }): Promise<ImageModelPricing> {
    const params = new URLSearchParams();
    if (opts?.currency) params.set('currency', opts.currency);
    const qs = params.toString();
    return this.request<ImageModelPricing>(`/api/v1/image/${encodeURIComponent(modelId)}${qs ? `?${qs}` : ''}`);
  }

  async getImageHistory(opts?: {
    days?: number;
    modelId?: string;
    provider?: string;
  }): Promise<ImageModelHistory[]> {
    const params = new URLSearchParams();
    if (opts?.days) params.set('days', String(opts.days));
    if (opts?.modelId) params.set('modelId', opts.modelId);
    if (opts?.provider) params.set('provider', opts.provider);
    const qs = params.toString();
    return this.request<ImageModelHistory[]>(`/api/v1/image/history${qs ? `?${qs}` : ''}`);
  }

  async getImageProviders(): Promise<ImageProviderSummary[]> {
    return this.request<ImageProviderSummary[]>('/api/v1/image/providers');
  }

  async compareImages(modelIds: string[], opts?: { currency?: string }): Promise<ImageModelPricing[]> {
    const params = new URLSearchParams({ models: modelIds.join(',') });
    if (opts?.currency) params.set('currency', opts.currency);
    return this.request<ImageModelPricing[]>(`/api/v1/image/compare?${params}`);
  }

  async getCheapestImage(opts?: { provider?: string; currency?: string; after?: string; before?: string }): Promise<ImageModelPricing> {
    const params = new URLSearchParams();
    if (opts?.provider) params.set('provider', opts.provider);
    if (opts?.currency) params.set('currency', opts.currency);
    if (opts?.after) params.set('after', opts.after);
    if (opts?.before) params.set('before', opts.before);
    const qs = params.toString();
    return this.request<ImageModelPricing>(`/api/v1/image/cheapest${qs ? `?${qs}` : ''}`);
  }

  // Video pricing methods

  async getVideoPricing(opts?: { provider?: string; currency?: string; after?: string; before?: string }): Promise<VideoModelPricing[]> {
    const params = new URLSearchParams();
    if (opts?.provider) params.set('provider', opts.provider);
    if (opts?.currency) params.set('currency', opts.currency);
    if (opts?.after) params.set('after', opts.after);
    if (opts?.before) params.set('before', opts.before);
    const qs = params.toString();
    return this.request<VideoModelPricing[]>(`/api/v1/video${qs ? `?${qs}` : ''}`);
  }

  async getVideoModel(modelId: string, opts?: { currency?: string }): Promise<VideoModelPricing> {
    const params = new URLSearchParams();
    if (opts?.currency) params.set('currency', opts.currency);
    const qs = params.toString();
    return this.request<VideoModelPricing>(`/api/v1/video/${encodeURIComponent(modelId)}${qs ? `?${qs}` : ''}`);
  }

  async getVideoHistory(opts?: { days?: number; modelId?: string; provider?: string }): Promise<VideoModelHistory[]> {
    const params = new URLSearchParams();
    if (opts?.days) params.set('days', String(opts.days));
    if (opts?.modelId) params.set('modelId', opts.modelId);
    if (opts?.provider) params.set('provider', opts.provider);
    const qs = params.toString();
    return this.request<VideoModelHistory[]>(`/api/v1/video/history${qs ? `?${qs}` : ''}`);
  }

  async getVideoProviders(): Promise<VideoProviderSummary[]> {
    return this.request<VideoProviderSummary[]>('/api/v1/video/providers');
  }

  async compareVideoModels(modelIds: string[], opts?: { currency?: string }): Promise<VideoModelPricing[]> {
    const params = new URLSearchParams({ models: modelIds.join(',') });
    if (opts?.currency) params.set('currency', opts.currency);
    return this.request<VideoModelPricing[]>(`/api/v1/video/compare?${params}`);
  }

  async getCheapestVideoModel(opts?: { provider?: string; currency?: string; after?: string; before?: string }): Promise<VideoModelPricing> {
    const params = new URLSearchParams();
    if (opts?.provider) params.set('provider', opts.provider);
    if (opts?.currency) params.set('currency', opts.currency);
    if (opts?.after) params.set('after', opts.after);
    if (opts?.before) params.set('before', opts.before);
    const qs = params.toString();
    return this.request<VideoModelPricing>(`/api/v1/video/cheapest${qs ? `?${qs}` : ''}`);
  }

  // Avatar pricing methods

  async getAvatarPricing(opts?: { provider?: string; currency?: string; after?: string; before?: string }): Promise<AvatarModelPricing[]> {
    const params = new URLSearchParams();
    if (opts?.provider) params.set('provider', opts.provider);
    if (opts?.currency) params.set('currency', opts.currency);
    if (opts?.after) params.set('after', opts.after);
    if (opts?.before) params.set('before', opts.before);
    const qs = params.toString();
    return this.request<AvatarModelPricing[]>(`/api/v1/avatar${qs ? `?${qs}` : ''}`);
  }

  async getAvatarModel(modelId: string, opts?: { currency?: string }): Promise<AvatarModelPricing> {
    const params = new URLSearchParams();
    if (opts?.currency) params.set('currency', opts.currency);
    const qs = params.toString();
    return this.request<AvatarModelPricing>(`/api/v1/avatar/${encodeURIComponent(modelId)}${qs ? `?${qs}` : ''}`);
  }

  async getAvatarHistory(opts?: { days?: number; modelId?: string; provider?: string }): Promise<AvatarModelHistory[]> {
    const params = new URLSearchParams();
    if (opts?.days) params.set('days', String(opts.days));
    if (opts?.modelId) params.set('modelId', opts.modelId);
    if (opts?.provider) params.set('provider', opts.provider);
    const qs = params.toString();
    return this.request<AvatarModelHistory[]>(`/api/v1/avatar/history${qs ? `?${qs}` : ''}`);
  }

  async getAvatarProviders(): Promise<AvatarProviderSummary[]> {
    return this.request<AvatarProviderSummary[]>('/api/v1/avatar/providers');
  }

  async compareAvatarModels(modelIds: string[], opts?: { currency?: string }): Promise<AvatarModelPricing[]> {
    const params = new URLSearchParams({ models: modelIds.join(',') });
    if (opts?.currency) params.set('currency', opts.currency);
    return this.request<AvatarModelPricing[]>(`/api/v1/avatar/compare?${params}`);
  }

  async getCheapestAvatarModel(opts?: { provider?: string; currency?: string; after?: string; before?: string }): Promise<AvatarModelPricing> {
    const params = new URLSearchParams();
    if (opts?.provider) params.set('provider', opts.provider);
    if (opts?.currency) params.set('currency', opts.currency);
    if (opts?.after) params.set('after', opts.after);
    if (opts?.before) params.set('before', opts.before);
    const qs = params.toString();
    return this.request<AvatarModelPricing>(`/api/v1/avatar/cheapest${qs ? `?${qs}` : ''}`);
  }

  // TTS pricing methods

  async getTtsPricing(opts?: { provider?: string; currency?: string; after?: string; before?: string }): Promise<TtsModelPricing[]> {
    const params = new URLSearchParams();
    if (opts?.provider) params.set('provider', opts.provider);
    if (opts?.currency) params.set('currency', opts.currency);
    if (opts?.after) params.set('after', opts.after);
    if (opts?.before) params.set('before', opts.before);
    const qs = params.toString();
    return this.request<TtsModelPricing[]>(`/api/v1/tts${qs ? `?${qs}` : ''}`);
  }

  async getTtsModel(modelId: string, opts?: { currency?: string }): Promise<TtsModelPricing> {
    const params = new URLSearchParams();
    if (opts?.currency) params.set('currency', opts.currency);
    const qs = params.toString();
    return this.request<TtsModelPricing>(`/api/v1/tts/${encodeURIComponent(modelId)}${qs ? `?${qs}` : ''}`);
  }

  async getTtsHistory(opts?: { days?: number; modelId?: string; provider?: string }): Promise<TtsModelHistory[]> {
    const params = new URLSearchParams();
    if (opts?.days) params.set('days', String(opts.days));
    if (opts?.modelId) params.set('modelId', opts.modelId);
    if (opts?.provider) params.set('provider', opts.provider);
    const qs = params.toString();
    return this.request<TtsModelHistory[]>(`/api/v1/tts/history${qs ? `?${qs}` : ''}`);
  }

  async getTtsProviders(): Promise<TtsProviderSummary[]> {
    return this.request<TtsProviderSummary[]>('/api/v1/tts/providers');
  }

  async compareTtsModels(modelIds: string[], opts?: { currency?: string }): Promise<TtsModelPricing[]> {
    const params = new URLSearchParams({ models: modelIds.join(',') });
    if (opts?.currency) params.set('currency', opts.currency);
    return this.request<TtsModelPricing[]>(`/api/v1/tts/compare?${params}`);
  }

  async getCheapestTtsModel(opts?: { provider?: string; currency?: string; after?: string; before?: string }): Promise<TtsModelPricing> {
    const params = new URLSearchParams();
    if (opts?.provider) params.set('provider', opts.provider);
    if (opts?.currency) params.set('currency', opts.currency);
    if (opts?.after) params.set('after', opts.after);
    if (opts?.before) params.set('before', opts.before);
    const qs = params.toString();
    return this.request<TtsModelPricing>(`/api/v1/tts/cheapest${qs ? `?${qs}` : ''}`);
  }

  // STT pricing methods

  async getSttPricing(opts?: { provider?: string; currency?: string; after?: string; before?: string }): Promise<SttModelPricing[]> {
    const params = new URLSearchParams();
    if (opts?.provider) params.set('provider', opts.provider);
    if (opts?.currency) params.set('currency', opts.currency);
    if (opts?.after) params.set('after', opts.after);
    if (opts?.before) params.set('before', opts.before);
    const qs = params.toString();
    return this.request<SttModelPricing[]>(`/api/v1/stt${qs ? `?${qs}` : ''}`);
  }

  async getSttModel(modelId: string, opts?: { currency?: string }): Promise<SttModelPricing> {
    const params = new URLSearchParams();
    if (opts?.currency) params.set('currency', opts.currency);
    const qs = params.toString();
    return this.request<SttModelPricing>(`/api/v1/stt/${encodeURIComponent(modelId)}${qs ? `?${qs}` : ''}`);
  }

  async getSttHistory(opts?: { days?: number; modelId?: string; provider?: string }): Promise<SttModelHistory[]> {
    const params = new URLSearchParams();
    if (opts?.days) params.set('days', String(opts.days));
    if (opts?.modelId) params.set('modelId', opts.modelId);
    if (opts?.provider) params.set('provider', opts.provider);
    const qs = params.toString();
    return this.request<SttModelHistory[]>(`/api/v1/stt/history${qs ? `?${qs}` : ''}`);
  }

  async getSttProviders(): Promise<SttProviderSummary[]> {
    return this.request<SttProviderSummary[]>('/api/v1/stt/providers');
  }

  async compareSttModels(modelIds: string[], opts?: { currency?: string }): Promise<SttModelPricing[]> {
    const params = new URLSearchParams({ models: modelIds.join(',') });
    if (opts?.currency) params.set('currency', opts.currency);
    return this.request<SttModelPricing[]>(`/api/v1/stt/compare?${params}`);
  }

  async getCheapestSttModel(opts?: { provider?: string; currency?: string; after?: string; before?: string }): Promise<SttModelPricing> {
    const params = new URLSearchParams();
    if (opts?.provider) params.set('provider', opts.provider);
    if (opts?.currency) params.set('currency', opts.currency);
    if (opts?.after) params.set('after', opts.after);
    if (opts?.before) params.set('before', opts.before);
    const qs = params.toString();
    return this.request<SttModelPricing>(`/api/v1/stt/cheapest${qs ? `?${qs}` : ''}`);
  }

  // Music pricing methods

  async getMusicPricing(opts?: { provider?: string; currency?: string; after?: string; before?: string }): Promise<MusicModelPricing[]> {
    const params = new URLSearchParams();
    if (opts?.provider) params.set('provider', opts.provider);
    if (opts?.currency) params.set('currency', opts.currency);
    if (opts?.after) params.set('after', opts.after);
    if (opts?.before) params.set('before', opts.before);
    const qs = params.toString();
    return this.request<MusicModelPricing[]>(`/api/v1/music${qs ? `?${qs}` : ''}`);
  }

  async getMusicModel(modelId: string, opts?: { currency?: string }): Promise<MusicModelPricing> {
    const params = new URLSearchParams();
    if (opts?.currency) params.set('currency', opts.currency);
    const qs = params.toString();
    return this.request<MusicModelPricing>(`/api/v1/music/${encodeURIComponent(modelId)}${qs ? `?${qs}` : ''}`);
  }

  async getMusicHistory(opts?: { days?: number; modelId?: string; provider?: string }): Promise<MusicModelHistory[]> {
    const params = new URLSearchParams();
    if (opts?.days) params.set('days', String(opts.days));
    if (opts?.modelId) params.set('modelId', opts.modelId);
    if (opts?.provider) params.set('provider', opts.provider);
    const qs = params.toString();
    return this.request<MusicModelHistory[]>(`/api/v1/music/history${qs ? `?${qs}` : ''}`);
  }

  async getMusicProviders(): Promise<MusicProviderSummary[]> {
    return this.request<MusicProviderSummary[]>('/api/v1/music/providers');
  }

  async compareMusicModels(modelIds: string[], opts?: { currency?: string }): Promise<MusicModelPricing[]> {
    const params = new URLSearchParams({ models: modelIds.join(',') });
    if (opts?.currency) params.set('currency', opts.currency);
    return this.request<MusicModelPricing[]>(`/api/v1/music/compare?${params}`);
  }

  async getCheapestMusicModel(opts?: { provider?: string; currency?: string; after?: string; before?: string }): Promise<MusicModelPricing> {
    const params = new URLSearchParams();
    if (opts?.provider) params.set('provider', opts.provider);
    if (opts?.currency) params.set('currency', opts.currency);
    if (opts?.after) params.set('after', opts.after);
    if (opts?.before) params.set('before', opts.before);
    const qs = params.toString();
    return this.request<MusicModelPricing>(`/api/v1/music/cheapest${qs ? `?${qs}` : ''}`);
  }
}
