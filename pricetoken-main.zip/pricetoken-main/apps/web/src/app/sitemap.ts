import type { MetadataRoute } from 'next';

export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = 'https://pricetoken.ai';
  const buildDate = new Date('2026-03-04');

  return [
    { url: baseUrl, lastModified: buildDate, changeFrequency: 'daily', priority: 1 },
    { url: `${baseUrl}/image`, lastModified: buildDate, changeFrequency: 'daily', priority: 0.8 },
    { url: `${baseUrl}/image/calculator`, lastModified: buildDate, changeFrequency: 'weekly', priority: 0.7 },
    { url: `${baseUrl}/image/compare`, lastModified: buildDate, changeFrequency: 'weekly', priority: 0.7 },
    { url: `${baseUrl}/image/history`, lastModified: buildDate, changeFrequency: 'daily', priority: 0.7 },
    { url: `${baseUrl}/history`, lastModified: buildDate, changeFrequency: 'daily', priority: 0.8 },
    { url: `${baseUrl}/calculator`, lastModified: buildDate, changeFrequency: 'weekly', priority: 0.7 },
    { url: `${baseUrl}/compare`, lastModified: buildDate, changeFrequency: 'weekly', priority: 0.7 },
    { url: `${baseUrl}/video`, lastModified: buildDate, changeFrequency: 'daily', priority: 0.8 },
    { url: `${baseUrl}/video/calculator`, lastModified: buildDate, changeFrequency: 'weekly', priority: 0.7 },
    { url: `${baseUrl}/video/compare`, lastModified: buildDate, changeFrequency: 'weekly', priority: 0.7 },
    { url: `${baseUrl}/video/history`, lastModified: buildDate, changeFrequency: 'daily', priority: 0.7 },
    { url: `${baseUrl}/avatar`, lastModified: buildDate, changeFrequency: 'daily', priority: 0.8 },
    { url: `${baseUrl}/avatar/calculator`, lastModified: buildDate, changeFrequency: 'weekly', priority: 0.7 },
    { url: `${baseUrl}/avatar/compare`, lastModified: buildDate, changeFrequency: 'weekly', priority: 0.7 },
    { url: `${baseUrl}/avatar/history`, lastModified: buildDate, changeFrequency: 'daily', priority: 0.7 },
    { url: `${baseUrl}/tts`, lastModified: buildDate, changeFrequency: 'daily', priority: 0.8 },
    { url: `${baseUrl}/tts/calculator`, lastModified: buildDate, changeFrequency: 'weekly', priority: 0.7 },
    { url: `${baseUrl}/tts/compare`, lastModified: buildDate, changeFrequency: 'weekly', priority: 0.7 },
    { url: `${baseUrl}/tts/history`, lastModified: buildDate, changeFrequency: 'daily', priority: 0.7 },
    { url: `${baseUrl}/stt`, lastModified: buildDate, changeFrequency: 'daily', priority: 0.8 },
    { url: `${baseUrl}/stt/calculator`, lastModified: buildDate, changeFrequency: 'weekly', priority: 0.7 },
    { url: `${baseUrl}/stt/compare`, lastModified: buildDate, changeFrequency: 'weekly', priority: 0.7 },
    { url: `${baseUrl}/stt/history`, lastModified: buildDate, changeFrequency: 'daily', priority: 0.7 },
    { url: `${baseUrl}/music`, lastModified: buildDate, changeFrequency: 'daily', priority: 0.8 },
    { url: `${baseUrl}/music/calculator`, lastModified: buildDate, changeFrequency: 'weekly', priority: 0.7 },
    { url: `${baseUrl}/music/compare`, lastModified: buildDate, changeFrequency: 'weekly', priority: 0.7 },
    { url: `${baseUrl}/music/history`, lastModified: buildDate, changeFrequency: 'daily', priority: 0.7 },
    { url: `${baseUrl}/docs`, lastModified: buildDate, changeFrequency: 'monthly', priority: 0.9 },
    { url: `${baseUrl}/legal`, lastModified: buildDate, changeFrequency: 'yearly', priority: 0.3 },
  ];
}
