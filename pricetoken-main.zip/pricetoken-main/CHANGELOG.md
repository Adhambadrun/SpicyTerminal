# Changelog

## [0.13.10] - 2026-03-20

### Added
- 6 Replicate avatar/lip-sync models: VEED Fabric 1.0 (480p/720p), Wav2Lip, SadTalker, VideoRetalking, DreamActor M2.0
- Replicate as new avatar provider with fallback URLs and system prompt wiring
- Avatar model count: 18 → 24

## [0.13.9] - 2026-03-20

### Added
- 24 new video generation models (49 → 73 total): Hunyuan Video, Vidu Q3, Magi, PixVerse, CogVideoX-5B, Seedance 1.0 Pro, Stable Video, Wan 2.2/2.6, Kling 2.6, LTX 2.0, and more
- Replicate as new video provider with 8 models — including Seedance 1 Pro Fast and Wan 2.2 5B Fast ($0.18/min, cheapest video model in registry)
- Scraper fallback URLs for all new FAL video models
- DB seed corrections for all 24 new models

## [0.13.8] - 2026-03-17

### Added
- GPT-5.4 mini/nano, GPT Image 1.5, and Sora 2 Pro pricing correction in registry

### Fixed
- Analytics crash on null SUM aggregation and broken event tracking
- Edge Runtime sandbox bypass for analytics tracking (use localhost)
- Video corrections: added grok-imagine-video to DB seeding pipeline

## [0.13.7] - 2026-03-17

### Added
- xAI text models: Grok 4.20 ($2/$6/MTok, 2M context) and Grok Code Fast 1 ($0.20/$1.50/MTok)
- xAI video: Grok Imagine Video ($3/min)
- FAL TTS: xAI TTS ($4.20/M chars), TADA 1B ($50/M chars), TADA 3B ($80/M chars)
- Scraper pipeline wiring for all new models (system prompts, provider configs, fallback URLs)

## [0.13.6] - 2026-03-16

### Added
- FAL LTX-2.3 Audio-to-Video model in video and avatar registries
- Registry validation for carried models and music fetch pipeline support

### Fixed
- Deploy seed now covers all 6 categories (was missing avatar, tts, stt, music)

## [0.13.5] - 2026-03-14

### Added
- Google Cloud Gemini 2.5 Flash-Lite Preview TTS model ($0.50/M chars) — TTS registry now has 61 models

## [0.13.4] - 2026-03-12

### Added
- Music category to daily cron script and retry endpoint — music pricing now runs alongside the other 6 categories
- Static fallback text mechanism for providers with unscrappable pricing pages (Framer SPAs, etc.)
- Cartesia TTS static fallback — Sonic-3 and Sonic-Turbo no longer flagged daily due to scraping failures

### Removed
- Deprecated `fal-flux-1-pro` from image registry — image models reduced from 47 to 46

## [0.13.3] - 2026-03-13

### Added
- 3 new FAL avatar models: VEED Fabric 1.0 480p ($4.80/min), VEED Fabric 1.0 720p ($9.00/min), and Kling Video LipSync Text-to-Video ($0.84/min) — avatar registry now has 17 models

## [0.13.2] - 2026-03-11

### Added
- 2 new Replicate/Inworld TTS models: Inworld TTS 1.5 Max ($10/M chars) and Inworld TTS 1.5 Mini ($5/M chars) — TTS registry now has 60 models

## [0.13.1] - 2026-03-10

### Added
- 4 new SunoAPI.org models: Suno v4, v4.5 Plus, v4.5 All, and v5 — music registry now has 7 models

### Fixed
- Corrected SunoAPI.org pricing from estimated $0.00625/min to verified $0.00375/min (v4.5+) and $0.0075/min (v4), based on actual API call credit measurements (12 credits/call, 2 songs/call, $0.005/credit)

## [0.13.0] - 2026-03-10

### Added
- **Music generation** as 7th pricing modality — 3 providers: ElevenLabs ($0.50/min), Soundverse ($0.0125/min), SunoAPI.org ($0.00625/min, unofficial)
- Music YAML registry, static generation (14 files total), and SDK support in both TypeScript and Python (types, cost functions, client methods)
- 6 REST API endpoints under `/api/v1/music` (list, single model, cheapest, compare, history, providers)
- Music frontend pages: pricing table, cost calculator, model comparison, price history chart
- Full 3-tier music scraper pipeline with AI extraction, cross-verification, prior consistency checks, and consensus building
- Cron route `/api/cron/fetch-music-pricing` for automated music price scraping
- "Unofficial" purple badge variant on `StatusBadge` for third-party API wrappers
- `pricingNote` tooltip on music pricing table for credit/per-song conversion explanations
- Music API documentation in docs page with curl, JavaScript, and Python examples

## [0.12.0] - 2026-03-10

### Added
- Confidence tooltip on "unverified" badges — hover to see why a model shows medium/low confidence (carried forward, flagged, stale, etc.)
- 7-day carry-forward expiry — orphaned models that haven't been scraped in 7+ days stop being carried, preventing indefinite zombie entries
- Runway Characters added to avatar scraper pipeline for daily price fetching

### Fixed
- Removed 5 orphaned HeyGen avatar model IDs (`heygen-translate-*`, `heygen-video-agent-prompt`, `heygen-video-translation`) that were renamed but still in the registry
- Deprecated `heygen-avatar-standard` and `heygen-avatar-iv` in registry and updated all docs/prompts to use active model IDs
- Removed `gemini-3-pro-preview` from scraper system prompt (already deprecated in registry)
- Added one-time DB cleanup script for stale low-confidence rows from early March

## [0.11.1] - 2026-03-09

### Added
- Runway Characters (GWM-1 Avatars) — first non-HeyGen avatar provider, real-time conversational avatars at $0.20/min

## [0.11.0] - 2026-03-08

### Added
- **YAML model registry** — single source of truth for all pricing data across 6 modalities (`registry/*.yaml`), with `generate-static` script producing both TS and Python SDK static files
- **Self-hosted analytics system** — SQLite-based tracking with bot detection, 15+ dashboard chart/table components, middleware integration, and cron aggregation
- **Enhanced browser scraper** — scroll support, `waitForSelector`, longer waits for JS-heavy pricing pages, and `browserOptions` threaded through all fetch pipelines
- Per-model FAL fallback URLs with accumulative fallback logic across all models
- Regression detection in `update-static` script
- Video corrections pipeline with DB-first pricing flow
- FAL HeyGen Avatar4 models
- GenAI prices comparison script with coverage analysis
- CI validation for registry YAML and generated static files
- CONTRIBUTING.md, GitHub issue form, and PR template

### Fixed
- `pageText` limit increased to 100K and relaxed consensus threshold for price changes
- Combined page text now passed to cross-verification for more accurate extraction
- Complete model ID coverage in all system prompts (video, image, text)
- Provider config URLs and extraction prompts updated for reliable scraping
- Dirty working tree reset on server before `git pull` during deploy

### Changed
- `update-static.ts` refactored to write directly to `registry/*.yaml` instead of static files
- All package versions unified to single version track (web, npm SDK, Python SDK)

## [0.10.2] - 2026-03-07

### Added
- `update-static` script (`npm run update-static`) — fetches all 6 modalities from production API and regenerates both TS and Python SDK static files automatically
- `inputType` field on Python SDK `VideoModelPricing` dataclass

### Fixed
- Python SDK static data fully synced with production API across all 6 modalities (text, TTS, STT, avatar, image, video) — added 50+ missing models
- Video static template now always includes `inputType` field (fixes TS type errors)
- Test assertions relaxed for nullable fields (`inputType`, `supportedFormats`)

## [0.10.1] - 2026-03-07

### Added
- `lipSync` boolean field on avatar pricing — indicates whether a model produces lip-synced output (true for all avatar generation and lip-synced translation, false for proofread/audio dubbing)
- Deprecated toggle for Video, TTS, STT, and Avatar pricing tables
- Smart carry-forward with 1-day grace period and original source tracking
- Fallback extraction URLs for all pricing categories
- FAL, Cartesia, and ElevenLabs TTS/STT providers
- Launch dates backfilled for 88 models across video, avatar, TTS, STT

### Fixed
- Carry-forward now preserves original non-carried source for confidence scoring
- Ideogram V3 prices corrected to match actual API pricing
- TTS static data synced with refined production launch dates
- Python SDK avatar static data synced (3 → 15 entries)

### Changed
- fal.ai image models updated to match top platform models

## [0.10.0] - 2026-03-06

### Added
- **Text-to-Speech (TTS) pricing module** — 13 models from 7 providers (OpenAI, Google Cloud, Amazon Polly, Azure, ElevenLabs, Deepgram, PlayHT) tracked at cost per million characters
  - `TtsPricingSnapshot` Prisma model, SDK types (`TtsModelPricing`, `TtsCostEstimate`, etc.), static seed data, and cost functions
  - TTS provider registry + LLM extraction pipeline with 3-tier verification
  - `/api/v1/tts/*` routes (all, single, cheapest, compare, history, providers) with `after`/`before` date filtering
  - TTS pricing table, cost calculator, model comparison, and price history pages
  - SDK client methods: `getTtsPricing()`, `getTtsModel()`, `compareTtsModels()`, `getCheapestTtsModel()`, etc.
- **Speech-to-Text (STT) pricing module** — 10 models from 5 providers (OpenAI, Deepgram, AssemblyAI, Google Cloud, Azure) tracked at cost per minute
  - `SttPricingSnapshot` Prisma model, SDK types (`SttModelPricing`, `SttCostEstimate`, etc.), static seed data, and cost functions
  - STT provider registry + LLM extraction pipeline with 3-tier verification
  - `/api/v1/stt/*` routes (all, single, cheapest, compare, history, providers) with `after`/`before` date filtering
  - STT pricing table, cost calculator, model comparison, and price history pages
  - SDK client methods: `getSttPricing()`, `getSttModel()`, `compareSttModels()`, `getCheapestSttModel()`, etc.
- TTS and STT support in both npm and Python SDKs (types, static data, cost functions, client methods, tests)
- Navigation links, docs tab switcher (6 tabs), homepage modality cards, and sitemap entries for TTS and STT
- TTS and STT seed scripts, fetch scripts, and cron endpoints added to sequential runner
- Sanity bounds: TTS $0.50–$500/M chars, STT $0.0005–$1.00/min
- Launch date filter tests for TTS and STT route endpoints

### Fixed
- HeyGen avatar scraper switched to docs.heygen.com reference page
- Launch date fallback to static data for all store layers

## [0.9.0] - 2026-03-06

### Added
- **Avatar AI pricing module** — HeyGen API pricing with 3 models (Standard Avatar, Interactive Avatar IV, Video Translation) tracked at cost-per-minute granularity
  - `AvatarPricingSnapshot` Prisma model, avatar SDK types, static seed data, and cost functions
  - Avatar provider registry + LLM extraction pipeline with 3-tier verification
  - `/api/v1/avatar/*` routes (all, single, cheapest, compare, history, providers)
  - Avatar cost calculator, comparison, price history pages, and non-API provider directory cards
  - SDK client methods: `getAvatarPricing()`, `getAvatarModel()`, `compareAvatarModels()`, etc.
  - Navigation entries, docs, homepage card, and sitemap entries
  - Avatar seed and cron scripts added to sequential runner
- Avatar test coverage for both npm and Python SDKs (cost calculation + client methods)
- Sequential cron runner script for orchestrating text, image, video, and avatar fetch pipelines
- Conference-style 3-tier verification (reviewers, area chair, general chair) for pricing extraction
- `launchDate` extraction from provider pricing pages
- Re-verification for flagged models before giving up
- GPT-5.4 text models and LTX video provider
- Disabled 3D/World modality card with "coming soon" provider section
- Image pricing cron endpoint
- GitHub Release creation on version tags

### Fixed
- `maxDuration` required and verified for all video models
- Provider URLs and extraction prompts updated for reliable extraction
- Model ID constraints added to video and image extraction prompts
- Extraction-layer failures fixed with re-verification and `launchDate` extraction
- Scraper text limit increased to 30k, browser timeout to 90s, AI max tokens to 8192
- Verification consensus and verdict parsing improved
- Image/video carry-forward preserves `launchDate` in snapshots
- Docker deploy: wait for Postgres, retry Prisma migrations on DNS failures, OAuth for Claude CLI
- Providers already verified today skipped on re-run
- Amazon and Mistral providers removed
- Unknown model IDs filtered in image/video pipelines

### Changed
- Verification text bumped to 25k with `Accept-Language` header for consistent extraction
- Health endpoint reads version from `package.json` at build time

## [0.8.0] - 2026-03-05

### Added
- **Bayesian confidence scoring** — every model gets a numeric `confidenceScore` (0–100), a three-tier `confidenceLevel` ("high" | "medium" | "low"), and a `freshness` object with `lastVerified`, `ageHours`, and `stale` fields. Scores are computed at query time using log-odds Bayesian updating with priors based on data source, agent consensus, data age, and price stability. (Suggested by [@maxrodrigo](https://github.com/maxrodrigo))
- `agentApprovals` and `agentTotal` columns on all three snapshot tables — verification metadata is now persisted to the database instead of being discarded after scraping
- `FreshnessIndicator` component — colored dot (green/yellow/red) with relative time ("2h ago", "3d ago") and tooltip showing confidence score, added as a new sortable column in all three pricing tables (Text, Image, Video)
- "Score" step (5th) in the data pipeline explainer on the landing page, explaining the Bayesian methodology
- "Confidence Scoring" section in API docs with formula, prior table, and field descriptions
- Confidence scoring section in README with field reference table
- 15 new tests for confidence scoring library (boundary conditions, signal independence, level mapping, freshness)

### Changed
- `DataConfidence` type expanded from `"high" | "low"` to `"high" | "medium" | "low"`
- `ModelPricing.source`, `ImageModelPricing.source`, `VideoModelPricing.source` unions expanded to include `"carried"` and `"verified"` where missing
- `StatusBadge` component now shows "unverified" badge for both `"medium"` and `"low"` confidence
- Response format updated: `confidence` field now reflects the computed level instead of the raw DB value
- Python SDK types updated with `FreshnessInfo` dataclass, `ConfidenceLevel` type, and expanded `Source`/`DataConfidence` literals
- All static pricing entries (JS + Python) include default `confidenceScore`, `confidenceLevel`, and `freshness` fields

## [0.7.0] - 2026-03-05

### Added
- **Video AI pricing module** — 9 providers (Runway, Sora, Veo, Kling, Luma, Pika, MiniMax, Seedance, FAL) with 17 models tracked at cost-per-minute granularity
  - `VideoPricingSnapshot` Prisma model, video SDK types, static seed data
  - Video provider registry + LLM extraction pipeline with cross-verification
  - `/api/v1/video/*` routes (all, single, cheapest, compare, history, providers)
  - Video cost calculator, comparison, and price history pages
  - SDK client methods: `getVideoPricing()`, `getVideoModel()`, `compareVideoModels()`, etc.
  - Python SDK mirror with `calculate_video_cost()` and all video client methods
- **Image generation pricing module** — 11 providers (OpenAI, Google, Stability, BFL, Amazon, Recraft, Mistral, Bytedance, fal, Ideogram, xAI) with image models tracked at cost-per-image
  - `ImagePricingSnapshot` Prisma model, image SDK types, static seed data
  - Image extraction pipeline with cross-verification, prior-consistency checks, and consensus (new in 0.7.0)
  - `/api/v1/image/*` routes
  - Image pricing table page with inline calculator
  - SDK client methods and Python mirror
- **Unified modality navigation** — sub-nav tabs for Text/Image/Video under each section (Pricing, Calculator, Compare, History)
- **Launch Price vs Date** scatter chart on image and video history pages (text already had it)
- **Sanity bounds** for all three modalities — rejects obviously wrong prices (negative, zero, out of range) before verification
- Mobile responsive overhaul across all pages (hamburger nav, responsive tables, charts)
- Configurable AI extraction providers (Claude Code CLI, Anthropic, OpenAI, Google)
- systemd timer for daily automated pricing fetches
- Admin "Fetch Now" button on fetch-status page
- 80 new tests (268 total across JS, 44 Python)

### Fixed
- Full pricing audit across all modalities using official API documentation:
  - Text: Gemini 2.0 Flash/Flash-Lite marked deprecated, Gemini 3 Pro date corrected, DeepSeek display names updated, Qwen launch dates fixed
  - Video: Veo 3.1 prices corrected ($12→$24/min 1080p, $24→$36/min 4K), Kling 3.0 ($1.74→$5.04/min), all 15 launch dates verified, Sora 2 Pro duration fixed (20→25s)
  - Image: BFL FLUX models rewritten (removed non-existent models, added missing ones, corrected all prices and launch dates)
  - FAL aggregator prices corrected to FAL's actual rates (not upstream provider rates)
- Improved LLM system prompts with explicit credit-to-USD and per-second-to-per-minute conversion examples
- Recharts rendering fixes (NaN props, empty charts, SSR issues)
- Robust JSON extraction from LLM responses with surrounding text

### Changed
- `/api/v1/pricing/*` base routes removed — `/api/v1/text/*` is now canonical (parallel with `/image/*` and `/video/*`)
- Image fetch pipeline upgraded from extract-and-save to full 4-layer verification (extraction → sanity bounds → cross-verify → prior-consistency → consensus)
- Video system prompt expanded with concrete conversion examples to prevent common extraction errors

## [0.6.0] - 2026-03-04

### Added
- Opt-in SDK telemetry for both npm and Python packages — fire-and-forget ping on first API call when `telemetry: true` is set
- `POST /api/v1/telemetry` endpoint with 10/hr rate limit per IP, silent drop on errors
- Admin downloads page (`/admin/downloads`) with npm/PyPI download stats, telemetry pings chart, and SDK breakdown table
- "Used by" section on landing page powered by GitHub Code Search (Redis-cached, seeded adopters)
- `SdkTelemetryPing` Prisma model for telemetry storage
- Gemini 3.1 Flash-Lite and Gemini 3 Pro added to static pricing data
- PyPI monthly downloads badge in README
- Python SDK linting (ruff + mypy) added to root CI pipeline
- 11 new tests across telemetry endpoint, JS SDK, and Python SDK (188 total)

### Changed
- Middleware CORS methods expanded from `GET, OPTIONS` to `GET, POST, OPTIONS`
- Telemetry route exempted from general API rate limiter (uses its own 10/hr limit)

## [0.5.0] - 2026-03-04

### Added
- `launchDate` field across the full stack: SDK types, Prisma schema, static data for all 42 models
- `after` and `before` date query params on `/api/v1/text` and `/api/v1/text/cheapest` endpoints for filtering models by launch date
- Sortable "Launched" column in the PricingTable (formats as "Mon YYYY", nulls sorted last)
- Launch Price Timeline scatter plot on `/history` page showing price trends across providers over time
- `after`/`before` params in both TS and Python SDK clients (`getPricing`, `getCheapest`, `get_pricing`, `get_cheapest`)
- GPT-5.3 Instant and GPT-5.3 Codex to static pricing data
- Legal disclaimer page (`/legal`) and footer link
- 7 new tests for date range filtering and SDK param forwarding (188 total)

### Fixed
- Seed script now backfills `launchDate` on existing DB records (previously only inserted new models)
- 6 launch dates corrected to use API GA dates instead of announcement dates (Grok 3/Mini, Gemini 2.0 Flash-Lite, DeepSeek V3, GPT-5.3 Codex, GPT-5.1)
- Deploy workflow seed step added to populate new models on deploy

## [0.4.1] - 2026-03-04

### Added
- Comprehensive API route handler tests: 67 tests across all 8 public endpoints covering HTTP status codes, CORS headers, Cache-Control, cache behavior, query params, currency conversion, and response shapes
- Curl example with JSON response preview in landing page hero section

### Fixed
- Seed script now inserts missing models instead of skipping when database already has data

## [0.4.0] - 2026-03-04

### Added
- xAI provider (Grok 4, Grok 4.1 Fast, Grok 3, Grok 3 Mini)
- Mistral provider (Mistral Large 3, Mistral Medium 3, Codestral, Mistral Small 3.1)
- OpenAI models: GPT-5.1, o3 Pro, o3 Mini
- Google preview models: Gemini 3.1 Pro Preview, Gemini 3 Flash Preview
- Puppeteer-based scraping for JS-rendered pricing pages (React SPAs)
- Provider brand colors for xAI and Mistral in dark/light themes
- PyPI install option in landing page hero CTA

### Fixed
- Deploy workflow Prisma schema path
- Docker build caching in deploy workflow
- USD currency included in API responses by default

## [0.3.1] - 2026-03-04

### Changed
- Admin authentication: replaced IP allowlist with password + HMAC-signed session cookies
- Admin routes restructured with Next.js route groups — login page has no sidebar

### Added
- `/admin/login` page with password form
- `POST /api/admin/auth` login endpoint with timing-safe password comparison
- `POST /api/admin/auth/logout` endpoint
- Logout button in admin sidebar
- Session cookie auth library (`admin-auth.ts`) using `crypto.subtle` (Edge-compatible)

### Removed
- `ADMIN_ALLOWED_IPS` env var — replaced by `ADMIN_PASSWORD` + `ADMIN_SESSION_SECRET`

## [py-0.3.0] - 2026-03-04

### Added
- Python SDK (`packages/sdk-python/`) — zero-dependency Python package mirroring the JS/TS SDK
- `PriceTokenClient` with all 6 API methods (get_pricing, get_model, get_history, get_providers, compare, get_cheapest)
- `calculate_cost` and `calculate_model_cost` for offline cost calculation
- 21 static pricing entries (Anthropic, OpenAI, Google, DeepSeek)
- Full type coverage with `dataclass(slots=True)` and PEP 561 `py.typed` marker
- `ci-python` job in CI workflow (ruff, mypy strict, pytest)
- `publish-python.yml` workflow for PyPI publishing on `py-v*` tags
- Python quick start section and PyPI badge in root README
- PyPI Package row in comparison table

### Fixed
- ESLint `no-undef` for `process` in `.mjs` files
- `package-lock.json` sync for `@pricetoken/sdk-python` workspace

## [0.3.0] - 2026-03-04

### Added
- Multi-agent verification pipeline: three AI providers (Anthropic, OpenAI, Google) cross-check extracted pricing with 2-of-3 consensus
- Admin panel with IP allowlist: fetch status dashboard, alerts page, cost tracking, and provider config
- Admin icon in navigation bar (visible to allowed IPs only)
- Daily cron trigger for automated pricing fetches
- Paste-text input mode for the cost calculator
- Model lifecycle status detection (active, deprecated) with StatusBadge component
- Missing model detection with admin warnings and fallback URL pipeline
- Custom pill dropdown for currency selector
- Full SEO suite: OpenGraph metadata, security headers, structured data
- Trust system with model status badges and confidence scores
- Auto-deploy on push to main via GitHub Actions

### Fixed
- Static pricing data corrections: removed hallucinated models, fixed context windows and prices
- SDK workspace build order in Docker
- OG metadata and social sharing image
- Price history chart tooltip precision (2 decimal places)

### Changed
- README overhauled with feature comparison table and verification explanation
- DataSources component updated with 4-step pipeline explanation

## [0.2.0] - 2026-03-03

### Added
- Gemini 3.1 Pro Preview to static pricing data ($2.00/$12.00 per MTok)
- "How We Get Our Data" transparency section on landing page with provider links and contribution CTA
- Pricing section subtitle explaining update frequency and units
- Alternatives comparison table in README

### Fixed
- Rate limit text corrected from "100 requests/day" to "30 requests/hour" (landing page + SDK README)
- Missing `.filters` CSS class in PricingTable causing unstyled filter bar
